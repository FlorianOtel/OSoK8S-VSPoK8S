
import sys
import socket
import SocketServer
import subprocess
from thread import *
from select import select
import time

class _Socket(object):
	MSGLEN = 2048
	BACKLOG_CONNECTIONS = 10

	def __init__(self, host, port, s=None):
		self.host = host
		self.port = port
		if s is None:
			self.s = socket.socket(socket.AF_INET,
					       socket.SOCK_STREAM)
		else:
			self.s = s

	def bind(self):
		self.s.bind((self.host, self.port))

	def listen(self):
		# puts the socket in server mode with max BACKLOG_CONNECTIONS
		self.s.listen(self.BACKLOG_CONNECTIONS)

	def accept(self):
		return self.s.accept()

	def connect(self):
		self.s.connect((self.host, self.port))

	def send(self, msg):
		while msg:
			bytes = self.s.send(msg)
			if (bytes == 0):
				raise RuntimeError("socket connection broken")
			msg = msg[bytes:]
		return bytes

	def recv(self):
		chunks = []
		while True:
			readable, writable, exceptional = select([self.s], [], [], 0)
			if readable == False:
				continue
			while True:
				chunk = self.s.recv(self.MSGLEN)
				if not chunk:
					break
				chunks.append(chunk)
			break
		return ''.join(chunks)

	def close(self):
		self.s.close()

class _SocketServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
	daemon_threads = True
	allow_reuse_address = True

	def __init__(self, server_ip, port, remote_ip, RequestHandlerClass,
		     lock, vlog):
		SocketServer.TCPServer.__init__(self, (server_ip, port),
						RequestHandlerClass)
		self.vlog = vlog
		self.server_ip = server_ip
		self.remote_ip = remote_ip
		self.port = port
		self.lock = lock

class _SocketClient(object):
	def __init__(self, client_ip, port):
		self.socket = _Socket(client_ip, port)
		self.socket.connect()

	def write(self, msg):
		try:
			sent_bytes = self.socket.send(msg)
		finally:
			self.socket.close()
		return sent_bytes
