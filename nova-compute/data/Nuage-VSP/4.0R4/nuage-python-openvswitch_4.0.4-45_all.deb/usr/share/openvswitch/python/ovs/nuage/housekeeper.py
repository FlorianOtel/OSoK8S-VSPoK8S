###########################################################################
#
#   Filename:           housekeeper
#
#   Author:             Saurabh Shrivastava
#   Created:            Feb 16 2016
#
#   Description:        Housekeeper
#
###########################################################################
#
#              Copyright (c) 2016 Nuage Networks, Nokia
#
###########################################################################

import random
import signal
import sys
import time

import nuage.utils

vlog = None

def init (v):
    global vlog
    vlog = v

def call_prog_cleanup (arg) :
    nuage.utils.call_prog (arg[0], arg[1])

def call_prog (method, params, cleanup, cleanup_first, cleanup_method, cleanup_params,
               verify_method, verify_params, verify_string) :
    ok = False
    if cleanup_first :
        call_prog_cleanup ((cleanup_method, cleanup_params))
        # remove from cleanup list TODO
    try :
        (ret, out, err) = nuage.utils.call_prog (verify_method, verify_params)
    except :
        out = ""
    if out.find (verify_string) < 0 :
        try :
            (ret, out, err) = nuage.utils.call_prog (method, params)
        except :
            ret = -1
        if ret == 0 :
            cleanup.cleanup_add (call_prog_cleanup, (cleanup_method, cleanup_params))
            ok = True
    else :
        # already present
        ok = True
    return ok

def config_parse (fname) :
    config = {}
    file= open (fname)
 
    for line in file :
        line = line.strip()
        if line and line[0] is not "#" and line[-1] is not "=":
            var,val = line.rsplit ("=",1)
            config [var.strip()] = val.strip()
            
    return config
