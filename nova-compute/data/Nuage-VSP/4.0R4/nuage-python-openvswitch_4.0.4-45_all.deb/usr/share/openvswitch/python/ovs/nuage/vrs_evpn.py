
import nuage.utils
import re

class VRSEvpn(object):
	def __init__(self, br, evpn_id, vlog):
		self.appctl_path = "/usr/bin/ovs-appctl"
		self.br = br
		self.evpn_id = evpn_id
		self.vlog = vlog

	def is_resilient(self):
		evpn_show_out = []
		cmdstr = self.appctl_path + " evpn/show " + self.br + " " + self.evpn_id
		r = nuage.utils.call_prog_as_is(cmdstr)
		if r[0] is not 0 :
			self.vlog.emer("Unable to execute: \"%s\"" % cmdstr)
			self.vlog.emer("rc: \"%s\"" % r[0])
			self.vlog.emer("out: \"%s\"" % r[1])
			self.vlog.emer("err: \"%s\"" % r[2])
			return False
		else :
			evpn_show_out = str(r[1].rstrip())
		rgstr_index = evpn_show_out.find("resiliency: ")
		if (rgstr_index == -1):
			return False
		rgstr_index = rgstr_index + len("resiliency: ")
		rgstate = str(evpn_show_out[rgstr_index:].split()[0])
		if (rgstate == "ENABLED") :
			return True
		else:
			return False

