
import time
import nuage.ovsdb_client
import nuage.utils
import re
import nuage.vrs_bridge
import nuage.vrs_vrf
import nuage.vrs_evpn

class VRSRgSyncdDhcpAgent :
	dhcp_preamble = "dhcp"
	db = "Open_vSwitch"
	evpn_table_name = "Nuage_Evpn_Dhcp_Pool_Table"
	mac_table_name = "Nuage_Evpn_Dhcp_Pool_Dhcp_Entry_Table"
	rgsync_table_name = "Vrs_Resiliency_Group_Sync_Dhcp"
	vlog = None

	def __init__(self, vlog):
		self.vlog = vlog

	def display_rgsync_stats(self):
		cols = [ "vrgsd_table", "vrgsd_n_inserts", "vrgsd_n_updates",
			 "vrgsd_n_deletes", "vrgsd_n_msgs_queued",
			 "vrgsd_n_msgs_dequeued" ]
		rgsync_dhcp_table = nuage.ovsdb_client.Transact(
				self.db, self.rgsync_table_name, self.vlog)
		read_row = rgsync_dhcp_table.get_cols_all_rows(cols)

		print("DHCP Agent:")
		print("%-38s%-7s%-7s%-7s%-9s%-9s" %("Table", "N-Ins", "N-Upd", "N-Del", "N-Msg-Q", "N-Msg-Dq"))
		for row in read_row:
			row = str(row).replace("[", "").replace("]", "").replace("'", "").split(",")
			table_name = row[0].replace(" ", "")
			if (table_name == '' or table_name == None):
				continue
			n_ins_str = str(row[1])
			if (n_ins_str == None or n_ins_str == ''):
				n_ins = 0
			else:
				n_ins = int(row[1])
			n_upd_str = str(row[2])
			if (n_upd_str == None or n_upd_str == ''):
				n_upd = 0
			else:
				n_upd = int(row[2])
			n_del_str = str(row[3])
			if (n_del_str == None or n_del_str == ''):
				n_del = 0
			else:
				n_del = int(row[3])
			n_msg_q_str = str(row[4])
			if (n_msg_q_str == None or n_msg_q_str == ''):
				n_msg_q = 0
			else:
				n_msg_q = int(row[4])
			n_msg_dq_str = str(row[5])
			if (n_msg_dq_str == None or n_msg_dq_str == ''):
				n_msg_dq = 0
			else:
				n_msg_dq = int(row[5])
			print("%-37s %-6d %-6d %-6d %-8d %-d" %(table_name, n_ins, n_upd, n_del, n_msg_q, n_msg_dq))

	def __update_rgsync_stats(self, table_name, field_name):
		cols = [ "vrgsd_table", field_name ]
		rgsync_dhcp_table = nuage.ovsdb_client.Transact(
				self.db, self.rgsync_table_name, self.vlog)
		read_row = rgsync_dhcp_table.get_cols_key_rows(
				"vrgsd_table", "string", table_name, cols)
		if (read_row == []):
			field_val = int("1")
			write_row = '{ "vrgsd_table" : "' + table_name + '", "' + field_name + '" : ' + str(field_val) + ' }'
			rgsync_dhcp_table.insert_row(write_row)
		else:
			read_row = str(read_row).replace("[[", "").replace("]]", "").split(",")
			field_val_str = str(read_row[1]).replace("'", "").replace(" ", "")
			if (field_val_str == None or field_val_str == ''):
				field_val = int("0")
			else:
				field_val = int(field_val_str)
			field_val = int(field_val + 1)
			key = '[[ "vrgsd_table", "==", "' + table_name + '" ]]'
			write_row = '{ "vrgsd_table" : "' + table_name + '", "' + field_name + '" : ' + str(field_val) + ' }'
			rgsync_dhcp_table.update_row(key, write_row)
		return

	def __update_rgsync_stats_n_ins(self, table_name):
		self.__update_rgsync_stats(table_name, "vrgsd_n_inserts")
		return

	def __update_rgsync_stats_n_del(self, table_name):
		self.__update_rgsync_stats(table_name, "vrgsd_n_deletes")
		return

	def __update_rgsync_stats_n_upd(self, table_name):
		self.__update_rgsync_stats(table_name, "vrgsd_n_updates")
		return

	def __update_rgsync_stats_n_msgs_q(self, table_name):
		self.__update_rgsync_stats(table_name, "vrgsd_n_msgs_queued")
		return

	def __update_rgsync_stats_n_msgs_dq(self, table_name):
		self.__update_rgsync_stats(table_name, "vrgsd_n_msgs_dequeued")
		return

	def __evpn_entry_read_ovsdb(self, evpn_id, selection):
		if (selection == 1):
			evpn_table_cols = [ "evpn_id", "table_modified" ]
		elif (selection == 2):
			evpn_table_cols = [ "dhcp_alloc_entry" ]
		else:
			evpn_table_cols = [ "evpn_id", "table_modified",
					    "dhcp_alloc_entry" ]
		evpn_table = nuage.ovsdb_client.Transact(self.db,
						self.evpn_table_name, self.vlog)
		evpn_row = evpn_table.get_cols_key_rows("evpn_id", "integer",
						evpn_id, evpn_table_cols)
		return evpn_row

	def __uuid_update_set_str(self, uuidList):
		string = "[ \"set\", ["
		uuidList = uuidList.split(",")
		for uuid in uuidList:
			string += "[\"uuid\",\"" + str(uuid) + "\" ],"
		string = string[:-1]
		string = string + " ] ]"
		return string

	def __evpn_entry_write_ovsdb(self, op, evpn_entry, macUuidList):
		evpn_id = evpn_entry[0]
		if (len(evpn_id.replace('[', '').split("'")) > 1):
			evpn_id = evpn_id.replace('[', '').split("'")[1]
		self.vlog.info("op: %s, evpn_id: %s, macUuidList: '%s'" %(op, evpn_id, macUuidList))
		macUuidListLen = len(macUuidList)
		if (macUuidListLen == 0) :
			self.vlog.info("macUuidList empty")
			return
		evpn_table = nuage.ovsdb_client.Transact(self.db,
					self.evpn_table_name, self.vlog)
		table_modified = "true"
		# first check if the entry exists, if not add it,
		# else update
		evpn_entry_ovsdb = self.__evpn_entry_read_ovsdb(evpn_id, 0)

		if (evpn_entry_ovsdb == []) and (op == "add"):
			self.vlog.info("%s: inserting evpn_id %s, table_modified: %s, macUuidList: %s" %(self.preamble, str(evpn_id), table_modified, macUuidList))
			macUuidStr = self.__uuid_update_set_str(macUuidList)
			evpn_row = '{ "evpn_id" : ' + evpn_id + ', "dhcp_alloc_entry" : ' + macUuidStr + ', "table_modified" : ' + table_modified + ' }'
			self.vlog.info("%s: evpn_row: %s" %(self.preamble, evpn_row))
			evpn_table.insert_row(evpn_row)
			self.__update_rgsync_stats_n_ins(self.evpn_table_name)
			return
		elif (evpn_entry_ovsdb == []) and (op == "del"):
			self.vlog.info("%s: attempting to delete from NULL evpn, ignoring" % self.preamble)
			return

		self.vlog.info("evpn_entry_ovsdb: %s" % evpn_entry_ovsdb)
		# retrieve the existing mac entries that are present
		# example if more than 1 uuid present
		#	[['200', 'False', "[u'set', [[u'uuid', u'4c246bdb-2293-41a1-8274-4015de94587c'], [u'uuid', u'986e8012-c8ab-4986-936a-be9f251a07ed']]]"]]
		# example if only 1 uuid present
		#	[['200', 'False', [u'4c246bdb-2293-41a1-8274-4015de94587c']]]
		if (str(evpn_entry_ovsdb).split(",")[2].find("set") != -1):
			set_index = str(evpn_entry_ovsdb).find("set")
			currUuidList = str(evpn_entry_ovsdb)[set_index + len("set' ") + 1:].replace("[", "").replace("]", "").replace('"', '').replace("u'uuid',", "").replace("u", "").replace("'", "").replace(" ", "")
		else :
			currUuidList = str(str(evpn_entry_ovsdb).split(",")[3].replace("']\"]]", "").split("'")[1])

		newUuidList = ""
		if (currUuidList == "") and (op == "add"):
			uuid_index = 0
			newUuidList = str(macUuidList)
		else:
			uuid_index = currUuidList.find(macUuidList);
			if (uuid_index != -1):
				if (op == "del"):
					# deleting from an existing list
					# currUuidList = AA,BB,CC,DD
					curr_len = len(currUuidList)
					if ((uuid_index == 0) and
					    (macUuidListLen == curr_len)):
						# delete AA (only entry)
						newUuidList = ""
					elif ((uuid_index == 0) and
					      (macUuidListLen < curr_len)):
						# delete AA
						newUuidList = currUuidList[uuid_index + macUuidListLen + 1 :]
					elif ((uuid_index > 0) and
					      (uuid_index + macUuidListLen < curr_len)):
						# delete BB or CC
						newUuidList = currUuidList[0:uuid_index - 1] + currUuidList[uuid_index + macUuidListLen :]
					elif ((uuid_index > 0) and
					      (uuid_index + macUuidListLen == curr_len)):
						# delete DD
						newUuidList = currUuidList[0:uuid_index - 1]
					else:
						self.vlog.info("possibly bad uuid removal, (ignoring). uuid_index: %d, macUuidListLen: %d, curr_len: %d" %(uuid_index, macUuidListLen, curr_len))
						return
				else:
					# adding new entries into an existing
			       		# list. For example,
					# macUuidList = AA,BB
					# currUuidList = CC
					newUuidList = str(macUuidList) + "," + str(currUuidList)
			elif (op == "add"):
				# adding more entries into an existing list
				# whose count is smaller than what is received
				# in bulk. Insert only if incoming entries
				# are unique. For example,
				# macUuidList = AA,BB
				# currUuidList = AA or BB
				newUuidSetStr = str(macUuidList) + "," + str(currUuidList)
				newUuidSet = set(newUuidSetStr.split(","))
				newUuidList = str(newUuidSet).replace("([", "").replace("])","").replace("set", "").replace("'", "").replace(" ", "")

		self.vlog.info("op: %s, evpn_entry_ovsdb: %s, currUuidList: %s, newUuidList: %s, uuid_index: %d" % (op, evpn_entry_ovsdb, currUuidList, newUuidList, uuid_index))
		if (newUuidList != ""):
			newUuidStr = self.__uuid_update_set_str(newUuidList)
			evpn_row = '{ "evpn_id" : ' + evpn_id + ', "dhcp_alloc_entry" : ' + str(newUuidStr) + ', "table_modified" : ' + table_modified + ' }'
			key = '[[ "evpn_id", "==", ' + evpn_id + ' ]]'
			self.vlog.info("%s: updating evpn_id %s, table_modified: %s, newUuidStr: %s" %(self.preamble, str(evpn_id), table_modified, newUuidStr))
			evpn_table.update_row(key, evpn_row)
			self.__update_rgsync_stats_n_upd(self.evpn_table_name)
			return

		if ((op == "del") and (macUuidList != None) and
		    (len(macUuidList.split(",")) == 1)):
			self.vlog.info("%s: deleting evpn_id %s" %(self.preamble, str(evpn_id)))
			evpn_row = '[[ "evpn_id", "==", ' + evpn_id + ' ]]'
			evpn_table.delete_row(evpn_row)
			self.__update_rgsync_stats_n_del(self.evpn_table_name)

			table_modified = "true"
			evpn_row = '{ "evpn_id" : ' + evpn_id + ', "table_modified" : ' + table_modified + ' }'
			self.vlog.info("%s: reinserting evpn_row: %s" %(self.preamble, evpn_row))
			evpn_table.insert_row(evpn_row)

	def __mac_entry_read_ovsdb(self, mac_addr, read_uuid_only):
		mac_table = nuage.ovsdb_client.Transact(self.db,
					self.mac_table_name, self.vlog)
		if (read_uuid_only == True) :
			mac_table_cols = [ "_uuid" ]
		else :
			mac_table_cols = [ "mac", "ip_addr", "lease_start_time", "lease_time" ]
		mac_row = mac_table.get_cols_key_rows("mac", "string",
					mac_addr, mac_table_cols)
		return mac_row

	def __mac_entry_read_ovsdb_by_uuid(self, uuid, selection):
		mac_table = nuage.ovsdb_client.Transact(self.db,
					self.mac_table_name, self.vlog)
		if (selection == 1):
			mac_table_cols = [ "mac" ]
		else:
			mac_table_cols = [ "mac", "ip_addr", "lease_start_time", "lease_time" ]
		mac_row = mac_table.get_cols_by_uuid(uuid, mac_table_cols)
		return mac_row

	def __mac_entry_evpn_membership_check(self, mac_uuid, evpn_id):
		evpn_entry_ovsdb = self.__evpn_entry_read_ovsdb(str(evpn_id), 2)
		if (str(evpn_entry_ovsdb).find("set") != -1):
			set_index = str(evpn_entry_ovsdb).find("set")
			macUuidListStr = str(evpn_entry_ovsdb)[set_index + len("set' ") + 1:].replace("[", "").replace("]", "").replace('"', '').replace("u'uuid',", "").replace("u", "").replace("'", "").replace(" ", "")
			self.vlog.info("mac_uuid: {%s}, macUuidListStr: {%s}, evpn_id: {%s}" % (mac_uuid, macUuidListStr, str(evpn_id)))
			if ((macUuidListStr != '') and
			    (macUuidListStr.find(mac_uuid) != -1)):
				return True
		else :
			evpn_entry_ovsdb_str = str(evpn_entry_ovsdb)
			self.vlog.info("mac_uuid: {%s}, evpn_entry_ovsdb_str: {%s}, evpn_id: {%s}" % (mac_uuid, evpn_entry_ovsdb_str, str(evpn_id)))
			if ((evpn_entry_ovsdb_str != '') and
			    (evpn_entry_ovsdb_str.find(mac_uuid) != -1)):
				return True
		return False

	def __mac_content_read_ovsdb(self, mac_csv_list, evpn_id):
		macList = mac_csv_list.split(",")
		mac_rows = ""
		for mac_entry in macList:
			op = mac_entry.split(":")[0]
			mac_addr = mac_entry.split(":")[1:]
			mac_addr = ":".join(str(x) for x in mac_addr)
			mac_uuid = self.__mac_entry_read_ovsdb_uuid(str(mac_addr).split(","))
			if (mac_uuid == None) or (mac_uuid == "") :
				continue
			if (mac_uuid.find(",") != -1):
				mac_uuid_list = mac_uuid.split(",")
				for mac_uuid in mac_uuid_list:
					if (self.__mac_entry_evpn_membership_check(mac_uuid, str(evpn_id)) == True):
						mac_row = self.__mac_entry_read_ovsdb_by_uuid(mac_uuid, 0)
						self.vlog.info("mac_row: {%s}, evpn_id: {%s}" % (mac_row, str(evpn_id)))
						break
			else:
				mac_row = self.__mac_entry_read_ovsdb(mac_addr, False)
			if (mac_row == []) or (op == None):
				continue
			mac_rows += str(op) + str(":")
			mac_rows += str(mac_row)
		return mac_rows

	def __mac_entry_write_ovsdb(self, op, mac_entry, evpn_id):
		if (mac_entry == None) or (str(mac_entry) == "['']"):
			return
		self.vlog.info("mac_entry: !!%s!!, evpn_id: %s" %(mac_entry, evpn_id))
		mac = mac_entry[0]
		mac = mac.replace('[', '')
		mac_table = nuage.ovsdb_client.Transact(self.db,
					self.mac_table_name, self.vlog)
		# first check if the entry exists, if not add it, else update
		if (op == "add") :
			mac_entry_ovsdb_list = self.__mac_entry_read_ovsdb(mac, True)
			self.vlog.info("mac_entry_ovsdb_list: @@%s@@" % mac_entry_ovsdb_list)
			if (mac_entry_ovsdb_list == []):
				mac_entry_ovsdb = mac_entry_ovsdb_list
				ip_addr_ovsdb = None
			else:
				if (str(mac_entry_ovsdb_list).find("uuid") == -1):
					uuidList = str(mac_entry_ovsdb_list).split(",")[1].split('"')[0].replace("]","").split("'")[1]
				else:
					uuidList = str(mac_entry_ovsdb_list).replace("u'uuid',", "").replace("u", "").replace("]", "").replace("[", "").replace('"', '').replace("'", "").replace(" ", "").split(",")
				mac_entry_ovsdb = []
				ip_addr_ovsdb = None
				for mac_uuid in uuidList:
					self.vlog.info("mac_uuid: %s, uuidList: {%s}" % (mac_uuid, uuidList))
					if (self.__mac_entry_evpn_membership_check(mac_uuid, str(evpn_id)) == True):
						mac_entry_ovsdb = self.__mac_entry_read_ovsdb_by_uuid(mac_uuid, 0)
						mac_entry_ovsdb_comps = str(mac_entry_ovsdb).split(",")
						ip_addr_ovsdb = mac_entry_ovsdb_comps[1].replace("'", "").replace(" ", "")
						self.vlog.info("Found in evpn_id: %s, mac_entry_ovsdb: %s, ip_addr_ovsdb: %s, ignoring" % (evpn_id, mac_entry_ovsdb, ip_addr_ovsdb))
						return None
			ip_addr = mac_entry[1].replace(' ', '').replace("'", "")
			lease_start_time = mac_entry[2].split("'")[1]
			lease_time = mac_entry[3]
			lease_time = lease_time.replace(']', '').split("'")[1]
			mac_row = '{ "mac" : "' + str(mac) + '", "ip_addr" : "' + str(ip_addr) +'", "lease_start_time" : ' + lease_start_time + ', "lease_time" : ' + lease_time + ' }'
			if (mac_entry_ovsdb == []):
				mac_table.insert_row(mac_row)
				self.__update_rgsync_stats_n_ins(self.mac_table_name)
			elif (ip_addr_ovsdb != ip_addr):
				mac_table.insert_row(mac_row)
				self.__update_rgsync_stats_n_ins(self.mac_table_name)
			else :
				key = '[[ "mac", "==", "' + str(mac) + '" ]]'
				mac_table.update_row(key, mac_row)
				self.__update_rgsync_stats_n_upd(self.mac_table_name)

			# now read it and obtain the uuid of the entry
			# and return it
			mac_entry_ovsdb = self.__mac_entry_read_ovsdb(mac, True)
			if (str(mac_entry_ovsdb).find("uuid") == -1):
				uuid = str(mac_entry_ovsdb).split(",")[1].split('"')[0].replace("]","").split("'")[1]
			else:
				uuidList = str(mac_entry_ovsdb).replace("u'uuid',", "").replace("u", "").replace("]", "").replace("[", "").replace('"', '').replace("'", "").replace(" ", "").split(",")
				uuid = ""
				for mac_uuid in uuidList:
					mac_row = self.__mac_entry_read_ovsdb_by_uuid(mac_uuid, 0)
					if (str(mac_row).find(ip_addr) != -1):
						uuid = mac_uuid
						break
			self.vlog.info("ip_addr: %s, ip_addr_ovsdb: {%s}, uuid: {%s}" % (ip_addr, ip_addr_ovsdb, uuid))
			return uuid
		else :
			mac_row = '[[ "mac", "==", "' + str(mac) + '" ]]'
			mac_table.delete_row(mac_row)
			self.__update_rgsync_stats_n_del(self.mac_table_name)
			return None

	def __mac_content_write_ovsdb(self, op, mac_content, evpn_id):
		uuidList = ""
		for mac_entry in mac_content:
			mac_entry = str(mac_entry).split(",")
			uuid = self.__mac_entry_write_ovsdb(op, mac_entry, evpn_id)
			if (uuid == None) :
				continue
			if (uuidList == ""):
				uuidList += str(uuid)
			else :
				uuidList += "," + str(uuid)
		return uuidList

	def __mac_uuid_read_ovsdb_content(self, uuid):
		content = ""
		if ((uuid == None) or (uuid == "")):
			return str(content)
		mac_table = nuage.ovsdb_client.Transact(self.db,
					self.mac_table_name, self.vlog)
		mac_entry_ovsdb = self.__mac_entry_read_ovsdb_by_uuid(uuid, 0)
		if ((mac_entry_ovsdb == None) or
		    (str(mac_entry_ovsdb) == "") or
		    (str(mac_entry_ovsdb) == "[]")) :
			return str(content)
		content = str(mac_entry_ovsdb)
		return content

	def __mac_entry_read_ovsdb_uuid(self, mac_entry):
		uuid = ""
		if ((mac_entry == None) or (mac_entry == "")):
			return str(uuid)
		mac = mac_entry[0]
		mac = mac.replace('[', '')
		mac_table = nuage.ovsdb_client.Transact(self.db,
					self.mac_table_name, self.vlog)
		mac_entry_ovsdb = self.__mac_entry_read_ovsdb(mac, True)
		if ((mac_entry_ovsdb == None) or
		    (str(mac_entry_ovsdb) == "") or
		    (str(mac_entry_ovsdb) == "[]")) :
			return uuid
		self.vlog.info("mac_entry_ovsdb: @%s@, mac: #%s#" %(mac_entry_ovsdb, mac))
		if (str(mac_entry_ovsdb).find("uuid") == -1):
			uuid = str(mac_entry_ovsdb).split(",")[1].split('"')[0].replace("]","").split("'")[1]
		else:
			uuid = str(mac_entry_ovsdb).replace("u'uuid',", "").replace("u", "").replace("]", "").replace("[", "").replace('"', '').replace("'", "").replace(" ", "")
		return uuid

	def __mac_content_read_ovsdb_uuid(self, mac_content):
		uuidList = ""
		for mac_entry in mac_content:
			mac_entry = str(mac_entry).split(",")
			uuid = self.__mac_entry_read_ovsdb_uuid(mac_entry)
			if (uuid == None) or (uuid == "") :
				continue
			if (uuidList == ""):
				uuidList += str(uuid)
			else :
				uuidList += "," + str(uuid)
		return uuidList

	def __check_evpn_resiliency(self, vrs_evpn, this_evpn_id,
		       		    max_retry_count, wait_interval):
		if (vrs_evpn.is_resilient() == True):
			return True
		resilient = False
		retries = 0
		self.vlog.info("this_evpn_id %s may be non-resilient, will recheck status %d times at %d seconds interval.." % (this_evpn_id, max_retry_count, wait_interval))
		while retries < max_retry_count:
			time.sleep(wait_interval)
			resilient = vrs_evpn.is_resilient()
			if (resilient == True):
				break
			retries = retries + 1
		return resilient

	def __run_add_del_check_evpn_sanity(self, evpn_content):
		evpn_id = str(evpn_content[0]).replace("[", "").replace("'", "")
		vrs_bridge = nuage.vrs_bridge.VRSBridge(None, self.vlog)
		br_name = vrs_bridge.get_br_name()
		vrs_evpn = nuage.vrs_evpn.VRSEvpn(br_name, evpn_id, self.vlog)
		return self.__check_evpn_resiliency(vrs_evpn, evpn_id, 5, 2)

	def __run_add(self, op, evpn_content, mac_content):
		if (self.__run_add_del_check_evpn_sanity(evpn_content) == False):
			self.vlog.info("%s: received sync %s request for "
				       "non-resilient EVPN: {%s}, ignoring"
				       %(self.dhcp_preamble, op, evpn_content))
			return
		evpn_id = str(evpn_content[0]).replace("[", "").replace("'", "")
		macUuidList = self.__mac_content_write_ovsdb(op, mac_content,
							     evpn_id)
		self.__evpn_entry_write_ovsdb(op, evpn_content, macUuidList)

	def __run_del(self, op, evpn_content, mac_content):
		if (self.__run_add_del_check_evpn_sanity(evpn_content) == False):
			self.vlog.info("%s: received sync %s request for "
				       "non-resilient EVPN: {%s}, ignoring"
				       %(self.dhcp_preamble, op, evpn_content))
			return
		macUuids = self.__mac_content_read_ovsdb_uuid(mac_content)
		macUuidList = macUuids.split(",")
		for macUuid in macUuidList:
			uuid = str(macUuid)
			self.__evpn_entry_write_ovsdb(op, evpn_content, uuid)
		evpn_id = str(evpn_content[0]).replace("[", "").replace("'", "")
		self.__mac_content_write_ovsdb(op, mac_content, evpn_id)

	def __run_add_del(self, content, add_index, del_index):
		if (add_index < del_index) :
			op_index = add_index
		elif (del_index < add_index) :
			op_index = del_index
		else :
			self.vlog.info("add_index: %d, del_index: %d, mangled payload" %(add_index, del_index))
			return
		evpn_content = content[0:op_index].replace("[","").replace("'", "").split(",")
		# remove leading "]]" and last two characters, viz. '"' and ']'
		# mac_op_list_content looks like this:
		# del:[['00:00:0c:fa:fa:6b']]add:[['00:00:0c:fa:fa:6b', '104.3.0.20', '1435170438', '300']]del:[['00:00:0c:fa:fa:69']]add:[['00:00:0c:fa:fa:6a', '105.3.0.20', '1435170572', '300']]add:[['00:00:0c:fa:fa:69', '107.3.0.20', '1435170574', '300']]
		mac_op_list_content = content[op_index + 2 : -2]

		# construct list of indices in 'mac_op_list_content' where
		# individual ops are (viz. "add" and "del")
		add_index_list = nuage.utils.findall("add",
							 mac_op_list_content)
		del_index_list = nuage.utils.findall("del",
							 mac_op_list_content)
		op_index_list = nuage.utils.list_merge(add_index_list,
							   del_index_list)
		# now for each mac and operation pair, run add or a del.
		i = 0
		while (i < len(op_index_list)):
			this_op_index = op_index_list[i]
			if (i < len(op_index_list) - 1):
				next_op_index = op_index_list[i + 1]
				this_mac_op_entry = mac_op_list_content[this_op_index:next_op_index]
			else :
				this_mac_op_entry = mac_op_list_content[this_op_index:]
			op = this_mac_op_entry.split(":")[0]
			if (op == "add"):
				this_mac_content = this_mac_op_entry + ":["
				this_mac_content = this_mac_content.split(":[")[1:]
				self.vlog.info("processing op: %s, this_mac_content: @@%s@@" % (op, this_mac_content))
				self.__run_add(op, evpn_content, this_mac_content)
			else :
				this_mac_content = this_mac_op_entry[len(op) + 1:].replace("[[", "").replace("]]", "").replace("'", "").replace(" ", "").split(",")
				self.vlog.info("processing op: %s, this_mac_content: @@%s@@" % (op, this_mac_content))
				self.__run_del(op, evpn_content, this_mac_content)
			i = i + 1
		return

	def run(self, msg):
		response = None
		payload = msg.split("::");
		this_preamble = payload[0]
		if (this_preamble != self.dhcp_preamble) :
			vlog.warn("Received bad msg with preamble %s" % this_preamble)
			return response
		this_msg = payload[1:]
		this_msg = str(this_msg).replace('["', '').replace('"]', '')
		self.preamble = this_preamble
		self.vlog.info("%s: this_msg: {%s}" %(this_preamble, this_msg))
		msg_ptr = this_msg
		this_evpn_dhcp_start_idx = 0
		done = False
		while [ True ]:
			this_evpn_dhcp_end_idx = msg_ptr.find(']][[')
			if (this_evpn_dhcp_end_idx  == -1):
				this_evpn_data = msg_ptr.splitlines()
				done = True
			else:  
				this_evpn_data = msg_ptr[:this_evpn_dhcp_end_idx + 2].splitlines()
				msg_ptr = msg_ptr[this_evpn_dhcp_end_idx + 2:]
			this_resp = self.__run(this_evpn_data)
			if (this_resp != None):
				if (response == None):
					response = this_resp
				else:
					response = str(response) + this_resp
			if (done == True):
				break
		self.__update_rgsync_stats_n_msgs_dq(self.evpn_table_name)
		return response

	def __run(self, this_msg):
		self.vlog.info("processing this_msg: {%s}" % this_msg)
		response = None
		for content in this_msg:
			# content format:
			# [['200', 'True']]add:[['96:62:f8:7c:14:fc', '91.20.20.20', '1430440820', '86400']]
			# [['200', 'False']]del:00:00:5b:06:87:a4
			# [['200', 'True']]del:[['00:00:30:06:8c:27']]add:[['00:00:30:06:8c:27', '104.1.0.10', '1433378655', '86400']]
			resync_index = content.find("[[resync")
			add_index = content.find("]]add:")
			del_index = content.find("]]del:")

			if (resync_index != -1):
				evpn_id = 0
				evpn_id_index = content.find("-evpn]]:")
				if (evpn_id_index != -1):
					evpn_id_index = evpn_id_index + len("-evpn]]:")
					evpn_id = content[evpn_id_index:]
				response = self.__run_resync(evpn_id)
			elif ((add_index != -1) and (del_index != -1)):
				self.__run_add_del(content, add_index, del_index)
			elif (add_index != -1):
				op = "add"
		 		evpn_op_content = content.split(":[")[0]
				evpn_content = evpn_op_content.split("]")[0].split(",")
				mac_content = content.split(":[")[1:]
				self.__run_add(op, evpn_content, mac_content)
			elif (del_index != -1):
				op = "del"
				evpn_content = content.split("del:")[0].split(",")
				mac_content = content.split("del:")[1:]
				self.__run_del(op, evpn_content, mac_content)
			return response

	def get_msg(self, table, evpn_id, mac_csv_list):
		msg = ""
		evpn_row = self.__evpn_entry_read_ovsdb(evpn_id, 1)
		if (evpn_row == []):
			self.vlog.info("evpn_id %s does not exist in ovsdb" %(str(evpn_id)))
			return str(msg)
		# mac_csv_list sample formats:
		# DHCP requests: one or more in quick succession
		#	add:00:00:0c:fa:fa:6b,
		#	add:00:00:0c:fa:fa:69,add:00:00:0c:fa:fa:68,
		# DHCP releases: one or more in quick succession
		#	del:00:00:0c:fa:fa:6b,
		#	del:00:00:0c:fa:fa:6b,del:00:00:0c:fa:fa:6b
		# DHCP requests and releases: one or more in quick succession
		#	del:00:00:0c:fa:fa:69,add:00:00:0c:fa:fa:6a,
		add_index = mac_csv_list.find("add:")
		del_index = mac_csv_list.find("del:")
		if ((add_index != -1) and (del_index != -1)):
			add_index_list = nuage.utils.findall("add",
								 mac_csv_list)
			del_index_list = nuage.utils.findall("del",
								 mac_csv_list)
			op_index_list = nuage.utils.list_merge(add_index_list, del_index_list)
			i = 0
			while (i < len(op_index_list)):
				this_op_index = op_index_list[i]
				if (i < len(op_index_list) - 1):
					next_op_index = op_index_list[i + 1]
					this_mac_op_entry = mac_csv_list[this_op_index:next_op_index]
				else :
					this_mac_op_entry = mac_csv_list[this_op_index:]
				op = this_mac_op_entry.split(":")[0]
				if (op == "add"):
					mac_row = self.__mac_content_read_ovsdb(this_mac_op_entry, evpn_id)
					if (mac_row == ""):
						self.vlog.info("this_mac_op_entry (%s) not found" %this_mac_op_entry)
					else:
						msg += str(mac_row)
				elif (op == "del"):
					this_mac_entry = this_mac_op_entry[len(op) + 1:].replace("[[", "").replace("]]", "").replace("'", "").replace(" ", "").replace(",", "")
					msg += "del:[[" + str(this_mac_entry) + "]]"
				else:
					self.vlog.info("mangled op (%s), ignoring" %op)
				i = i + 1
		elif (add_index != -1):
			mac_rows = self.__mac_content_read_ovsdb(mac_csv_list, evpn_id)
			if (mac_rows == ""):
				self.vlog.info("inconsistent entries between mac_csv_list and table (%s)" %mac_csv_list)
				return str(msg)
			# message format example:
			# dhcp::[['200', 'True']]add:[['96:62:f8:7c:14:fc', '91.20.20.20', '1430440820', '86400']]
			msg = str(mac_rows)
		elif (del_index != -1):
			# message format example:
			# dhcp::[['200', 'True']]del:96:62:f8:7c:14:fc
			msg = mac_csv_list
		else:
			self.vlog.info("possibly mangled mac_csv_list (%s), ignoring" % mac_csv_list)
			return str(msg)
		msg = self.dhcp_preamble + "::" + str(evpn_row) + msg
		self.vlog.info("%s: Generated message of %s bytes from table: %s, mac_csv_list: {%s}, msg: {%s}" % (self.dhcp_preamble, str(len(msg)), table, mac_csv_list, msg))
		self.__update_rgsync_stats_n_msgs_q(self.evpn_table_name)
		return str(msg)

	def get_resync_msg(self, evpn_id):
		if (evpn_id == None):
			msg = self.dhcp_preamble + "::[[resync]]:"
		else:
			msg = self.dhcp_preamble + "::[[resync-evpn]]:" + str(evpn_id)
		self.vlog.info("%s: Generated message of %s bytes {%s}" % (self.dhcp_preamble, str(len(msg)), msg))
		return str(msg)

	def __force_read_ovsdb_evpn(self, evpn_id, msg):
		self.vlog.info("read ovsdb for DHCP entries in resilient evpn_id: %s" % str(evpn_id))
		evpn_entry_ovsdb = self.__evpn_entry_read_ovsdb(str(evpn_id), 2)
		if (str(evpn_entry_ovsdb).find("set") != -1):
			set_index = str(evpn_entry_ovsdb).find("set")
			macUuidListStr = str(evpn_entry_ovsdb)[set_index + len("set' ") + 1:].replace("[", "").replace("]", "").replace('"', '').replace("u'uuid',", "").replace("u", "").replace("'", "").replace(" ", "")
		else :
			macUuidListStr = str(str(evpn_entry_ovsdb).replace("u'uuid',", "").replace("u", "").replace("']\"]]", "").split("'")[1])
			self.vlog.info("macUuidListStr: %s" %macUuidListStr)
		if (macUuidListStr == ''):
			return msg
		macUuidList = macUuidListStr.split(",")
		if (macUuidList != None):
			msg += "[['" + str(evpn_id) + "', 'True']]"
		for macUuid in macUuidList :
			mac_content = self.__mac_uuid_read_ovsdb_content(macUuid)
			if (mac_content == None or mac_content == ""):
				continue
			msg += "add:" + mac_content
		return msg

	def __force_read_ovsdb_all_evpns(self, br_name, evpnIdList, evpn_id,
		       			 msg):
		for this_evpn_id in evpnIdList :
			vrs_evpn = nuage.vrs_evpn.VRSEvpn(br_name,
			       			this_evpn_id, self.vlog)
			resilient = self.__check_evpn_resiliency(vrs_evpn,
						this_evpn_id, 5, 2)
			if (resilient == False):
				self.vlog.info("this_evpn_id %s is non-resilient, ignoring.." % this_evpn_id)
				continue
			this_evpn_id = int(this_evpn_id)
			if (evpn_id != 0):
				if (evpn_id == this_evpn_id):
					msg = self.__force_read_ovsdb_evpn(this_evpn_id, msg)
			else :
				msg = self.__force_read_ovsdb_evpn(this_evpn_id, msg)
		return msg

	def __force_read_ovsdb_all_vrfs(self, br_name, vrfIdList, evpn, msg):
		for vrf_id in vrfIdList:
			vrs_vrf = nuage.vrs_vrf.VRSVrf(br_name, vrf_id,
				       			   self.vlog)
			evpnIdList = vrs_vrf.get_evpns()
			msg = self.__force_read_ovsdb_all_evpns(br_name,
						evpnIdList, evpn, msg)
		return msg

	def __force_read_ovsdb_all(self, evpn_id):
		msg = ""
		vrs_bridge = nuage.vrs_bridge.VRSBridge(None, self.vlog)
		br_name = vrs_bridge.get_br_name()
		vrfIdList = vrs_bridge.get_vrfs()
		if (len(vrfIdList) > 0):
			msg = self.__force_read_ovsdb_all_vrfs(br_name,
						vrfIdList, evpn_id, msg)
		else:
			evpnIdList = vrs_bridge.get_evpns()
			msg = self.__force_read_ovsdb_all_evpns(br_name,
						evpnIdList, evpn_id, msg)
		return msg

	def __run_resync(self, evpn_id):
		msg = self.__force_read_ovsdb_all(evpn_id)
		if (msg == ""):
			return None
		msg = self.dhcp_preamble + "::" + msg
		self.vlog.info("%s: evpn_id: %s msg: {%s}" % (self.dhcp_preamble, str(evpn_id), msg))
		return msg
