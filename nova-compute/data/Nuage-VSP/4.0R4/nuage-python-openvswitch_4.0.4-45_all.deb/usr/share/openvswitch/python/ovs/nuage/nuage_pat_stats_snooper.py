#!/usr/bin/env python

###########################################################################
#
#   Filename:           nuage-pat-stats-update
#
#   Author:             Vinay Deore
#   Created:            Apr 2016
#
#   Description:        Script to PAT stats in ovsdb
#
###########################################################################
#
#              Copyright (c) 2016 Nuage Networks
#
###########################################################################

import errno
import os
import sys

import json
import subprocess
import operator
import copy
import re
import time
from threading import Thread

sys.path.append ('/usr/share/openvswitch/python')
sys.path.append ('/usr/share/openvswitch/python/ovs')

import ovs.json
import nuage.vlog
import nuage.utils

from pprint import pprint
from json import JSONEncoder

vlog = nuage.vlog.Vlog("nuage-pat-snooper")
STATE_FILE = "/home/root/nsg-agent/nsg-state.json"

def get_alias_from_interface (interface):
    alias = interface
    with open(STATE_FILE) as state_file:
        allstate = json.load(state_file)
        state_file.close()
    if allstate["interfaces"].get(interface, "none") != "none":
        if allstate["interfaces"][interface].get('alias', "none") != "none":
           alias = allstate["interfaces"][interface]["alias"]
    return alias

def exeCommand(cmd):
    #vlog.dbg("cmd : %s" % cmd)
    r = nuage.utils.call_prog_as_is(cmd)
    if r[0] is not 0 :
       vlog.emer ("Unable to execute: \"%s\"" % cmd)
       vlog.emer ("rc: \"%s\"" % r[0])
       vlog.emer ("out: \"%s\"" % r[1])
       vlog.emer ("err: \"%s\"" % r[2])
    return r

def getKey(map, uplink):
    if (map == "DEFAULT" or map == "MASQ" ):
        key="{'key': {'post':[{'source':'0.0.0.0/0', 'protocol':'all',  "\
            "'match':'mark match 0x2/0x3', 'out':'"+uplink+"'}]}}"
        return eval(key)
    src = map.split("=>")[0]
    dst = map.split("=>")[1]
    if (src.find(":") == -1 and src.find("-") == -1 ):
        key = "{'key': {'post':["
        for port in uplink.split(','):
            key += "{'source':'"+src+"', 'protocol':'all',  'match':'mark match 0x2/0x3', 'out':'"+port+"'},"
        key = key[:-1]
        key += "], 'pre': ["
        for port in uplink.split(','):
            key += "{'dest':'"+dst+"','protocol':'all', 'match':'', 'in':'"+port+"'},"
        key = key[:-1]
        key += "]}}"
        return eval(key)
    if (src.find("-") != -1 ):
        key = "{'key': {'post':["
        for port in uplink.split(','):
            key += "{'source':'0.0.0.0/0', 'protocol':'all',  "\
                   "'match':'source IP range "+src+" mark match 0x2/0x3', 'out':'"+port+"'},"
        key = key[:-1]
        key += "]}}"
        return eval(key)
    if (src.find(":") != -1 ):
        key = "{'key': {'post':["
        for port in uplink.split(','):
            key += "{'source':'"+src.split(':')[0]+"', 'protocol':'tcp',  "\
                   "'match':'tcp spt:"+src.split(':')[1]+" mark match 0x2/0x3', 'out':'"+port+"'},"\
                   "{'source':'"+src.split(':')[0]+"', 'protocol':'udp',  "\
                   "'match':'udp spt:"+src.split(':')[1]+" mark match 0x2/0x3', 'out':'"+port+"'},"
        key = key[:-1]
        key += "], 'pre': ["
        for port in uplink.split(','):
            key += "{'dest':'"+dst.split(':')[0]+"', 'protocol':'tcp',  "\
                   "'match':'tcp dpt:"+dst.split(':')[1]+"', 'in':'"+port+"'},{'dest':'"+dst.split(':')[0]+"', 'protocol':'udp',  "\
                   "'match':'udp dpt:"+dst.split(':')[1]+"', 'in':'"+port+"'},"
        key = key[:-1]
        key += "]}}"
        return eval(key)

def isMatch(key, entry, chain):
    #vlog.dbg ("isMatch")
    if (chain not in key['key']):
        return False
    for i in key['key'][chain]:
        matched = True
        for j in i:
            if i[j] != entry[j]:
               matched = False
               continue
        if matched:
           #vlog.dbg ("match ")
           #vlog.dbg("%s" % entry)
           return True
    #vlog.dbg ("not match ")
    return False

def update_ovsdb(map, uplink, stats):
    vlog.dbg("ovsdb-update")
    cmd = '/usr/bin/ovsdb-client transact \'["Open_vSwitch", {"op" : "update", "table" : "Nuage_PAT_stats", "where" : [[ "map", "==", "'+map+'" ], ["uplink", "==", "'+uplink+'" ]], "row" : { "egress_nbytes" : ' +str(stats[3])+', "egress_npkts" : '+str(stats[2])+', "ingress_nbytes": ' +str(stats[1])+', "ingress_npkts" : '+str(stats[0])+'} } ]\''
    vlog.dbg("%s" % cmd)
    r = exeCommand(cmd)
    vlog.dbg("ovsdb update done")

def get_chain_stats(r, map, key, uplink, chain):
    #vlog.dbg("get_chain_stats")
    stats = [0, 0]
    for entry in r['rows']:
        if isMatch(key, entry, chain):
           stats =[ stats[0] + int(entry['pkts']), stats[1] + int(entry['bytes']) ]
           vlog.dbg ("matched entry : %s" %(entry))
           if (map == "DEFAULT" or map == "MASQ" ):
               entry["match"] = "done"
               break
    return stats

def get_map_stats(post, pre, map, alias, uplink):
    vlog.dbg("---------------")
    vlog.dbg("get_map_stats ")
    vlog.dbg("map: %s, uplink: %s, alias: %s" % (map, uplink, alias))
    #stats = []
    k = getKey(map, alias)
    #vlog.dbg k
    vlog.dbg ("key : %s" %(k['key']))
    stats = get_chain_stats(pre, map, k, alias, "pre")
    stats += get_chain_stats(post, map, k, alias, "post")
    vlog.dbg("map %s, ingress-pkts: %s, ingress-bytes: %s, egress-pkts: %s, "\
          "egress-nbytes: %s" % (map, stats[0], stats[1], stats[2], stats[3]))
    update_ovsdb(map, uplink, stats)
    vlog.dbg("---------------")

def iptables_toJson(r):
    vlog.dbg("iptables_toJson")
    json_str = '{'
    json_str += "'rows':["
    rows = r[1].splitlines()
    for i in range(2, len(rows)):
        row = re.split(' {2,}', rows[i])
        match = row[len(row) -1]
        row = re.split(' {1,}', rows[i])
        json_str += "{'pkts':'"+row[1].strip()+"', 'bytes':'"+row[2].strip()+"', 'protocol':'"+row[4].strip()+""\
                    "', 'in':'"+row[6].strip()+"', 'out':'"+row[7].strip()+"', 'source':'"+row[8].strip()+""\
                    "', 'dest':'"+row[9].strip()+"', 'match':'"+match.strip()+"'},"
    if json_str.endswith(','):
       json_str = json_str[:-1]
    json_str += ']}'
    res = eval(json_str)
    vlog.dbg("res: %s" % res)
    vlog.dbg("done-iptables_toJson")
    return res

def refreshTable():
    vlog.dbg("refreshTable")
    cmd = 'iptables -t mangle -nxvL POSTROUTING_PAT_STATS'
    #cmd = 'cat post'
    postrouting_res = exeCommand(cmd)
    post = iptables_toJson(postrouting_res)
    cmd = 'iptables -t mangle -nxvL PREROUTING_PAT_STATS'
    #cmd = 'cat pre'
    prerouting_res = exeCommand(cmd)
    pre = iptables_toJson(prerouting_res)
    vlog.dbg("done-refreshTable")
    return (pre, post)

def update_pat_stats():
    vlog.dbg("update_pat_stats")
    cmd = '/usr/bin/ovsdb-client transact \'["Open_vSwitch", {"op" : "select", \
           "table" : "Nuage_PAT_stats", "where" : [] } ]\''
    r = exeCommand(cmd)
    res = json.loads(r[1])
    n = len(res[0]['rows'])
    (pre, post) = refreshTable()
    res[0]['rows'].sort(key=operator.itemgetter('map'))
    vlog.dbg ("n: %s" % n)
    for i in range(0, n):
        map = res[0]['rows'][i]['map']
        uplink = res[0]['rows'][i]['uplink']
        alias = get_alias_from_interface(uplink)
        get_map_stats(post, pre, map, alias, uplink)
    vlog.dbg("done-update_pat_stats")
    cmd = 'iptables -t mangle -Z PREROUTING_PAT_STATS'
    r = exeCommand(cmd)
    cmd = 'iptables -t mangle -Z POSTROUTING_PAT_STATS'
    r = exeCommand(cmd)

'''
def main () :
    vlog.dbg("main")
    update_pat_stats()
    vlog.dbg("done-main")
if __name__ == '__main__' :
    try :
        main ()
    except :
        sys.exit(1)
'''
