
import nuage.utils
import re

class VRSVrf(object):
	def __init__(self, br, vrf_id, vlog):
		self.appctl_path = "/usr/bin/ovs-appctl"
		self.br = br
		self.vrf_id = vrf_id
		self.vlog = vlog

	def get_evpns(self):
		evpnList = []
		cmdstr = self.appctl_path + " vrf/show " + self.br + " " + self.vrf_id + " | grep evpn-list: | awk -F: \'{print $2}\'"
		r = nuage.utils.call_prog_as_is(cmdstr)
		if r[0] is not 0 :
			self.vlog.emer("Unable to execute: \"%s\"" % cmdstr)
			self.vlog.emer("rc: \"%s\"" % r[0])
			self.vlog.emer("out: \"%s\"" % r[1])
			self.vlog.emer("err: \"%s\"" % r[2])
		else :
			evpnList = r[1].rstrip().split()
		return evpnList
