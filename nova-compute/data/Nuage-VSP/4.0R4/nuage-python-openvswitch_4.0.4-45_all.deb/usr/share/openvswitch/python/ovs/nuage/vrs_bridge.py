
import nuage.utils
import nuage.vrs_common
import re

class VRSBridge(object):
	def __init__(self, br, vlog):
		self.appctl_path = "/usr/bin/ovs-appctl"
		self.ofctl_path = "/usr/bin/ovs-ofctl"
		if (br == None):
			self.br = str(self.__set_default_bridge())
		else:
			self.br = str(br)
		self.vlog = vlog

	def __set_default_bridge(self):
		return nuage.vrs_common.get_default_bridge()

	def get_br_name(self):
		return self.br

	def get_vrfs(self):
		vrfList = []
		cmdstr = self.appctl_path + " vrf/list " + self.br + " | grep vrfs: | awk -F: \'{print $2}\'"
		r = nuage.utils.call_prog_as_is(cmdstr)
		if r[0] is not 0 :
			self.vlog.emer("Unable to execute: \"%s\"" % cmdstr)
			self.vlog.emer("rc: \"%s\"" % r[0])
			self.vlog.emer("out: \"%s\"" % r[1])
			self.vlog.emer("err: \"%s\"" % r[2])
		else :
			vrfList = r[1].rstrip().split()
		return vrfList

	def get_evpns(self):
		evpnList = []
		cmdstr = self.appctl_path + " evpn/list " + self.br + " | grep evpns: | awk -F: '{print $2}'"
		r = nuage.utils.call_prog_as_is(cmdstr)
		if r[0] is not 0 :
			self.vlog.emer("Unable to execute: \"%s\"" % cmdstr)
			self.vlog.emer("rc: \"%s\"" % r[0])
			self.vlog.emer("out: \"%s\"" % r[1])
			self.vlog.emer("err: \"%s\"" % r[2])
		else :
			evpnList = r[1].rstrip().split()
		return evpnList

	def add_flows(self, table, cookie, match, actions):
		cmdstr = self.ofctl_path + ' add-flow ' + self.br + ' ' + ' --protocol=OpenFlow13 --flow-format=any '
		if (table != None):
			cmdstr += 'table=' + table + ','
		if (cookie != None):
			cmdstr += 'cookie=' + cookie + ','
		cmdstr += match + ','
		cmdstr += 'actions=' + actions
		if (self.vlog != None):
			self.vlog.info("cmdstr: %s" %cmdstr)
		nuage.utils.call_prog_as_is(cmdstr)

	def del_flows(self, table, cookie):
		cmdstr = self.ofctl_path + ' del-flows ' + self.br + ' ' + '--protocol=OpenFlow13 --flow-format=any '
		if (table != None):
			cmdstr += 'table=' + table + ','
		cmdstr += 'cookie=' + cookie + '/-1'
		if (self.vlog != None):
			self.vlog.info("cmdstr: %s" %cmdstr)
		nuage.utils.call_prog_as_is(cmdstr)

	def dump_flows(self):
		flows = None
		cmdstr = self.appctl_path + " bridge/dump-flows " + self.br
		r = nuage.utils.call_prog_as_is(cmdstr)
		if r[0] is not 0 :
			self.vlog.emer("Unable to execute: \"%s\"" % cmdstr)
			self.vlog.emer("rc: \"%s\"" % r[0])
			self.vlog.emer("out: \"%s\"" % r[1])
			self.vlog.emer("err: \"%s\"" % r[2])
		else :
			flows = str(r[1].rstrip()).splitlines()
		return flows
