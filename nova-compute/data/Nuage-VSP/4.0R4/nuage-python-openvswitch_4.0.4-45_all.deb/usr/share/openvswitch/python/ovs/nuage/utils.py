###########################################################################
#
#   Filename:           utils
#
#   Author:             Saurabh Shrivastava
#   Created:            Feb 7 2014
#
#   Description:        utils
#
###########################################################################
#
#              Copyright (c) 2014 Nuage Networks
#
###########################################################################

import os
import re
import select
import socket
import struct
import subprocess
import argparse

import ovs.daemon
import nuage.vlog

class Cleanup :
    """ Cleanup items on exit """

    def __init__ (self, name) :
        self.name = name
        self.cleanup_items = []

    def cleanup_add (self, it, ita) :
        self.cleanup_items.append ((it,ita))
 
    def cleanup (self) :
        for i in self.cleanup_items :
            i[0](i[1])


verbose = False
program_name = ''

def call_prog (method, params, wait_time=None) :
    cmd = [method] + params.split ()
    proc = subprocess.Popen (cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    read_set = [proc.stdout, proc.stderr]
    out = []
    err = []

    while read_set :
        timeout = True
	rlist, wlist, xlist = select.select (read_set, [], [], wait_time)
	if proc.stdout in rlist :
            timeout = False
	    data = os.read (proc.stdout.fileno (), 1024)
	    if data == "" :
		proc.stdout.close ()
		read_set.remove (proc.stdout)
	    out.append (data)
	if proc.stderr in rlist :
            timeout = False
	    data = os.read (proc.stderr.fileno (), 1024)
	    if data == "" :
		proc.stderr.close ()
		read_set.remove (proc.stderr)
	    err.append (data)
	if timeout :
            raise Exception ("timeout")
    
    proc.wait ()
    out = ''.join (out)
    err = ''.join (err)
    reply = (proc.returncode, out, err)

    return reply

def call_prog_as_is (cmd, wait_time=None) :
    proc = subprocess.Popen (cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    read_set = [proc.stdout, proc.stderr]
    out = []
    err = []

    while read_set :
        timeout = True
        try:
            rlist, wlist, xlist = select.select (read_set, [], [], wait_time)
        except select.error  as ex:
            if (ex[0] == 4):
                continue
	if proc.stdout in rlist :
            timeout = False
	    data = os.read (proc.stdout.fileno (), 1024)
	    if data == "" :
		proc.stdout.close ()
		read_set.remove (proc.stdout)
	    out.append (data)
	if proc.stderr in rlist :
            timeout = False
	    data = os.read (proc.stderr.fileno (), 1024)
	    if data == "" :
		proc.stderr.close ()
		read_set.remove (proc.stderr)
	    err.append (data)
	if timeout :
            raise Exception ("timeout")
    
    proc.wait ()
    out = ''.join (out)
    err = ''.join (err)
    reply = (proc.returncode, out, err)

    return reply

def print_error (err) :
    global program_name
    print "%s: error: %s" % (program_name, err)

def print_verbose (msg, start=None) :
    global verbose
    if verbose :
        if start is None :
            d = ''
        else : 
            if start :
                d = "<!--"
            else :
                d = "--->"
        print "%s%s" % (d,msg)

def mac2hex (mac) : 
    return mac.replace (':','')

def ip2hex (ip) :
    return "%x" % struct.unpack ("!L", socket.inet_aton (ip))[0]

def mac_check (mac) :
    ok = True
    m = re.match ("^([0-9A-F]{2}[:]){5}([0-9A-F]{2})$", mac, re.I)
    if m is None :
        ok = False
    if not ok :
        msg = "mac should be of the form XX:XX:XX:XX:XX:XX"
        raise argparse.ArgumentTypeError(msg)
    return mac

def ip_hostname_check(host):
    hostwithoutdot = host.replace(".","")
    # must be IP
    if hostwithoutdot.isdigit():
        return ip_check(host)
    # must be hostname
    else:
        return host

def ip_check (ip) :
    ok = True
    m = re.match ("^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$", ip, re.I)
    if m is None :
        ok = False
    else :
        for ii in m.groups() :
            if int(ii) > 255 :
                ok = False
                break
    if not ok :
        msg = "ip should be a dotted quad"
        raise argparse.ArgumentTypeError(msg)
    return ip


def port_check (port) :
    ok = True
    p = int(port)
    if p < 1 or p > 65535 :
        ok = False
    if not ok :
        msg = "port should be in the range 1..65535"
        raise argparse.ArgumentTypeError(msg)
    return p


def str_to_bool (meta_insecure):
    ua = str(meta_insecure).upper()
    if ua == 'TRUE'[:len(ua)]:
       return True
    elif ua == 'FALSE'[:len(ua)]:
       return False
    else:
       return meta_insecure

    
def subprocess_do (ac2) :
    print_verbose ("Command start: %s" % ' '.join(ac2), True)
    p = subprocess.Popen(ac2, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (out,err) = p.communicate ()
    ret = p.returncode 
    print_verbose ("Command output ..", True)
    print_verbose (out)
    print_verbose ("Command output done", False)
    print_verbose ("Command error ..", True)
    print_verbose (err)
    print_verbose ("Command error done", False)
    print_verbose ("Command end, ret=%d: %s" % (ret,' '.join(ac2)), False)
    if ret != 0 :
        err_str = "Command failed '%s', returned %d, err '%s'" % (' '.join(ac2),ret,err)
        print_error (err_str)
        raise Exception (err_str)
    return out

def re_do (pat, str) :
    p = re.compile (r'%s'%(pat), re.DOTALL)
    r = [m.groupdict() for m in p.finditer(str)]
    return r

def re_do_line (pat, str) :
    p = re.compile (r'%s'%(pat), re.DOTALL)
    r = []
    for l in str.splitlines() :
        m = p.search(l)
        if m : r.append(m.groupdict())
    return r

def parse_ovs_dpctl_show (port_num) :
    print_verbose ("Translating %s" % (port_num), True)
    '''
    system@ovs-system:
	lookups: hit:65 missed:57 lost:0
	flows: 0
	port 0: ovs-system (internal)
	port 1: alubr0 (internal)
	port 2: vxlan_sys_4789 (vxlan: df_default=false, ttl=0)
	port 3: tap12f3546c-d4
	port 4: tape7fc6279-8e
    '''
    ac2 = ['ovs-dpctl', 'show']
    out = subprocess_do (ac2)

    reg = (''
           'port\s*(?P<portnum>\S+):\s*(?P<portname>\S+)\s*(\(internal\)|\((?P<type>\S+):.*?key=(?P<key>\S+),.*?remote_ip=(?P<remoteip>\S+),.*?\))?'
           '')
    g = re_do_line (reg,out)

    name = 'none'
    for i in g :
       if i['portnum'] == port_num :
           if i['remoteip'] is not None :
               name = '%s with %s:%s' % (i['remoteip'],i['type'],i['key'])
           else :
               name = i['portname']
           break 

    print_verbose ("Translated %s, name=%s" % (port_num,name), False)
    return name 

 
def parse_ovs_ofctl_show (bridge_name, port_name=None, port_num=None) :
    print_verbose ("Translating %s, %s" % (port_name, port_num), True)
    '''
    1(vnet0): addr:fe:e1:15:38:02:02
        config:     0
        state:      0
        current:    10MB-FD COPPER
    '''
    if port_name == None :
        port_name = 'none'
    if port_num == None :
        port_num = 'none'

    ac2 = ['ovs-ofctl', 'show', bridge_name]
    out = subprocess_do (ac2)
  
    reg = (''
           '(?P<portnum>\S+)\((?P<portname>\S+)\):.*?addr:(?P<mac>\S+)'
           '')
    g = re_do (reg,out)
 
    mac = 'none'
    for i in g :
       if i['portname'] == port_name or i['portnum'] == port_num :
           port_num = i['portnum']
           if port_num == 'LOCAL' : port_num = '0'
           port_name = i['portname']
           mac = i['mac']
           break 
       
    print_verbose ("Translated port_name=%s port_num=%s mac=%s" % (port_name,port_num,mac), True)
    return (port_name,port_num,mac)


def parse_ovs_appctl_vm_port_show (vport_name) :
    print_verbose ("Translating %s" % (vport_name), True)
    '''
Name: instance-vm-0000029e	UUID: 302867a6-ec35-4f2b-afa8-9764ff8d11dd
		Name: tap6c06bf94-b0	MAC: fa:16:3e:4c:37:4d
	Bridge: alubr0	port: 9	flags: 0x0	stats-interval: 60
	vrf_id: 20358	evpn_id: 20359	flow_flags: 0x1660200	flood_gen_id: 0x1
	IP: 10.33.33.4	subnet: 255.255.255.0	GW: 10.33.33.1
	rate: 0	burst:0	class:0	mac_count: 1
	RX packets:8 errors:0 dropped:6 rl_dropped:0 
	TX packets:2 errors:0 dropped:0
	RX bytes:1124      TX bytes:644

		Name: tap943c94f4-b8	MAC: fa:16:3e:aa:d0:b8
	Bridge: alubr0	port: 8	flags: 0x0	stats-interval: 60
	vrf_id: 20341	evpn_id: 20342	flow_flags: 0x1660200	flood_gen_id: 0x1
	IP: 10.20.20.79	subnet: 255.255.255.0	GW: 10.20.20.1
	rate: 0	burst:0	class:0	mac_count: 1
	RX packets:243 errors:0 dropped:7 rl_dropped:0 
	TX packets:235 errors:0 dropped:0
	RX bytes:25069      TX bytes:22570

    '''
    ac2 = ['ovs-appctl', 'vm/port-show']
    out = subprocess_do (ac2)

    res = ('('
           '\s*Name:\s*\S+\s*UUID:'
           '.*?'
           '(?=\s*Name:\s*\S+\s*UUID:)'
           ')')
           
    reg1 = (''
           'Name:\s*(?P<vmname>\S+).*?UUID:\s*(?P<uuid>\S+)\s*'
           '(?P<remaining>.*)'
           '')

    reg2 = ('('
           '.*?Name:\s*(?P<portname>\S+).*?MAC:\s*(?P<mac>\S+).*?'
           '.*?Bridge:\s*(?P<bridge>\S+).*?'
           '.*?vrf_id:\s*(?P<vrf>\S+).*?evpn_id:\s*(?P<evpn>\S+).*?'
           '.*?IP:\s*(?P<ip>\S+).*?subnet:\s*(?P<subnet>\S+).*?GW:\s*(?P<gw>\S+)'
           ')')

    
    uuid = 'none'
    vrf_id = 'none'
    evpn_id = 'none'
    mac = '00:00:00:00:00:00'
    ip = '000.000.000.000'

    resout = re.split (res,out.replace ('\n', ' '))

    done = False
    for r in resout :
        if done : break
        if r == '' : continue
        g1 = re_do (reg1,r)
        g2 = re_do (reg2,g1[0]['remaining'])
        for i in g2 :
            if done : break
            if i['portname'] == vport_name :
                uuid = g1[0]['uuid']
                vrf_id = i['vrf']
                evpn_id = i['evpn']
                mac = i['mac']
                ip = i['ip']
                done = True 

    print_verbose ("Translated %s, uuid=%s vrf_id=%s evpn_id=%s mac=%s ip=%s" % 
                   (vport_name,uuid,vrf_id,evpn_id,mac,ip), False)
    return (uuid, vrf_id, evpn_id, mac, ip)

def process_args(cmd_description, cmds_list, group_description, debug_env_var,
		 argv, daemonize):
	parser = argparse.ArgumentParser(description = cmd_description,
		formatter_class = argparse.RawDescriptionHelpFormatter)
	group = parser.add_argument_group(title="Commands",
			description=group_description)
	group.add_argument('command', metavar="COMMAND",
			   nargs=1, choices=cmds_list,
			   help="Command to use.")
	group.add_argument('command_args', metavar="ARG", nargs='*',
			   help="Arguments to COMMAND.")

	vlog = nuage.vlog.Vlog (ovs.util.PROGRAM_NAME)
	nuage.vlog.add_args (parser)
	if (daemonize == True):
		ovs.daemon.add_args(parser)
	args = parser.parse_args ()
	args.log_file = "%s/%s.log" % (ovs.dirs.LOGDIR, ovs.util.PROGRAM_NAME)
	debug_flag = [ debug_env_var ]
	if (debug_flag == '0') :
		args.verbose = [["any:console:emer"], ["any:syslog:err"], ["any:file:err"]]
	else :
		args.verbose = [["any:console:emer"], ["any:syslog:err"], ["any:file:info"]]
	nuage.vlog.handle_args(args)
	if (daemonize == True):
		ovs.daemon.handle_args(args)

	command_name = args.command [0]
	args = args.command_args
	if not command_name in cmds_list :
		vlog.emer("%s: unknown command \"%s\" (use --help for help)" % (argv [0], command_name))
		sys.exit(1)
	func, n_args = cmds_list[command_name]
	if type (n_args) == tuple and len (args) < n_args [0] :
		vlog.emer ("%s: \"%s\" requires at least %d arguments but only %d provided\n" % (argv [0], command_name, n_args, len(args)))
		sys.exit(1)
	elif type (n_args) == int and len (args) != n_args :
		vlog.emer ("%s: \"%s\" requires %d arguments but %d provided\n" % (argv [0], command_name, n_args, len(args)))
		sys.exit(1)
	func(vlog, argv[2:])

def all_procs():
	ps = subprocess.Popen("ps ax -o pid= -o args= ", shell=True, stdout=subprocess.PIPE)
	ps_pid = ps.pid
	output = ps.stdout.read()
	ps.stdout.close()
	ps.wait()
	return output, ps_pid

def proc_exists(proc_name):
	output, ps_pid = all_procs()
	for line in output.split("\n"):
		res = re.findall("(\d+) (.*)", line)
		if res:
			pid = int(res[0][0])
			this_proc = res[0][1].split(" ")[0:2]
			if ((proc_name in this_proc[0] or
		            (len(this_proc) > 1 and
			     (this_proc[0].find("sh") != -1 or
			      this_proc[0].find("python") != -1) and
			     proc_name in this_proc[1])) and
			    pid != os.getpid() and pid != os.getppid() and
			    pid != ps_pid):
				return True
	return False

def n_procs_by_name(proc_name):
	output, ps_pid = all_procs()
	n_procs = 0
	for line in output.split("\n"):
		res = re.findall("(\d+) (.*)", line)
		if res:
			pid = int(res[0][0])
			this_proc = res[0][1].split(" ")[0:2]
			if ((proc_name in this_proc[0] or
		            (len(this_proc) > 1 and
			     (this_proc[0].find("sh") != -1 or
			      this_proc[0].find("python") != -1) and
			     proc_name in this_proc[1])) and
			    pid != os.getpid() and pid != os.getppid() and
			    pid != ps_pid):
				n_procs = n_procs + 1
	return n_procs

def killall_procs_by_name(proc_name):
	output, ps_pid = all_procs()
	for line in output.split("\n"):
		res = re.findall("(\d+) (.*)", line)
		if res:
			pid = int(res[0][0])
			this_proc = res[0][1].split(" ")[0:2]
			if ((proc_name in this_proc[0] or
		            (len(this_proc) > 1 and
			     (this_proc[0].find("sh") != -1 or
			      this_proc[0].find("python") != -1) and
			     proc_name in this_proc[1])) and
			    pid != os.getpid() and pid != os.getppid() and
			    pid != ps_pid):
				call_prog_as_is("/bin/kill -9 " + str(pid))

def findall(sub, string):
	index = 0
	indexList = []
	while index < len(string):
		index = string.find(sub, index)
		if index == -1:
			break
		indexList.append(index)
		index += len(sub)
	return indexList

def list_merge(list1, list2):
	ret = []
	while list1 and list2:
		if list1[-1] > list2[-1]:
			ret.append(list1.pop(-1))
		else:
			ret.append(list2.pop(-1))
	ret.reverse()
	return list1 + list2 + ret
