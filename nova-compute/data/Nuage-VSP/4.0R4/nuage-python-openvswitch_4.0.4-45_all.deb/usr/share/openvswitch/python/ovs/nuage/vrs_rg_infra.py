
import sys
import subprocess
import re
import random
import time
sys.path.append ('@pkgdatadir@/python')
sys.path.append ('@pkgdatadir@/python/ovs')
import nuage.vlog
import nuage.utils
import ovs.dirs
import ovs.util
import nuage.vrs_common
import nuage.vrs_bridge
from xml.dom.minidom import Document

class Rg(object):
	db = "Open_vSwitch"
	table = "Vrs_Resiliency_Group_Sync_Infra"
	def __init__(self, vlog):
		self.vlog = vlog
		self.ofctl_path = "/usr/bin/ovs-ofctl"
		self.appctl_path = "/usr/bin/ovs-appctl"
		self.vsctl_path = "/usr/bin/ovs-vsctl"
		self.rgctl_path = "/usr/sbin/vrs-rgctl"
		self.__set_default_bridge()
		self.set_rg_bridge()

	def __set_default_bridge(self):
		self.default_bridge = nuage.vrs_common.get_default_bridge( )

	def set_rg_bridge(self):
		cmdstr = self.vsctl_path + " --format=csv list bridge " + self.default_bridge + " | grep gw-hb-br | awk -F\"gw-hb-br\" \'{print $2}\' | awk \'{print $1}\' | sed \'s/\"\"//g\' | sed \'s/=//g\' | sed \'s/,//g\'"
		r = nuage.utils.call_prog_as_is(cmdstr)
		if r[0] is not 0 :
			self.vlog.emer("Unable to execute: \"%s\"" % cmdstr)
			self.vlog.emer("rc: \"%s\"" % r[0])
			self.vlog.emer("out: \"%s\"" % r[1])
			self.vlog.emer("err: \"%s\"" % r[2])
			self.rg_bridge = ""
		else :
			self.rg_bridge = r[1].rstrip()

class PortRg(Rg):
	def __init__(self, vlog, port_name):
		self.port_name = port_name
		super(PortRg, self).__init__(vlog)

	def stop(self):
		bridge = nuage.vrs_common.get_default_bridge()
		self.del_rg_flows(None, None, bridge)

	def __get_port_data(self, port_type):
		resilient = "false"
		resiliency_state = "none"
		cmdstr = self.ofctl_path + " dump-rgs " + self.default_bridge + " | grep " + port_type
		r = nuage.utils.call_prog_as_is(cmdstr)
		if (r == ""):
			return resilient, resiliency_state
		ofctl_out = r[1].rstrip()
		rg_entries = ofctl_out.split('\n')
		rg_list = []
		for rg in rg_entries :
			rg_list.append(rg.split(' '))
		for rg in rg_list :
			port_name = rg[0]
			if (port_name != self.port_name) :
				continue
			resilient = "true"
			resiliency_state = rg[-1]
			break
		return resilient, resiliency_state

	def __dump_xml_key_value(self, port_xml, xml_doc, key, value) :
		node = xml_doc.createElement(key)
		port_xml.appendChild(node)
		text = xml_doc.createTextNode(value)
		node.appendChild(text)

	def dump_xml(self, port_type, port_xml, xml_doc):
		resilient, resiliency_state = self.__get_port_data(port_type)
		self.__dump_xml_key_value(port_xml, xml_doc,
					  "resilient", resilient)
		self.__dump_xml_key_value(port_xml, xml_doc,
					  "resiliency_state", resiliency_state)
	
	def get_rg_role(self):
		cfg_role = ""
		cur_role = ""
		if (self.port_name == ''):
			return cfg_role, cur_role
		cmdstr = self.rgctl_path + " port/show-rg --access-port=" + self.port_name + " | grep " + self.port_name + ' | grep -v "unable to find"'
		r = nuage.utils.call_prog_as_is(cmdstr)
		if (r == ""):
			return cfg_role, cur_role
		rgctl_out = r[1].rstrip()
		rgctl_out = re.sub("\s\s+" , " ", rgctl_out)
		if (rgctl_out == "") or (rgctl_out == None):
			return cfg_role, cur_role
		cfg_role = rgctl_out.split(" ")[2]
		cur_role = rgctl_out.split(" ")[4]
		return cfg_role, cur_role

	def get_rg_state(self) :
		rg_state = "down"
		if (self.port_name == ''):
			return rg_state
		cmdstr = self.rgctl_path + " port/show-rg --access-port=" + self.port_name + " | grep " + self.port_name + ' | grep -v "unable to find"'
		r = nuage.utils.call_prog_as_is(cmdstr)
		if (r == ""):
			return rg_state
		rgctl_out = r[1].rstrip()
		rgctl_out = re.sub("\s\s+" , " ", rgctl_out)
		if (rgctl_out == "") or (rgctl_out == None):
			return rg_state
		rg_state = rgctl_out.split(" ")[9]
		return rg_state

	def is_rg_configured(self):
		cmdstr = self.rgctl_path + " port/show-rg --access-port=" + self.port_name + " | grep " + self.port_name + ' | grep "unable to find"'
		r = nuage.utils.call_prog_as_is(cmdstr)
		if (r[0] == 0):
			return False
		else:
			return True

	def get_rg_ofport(self):
		cmd = self.appctl_path + " dpif/show | grep " + self.port_name
		r = nuage.utils.call_prog_as_is(cmd)
		if (r[1] == ""):
			return ""
		ofp_port = r[1].rstrip().split()[1].replace(":", "").split("/")[0]
		return ofp_port

	def get_mac(self):
		ip_addr_show_out = []
		cmdstr = "ip addr show " + self.port_name
		r = nuage.utils.call_prog_as_is(cmdstr)
		if r[0] is not 0 :
			return None
		else :
			ip_addr_show_out = str(r[1].rstrip())
		macstr_index = ip_addr_show_out.find("link/ether ")
		if (macstr_index == -1):
			return None
		macstr_index = macstr_index + len("link/ether ")
		mac_addr = str(ip_addr_show_out[macstr_index:].split()[0])
		return mac_addr

	def add_rg_flows(self, table, cookie, bridge, local_ip, remote_ip,
		       	 ofp_port_1, ofp_port_2, port_mac):
		if (cookie == None):
			cookie = str(random.randint(1, 0xffffffff))
		self.vlog.info("Adding flows - table: %s, cookie: %s, bridge: %s, local_ip: %s, remote_ip: %s, ofp_port_1: %s, ofp_port_2: %s" % (table, cookie, bridge, local_ip, remote_ip, ofp_port_1, ofp_port_2))
		vrs_bridge = nuage.vrs_bridge.VRSBridge(bridge, self.vlog)
		if (bridge == self.rg_bridge):
			match = 'arp,nw_dst=' + local_ip
			actions = ofp_port_2
			vrs_bridge.add_flows(table, cookie, match, actions)
			match = 'arp,in_port=' + ofp_port_2 + ',nw_dst=' + remote_ip
			actions = ofp_port_1
			vrs_bridge.add_flows(table, cookie, match, actions)
		if (bridge == self.rg_bridge):
			match = 'ip,nw_dst=' + local_ip
		else:
			match = 'priority=65535,ip,nw_dst=' + local_ip
		if (port_mac == None):
			actions = ofp_port_2
		else:
			actions = "mod_dl_dst:" + port_mac + "," + ofp_port_2
		vrs_bridge.add_flows(table, cookie, match, actions)
		if (bridge == self.rg_bridge):
			match = 'ip,in_port=' + ofp_port_2 + ',nw_dst=' + remote_ip
		else:
			match = 'priority=65535,ip,in_port=' + ofp_port_2 + ',nw_dst=' + remote_ip
		actions = ofp_port_1
		vrs_bridge.add_flows(table, cookie, match, actions)
		if (bridge == self.rg_bridge):
			match = 'priority=0'
			actions = ""
			vrs_bridge.add_flows(table, cookie, match, actions)
		return cookie

	def __del_rg_all_flows(self, vrs_bridge):
		flowList = vrs_bridge.dump_flows()
		for flow in flowList:
			flow = str(flow)
			rg_untagged_flow = flow.find("169.254.1")
			if (rg_untagged_flow == -1):
				continue
			cookie_str_index = flow.find("cookie:")
			if (cookie_str_index == -1):
				continue
			cookie_str_index = cookie_str_index + len("cookie:")
			cookie = str(flow[cookie_str_index:].split()[0])
			vrs_bridge.del_flows(None, cookie)

	def del_rg_flows(self, table, cookie, bridge):
		self.vlog.info("Deleting flows - cookie: %s, table: %s, bridge: %s" % (cookie, table, bridge))
		vrs_bridge = nuage.vrs_bridge.VRSBridge(bridge, self.vlog)
		if (cookie == None):
			self.__del_rg_all_flows(vrs_bridge)
		else:
			vrs_bridge.del_flows(table, cookie)

	def disable_ipv6(self):
		port_name_ipv6_node = self.port_name.replace(".", "/")
		self.vlog.info("Disabling IPv6 traffic for " + port_name_ipv6_node)
		cmd = "sysctl -w net.ipv6.conf." + port_name_ipv6_node + ".disable_ipv6=1"
		nuage.utils.call_prog_as_is(cmd)

	def get_rg_cfg_attr(self, attr):
		if (self.port_name == ''):
			return ''
		cmdstr = self.vsctl_path + " --format=csv list interface | grep " + self.port_name + " | grep -v @"
		r = nuage.utils.call_prog_as_is(cmdstr)
		if (r == ""):
			return ''
		vsctl_out = r[1].rstrip()
		entries = vsctl_out.split(',')
		for e in entries:
			kvpair = str(e.split("=")).replace('"{', '').replace('"}', '').replace('""', '').replace(' ', '').replace("[", '').replace("]",'')
			if (kvpair.find("','") == -1):
				continue
			key = kvpair.split(",")[0]
			value = kvpair.split(",")[1]
			this_key = "'" + attr + "'"
			if (key != this_key):
				continue
			return value.replace("'", "")
		return ''

class GatewayRg(Rg):
	def __init__(self, vlog):
		super(GatewayRg, self).__init__(vlog)
		self.rg_flow_cookie = None

	def stop(self):
		access_port, local_ip, remote_ip = self.get_rg_ipaddrs()
		self.clear_rgsync_stats(access_port)
		self.disconnect_rg_peer(access_port, local_ip, remote_ip)

	def is_rg_peer_untagged(self, remote_ip):
		if (remote_ip.find("169.254.1") >= 0):
			return True
		else:
			return False

	def __get_port_list(self, port_type):
		cmdstr = self.ofctl_path + " dump-rgs " + self.default_bridge + " 2> /dev/null | grep " + port_type
		r = nuage.utils.call_prog_as_is(cmdstr)
		if (r == ""):
			return resilient, resiliency_state
		ofctl_out = r[1].rstrip()
		rg_entries = ofctl_out.split('\n')
		rg_list = []
		for rg in rg_entries :
			rg_list.append(rg.split(' '))
		pList = []
		for rg in rg_list :
			this_port_name = rg[0]
			pList.append(this_port_name)
		return sorted(pList)

	def get_rg_ipaddrs(self):
		local_ip = ""
		remote_ip = ""
		ap = ""
		apList = self.__get_port_list("Access")
		for ap in apList:
			port_rg = PortRg(self.vlog, ap)
			state = port_rg.get_rg_state()
			if (state != "up") :
				continue
			local_ip = port_rg.get_rg_cfg_attr("bfd_src_ip") 
			remote_ip = port_rg.get_rg_cfg_attr("bfd_dst_ip") 
			if (local_ip and local_ip != "0.0.0.0" and
			    remote_ip and remote_ip != "0.0.0.0"):
				break
		return ap, local_ip, remote_ip

	def get_num_rg_ports(self):
		apList = self.__get_port_list("Access")
		n_rgs = 0
		n_rgs_up = 0
		for ap in apList:
			n_rgs = n_rgs + 1
			port_rg = PortRg(self.vlog, ap)
			state = port_rg.get_rg_state()
			if (state == "up") :
				n_rgs_up = n_rgs_up + 1
		return n_rgs, n_rgs_up

	def __get_rg_gw_hb_vlan(self, iface):
		cmd = "vrs-rgctl port/show-rg --access-port=" + iface + " | grep " + iface + " | awk '{print $2}'"
		r = nuage.utils.call_prog_as_is(cmd)
		if r[0] is not 0 :
			self.vlog.info("vrs-rgctl command failed {%s}" % r[1])
			return False
		gw_hb_vlan = str(r[1].rstrip())
		return gw_hb_vlan

	def __get_rg_iface_info(self, iface):
		gw_hb_vlan = self.__get_rg_gw_hb_vlan(iface)
		if (gw_hb_vlan == ""):
			rg_iface = ""
		elif (gw_hb_vlan != "0"):
			self.set_rg_bridge()
			rg_iface = self.rg_bridge
		else :
			rg_iface = iface + "-svc"
		return rg_iface, gw_hb_vlan

	def __config_rg_iface_ip_route(self, iface, remote_ip, verbose):
		ip_octets = remote_ip.split(".")
		subnet = ip_octets[0] + "." + ip_octets[1] + "." + ip_octets[2] + "." + "0"
		cmd = "ip route add " + subnet + "/24 dev " + iface 
		r = nuage.utils.call_prog_as_is(cmd)
		if r[0] is not 0 :
			if (verbose == True):
				self.vlog.info("ip route add failed {%s}" % r[1])
		 	return False
		return True

	def __config_rg_iface_ip(self, iface, local_ip, remote_ip):
		cmd = "ip addr add " + local_ip + " dev " + iface
		r = nuage.utils.call_prog_as_is(cmd)
		if r[0] is not 0 :
			self.vlog.info("ip addr config failed {%s}" % r[1])
			return False
		cmd = "ip link set dev " + iface + " up"
		r = nuage.utils.call_prog_as_is(cmd)
		if r[0] is not 0 :
			self.vlog.info("Interface link up failed {%s}" % r[1])
	 		return False
		return self.__config_rg_iface_ip_route(iface, remote_ip, True)

	def __config_rg_iface(self, iface, local_ip, port, remote_ip):
		if (local_ip == '' or iface == '') :
			return False
		rg_iface, gw_hb_vlan = self.__get_rg_iface_info(iface)
		if (rg_iface == ""):
			self.vlog.info("Unable to obtain resiliency iface for %s" % iface)
			return False
		if (gw_hb_vlan != "0"):
			rc = self.__config_rg_iface_ip(rg_iface, local_ip,
						       remote_ip)
			if (rc == False):
				return False
			port_rg = PortRg(self.vlog, iface + "." + gw_hb_vlan)
			rg_ofp_port = port_rg.get_rg_ofport()
			port_rg_iface = PortRg(self.vlog, rg_iface)
			rg_port_mac = port_rg_iface.get_mac()
			self.rg_flow_cookie = port_rg.add_rg_flows(None, None,
					self.rg_bridge, local_ip,
					remote_ip, rg_ofp_port, "LOCAL",
					rg_port_mac)
			port_rg.disable_ipv6()
		else:
			cmd = "ovs-vsctl add-port " + self.default_bridge + " " + rg_iface + " -- set interface " + rg_iface + " type=internal other_config:proxy_arp=enable"
			r = nuage.utils.call_prog_as_is(cmd)
			if r[0] is not 0 :
				self.vlog.info("ovs-vsctl add-port failed {%s}" % r[1])
		 		return False
			rc = self.__config_rg_iface_ip(rg_iface, local_ip,
						       remote_ip)
			if (rc == False):
				return False
			port_rg = PortRg(self.vlog, iface)
			dp_ofp_port = port_rg.get_rg_ofport()
			port_rg = PortRg(self.vlog, rg_iface)
			rg_ofp_port = port_rg.get_rg_ofport()
			rg_port_mac = port_rg.get_mac()
			self.rg_flow_cookie = port_rg.add_rg_flows(None, None,
				self.default_bridge, local_ip, remote_ip,
				dp_ofp_port, rg_ofp_port, rg_port_mac)
			port_rg.add_rg_flows("4", self.rg_flow_cookie,
				self.default_bridge, local_ip, remote_ip,
				dp_ofp_port, rg_ofp_port, rg_port_mac)
		cmd = 'iptables -L | grep "tcp dpt:' + str(port) + '"'
		r = nuage.utils.call_prog_as_is(cmd)
		rule_exists = r[0]
		if (rule_exists == 0) :
			self.vlog.info("input rule already exists")
		else :
			cmd = "iptables -I INPUT 1 -p tcp --dport " + str(port) + " -j ACCEPT"
			r = nuage.utils.call_prog_as_is(cmd)
			if r[0] is not 0 :
				self.vlog.info("input config failed {%s}" % r[1])
		 		return False
		self.vlog.info("__config_rg_iface: iface: %s, rg_iface %s, gw_hb_vlan: %s" %(iface, rg_iface, gw_hb_vlan))
		return True

	def __deconfig_rg_iface_ip(self, iface, local_ip, remote_ip):
		ip_octets = remote_ip.split(".")
		subnet = ip_octets[0] + "." + ip_octets[1] + "." + ip_octets[2] + "." + "0"
		cmd = "ip route del " + subnet + "/24 dev " + iface 
		r = nuage.utils.call_prog_as_is(cmd)
		if r[0] is not 0 :
			self.vlog.info("ip route del failed {%s}{%s}" %(cmd,r[2]))
		cmd = "ip addr del " + local_ip + "/32  dev " + iface
		r = nuage.utils.call_prog_as_is(cmd)
		if r[0] != 0 :
			self.vlog.info("ip addr deconfig failed {%s}{%s}" %(cmd,r[2]))
	def __deconfig_rg_iface_ip_tables(self):
		cmd = "iptables -vnL --line-numbers | grep dpt:65535 | awk '{print $1}'"
		r = nuage.utils.call_prog_as_is(cmd)
		if r[0] != 0 :
			self.vlog.info("input rule config failed {%s}{%s}" %(cmd,r[2]))
		else:
			rule_num = str(r[1].rstrip())
			cmd = "iptables -D INPUT " + rule_num
			r = nuage.utils.call_prog_as_is(cmd)
			if r[0] != 0 :
				self.vlog.info("input rule deconfig failed {%s}{%s}" %(cmd,r[2]))
		return

	def __deconfig_rg_iface(self, iface, local_ip, remote_ip):
		self.__deconfig_rg_iface_ip_tables()
		if (local_ip == '' or iface == ''):
			return False
		rg_iface, gw_hb_vlan = self.__get_rg_iface_info(iface)
		if (rg_iface == ""):
			self.vlog.info("Unable to obtain resiliency iface for %s" % iface)
			return False
		if (gw_hb_vlan != "0"):
			port_rg = PortRg(self.vlog, iface + "." + gw_hb_vlan)
			self.__deconfig_rg_iface_ip(rg_iface, local_ip, remote_ip)
		else :
			port_rg = PortRg(self.vlog, iface)
			port_rg.del_rg_flows(None, self.rg_flow_cookie,
					     self.default_bridge)
			self.__deconfig_rg_iface_ip(rg_iface, local_ip, remote_ip)
			cmd = "ovs-vsctl del-port " + rg_iface
			r = nuage.utils.call_prog_as_is(cmd)
			if r[0] is not 0 :
				self.vlog.info("ovs-vsctl del-port failed {%s}" % r[1])
		self.vlog.info("__deconfig_rg_iface: iface: %s, rg_iface %s, gw_hb_vlan: %s" %(iface, rg_iface, gw_hb_vlan))
		return True

	def connect_rg_peer(self, access_port, local_ip, port, remote_ip):
		self.__deconfig_rg_iface(access_port, local_ip, remote_ip)
		return self.__config_rg_iface(access_port, local_ip, port,
					      remote_ip)

	def disconnect_rg_peer(self, access_port, local_ip, remote_ip):
		return self.__deconfig_rg_iface(access_port, local_ip, remote_ip)

	def is_rg_peer_alive(self, port_name, remote_ip, n_pkts):
		if (remote_ip == ''):
			return
		if (remote_ip.find("169.254.1") == -1):
			cmd = "/bin/ping -c1 -w" + str(n_pkts) + " " + remote_ip
		else:
			iface = port_name + "-svc"
			self.__config_rg_iface_ip_route(iface, remote_ip, False)
			cmd = "/bin/ping -c1 -w" + str(n_pkts) + " " + remote_ip + " -I " + iface
		r = nuage.utils.call_prog_as_is(cmd)
		if r[0] == 0 :
			return True
		else :
			return False

	def is_rg_peer_alive_retries(self, port_name, remote_ip, int_secs,
				     n_ints):
		retries = 0
		alive = False
		while retries < n_ints:
			retries = retries + 1
			self.vlog.info("waiting int_secs (%d secs) for connection to establish, retries: %d of %d" %(int_secs, retries, n_ints))
			time.sleep(int_secs)
			alive = self.is_rg_peer_alive(port_name, remote_ip, 2)
			if (alive == True):
				self.vlog.info("remote peer %s is alive" %remote_ip)
				break
		return alive

	def __clear_rgsync_port_stats(self, rgsync_infra_tbl, access_port):
		if (access_port == ""):
			cols = [ "vrgsi_iface" ]
			read_row = rgsync_infra_tbl.get_cols_all_rows(cols)
			read_row = str(read_row).replace("[", "").replace("]", "").replace("'", "").split(",")
			access_port = read_row[0].replace(" ", "")
		row = '[[ "vrgsi_iface", "==", "' + access_port + '" ]]'
		rgsync_infra_tbl.delete_row(row)

	def __commit_rgsync_stats(self, rgsync_infra_tbl, read_row,
				  access_port, local_ip, port_num,
				  remote_ip, total_hb_misses,
				  last_hb_miss_time):
		write_row = '{ "vrgsi_iface" : "' + access_port + '", "vrgsi_peer" : "' + remote_ip + '", "vrgsi_local_ip" : "' + local_ip + '", "vrgsi_port_num" : "' + str(port_num) + '", "vrgsi_hb_misses" : "' + str(total_hb_misses) + '", "vrgsi_hb_miss_time" : "' + last_hb_miss_time + '" }'
		if (read_row == []):
			rgsync_infra_tbl.insert_row(write_row)
		else:
			key = '[[ "vrgsi_peer", "==", "' + remote_ip + '" ]]'
			rgsync_infra_tbl.update_row(key, write_row)

	def clear_rgsync_stats(self, access_port):
		rgsync_infra_tbl = nuage.ovsdb_client.Transact(self.db,
							self.table, self.vlog)
		self.vlog.info("Clearing rgsync stats entry for {%s}" %access_port)
		self.__clear_rgsync_port_stats(rgsync_infra_tbl, access_port)

	def update_rgsync_stats_all(self, access_port, local_ip, port_num,
				    remote_ip, total_hb_misses,
				    last_hb_miss_time):
		if (access_port == ""):
			return
		rgsync_infra_tbl = nuage.ovsdb_client.Transact(self.db,
							self.table, self.vlog)
		cols = [ "vrgsi_peer", "vrgsi_iface", "vrgsi_local_ip", "vrgsi_port_num", "vrgsi_hb_misses" ]
		read_row = rgsync_infra_tbl.get_cols_key_rows(
				"vrgsi_peer", "string", remote_ip, cols)
		self.__commit_rgsync_stats(rgsync_infra_tbl, read_row,
					   access_port, local_ip, port_num,
					   remote_ip, total_hb_misses,
					   last_hb_miss_time)

	def update_rgsync_stats_hb_misses(self, remote_ip, total_hb_misses,
					  last_hb_miss_time):
		rgsync_infra_tbl = nuage.ovsdb_client.Transact(self.db,
							self.table, self.vlog)
		cols = [ "vrgsi_iface", "vrgsi_local_ip", "vrgsi_port_num", ]
		read_row = rgsync_infra_tbl.get_cols_key_rows(
				"vrgsi_peer", "string", remote_ip, cols)
		read_row = str(read_row).replace("[", "").replace("]", "").replace("'", "").split(",")
		access_port = read_row[0].replace(" ", "")
		local_ip = read_row[1].replace(" ", "")
		port_num = read_row[2].replace(" ", "")
		self.__commit_rgsync_stats(rgsync_infra_tbl, read_row,
					   access_port, local_ip, port_num,
					   remote_ip, total_hb_misses,
					   last_hb_miss_time)

	def __display_rgsync_stats_row(self, access_port, liveliness,
				       local_ip, port_num, remote_ip,
				       total_hb_misses, last_hb_miss_time):
		print("Resiliency Group Sync Connection Statistics:")
		print("\tConnection State: %s" % liveliness)
		print("\tPeer IP: %s" % remote_ip)
		print("\tLocal IP: %s:%s" % (local_ip, port_num))
		if (access_port == ""):
			print("\tAccess port: n/a (disconnected)")
		else:
			print("\tAccess Port: %s" % access_port)
		print("\tHeartbeat Misses: %s" % total_hb_misses)
		if (last_hb_miss_time == ""):
			print("\tLast Heartbeat Miss: n/a")
		else :
			print("\tLast Heartbeat Miss: %s" % last_hb_miss_time)

	def display_rgsync_stats(self):
		rgsync_infra_tbl = nuage.ovsdb_client.Transact(self.db,
			 			self.table, self.vlog)
		cols = [ "vrgsi_peer", "vrgsi_iface", "vrgsi_local_ip", "vrgsi_port_num", "vrgsi_hb_misses", "vrgsi_hb_miss_time", ]
		read_row = rgsync_infra_tbl.get_cols_all_rows(cols)
		n_rgs_up = 0
		for row in read_row:
			row = str(row).replace("[", "").replace("]", "").replace("'", "").split(",")
			remote_ip = row[0].replace(" ", "")
			access_port = row[1].replace(" ", "")
			if (remote_ip != ''):
				alive = self.is_rg_peer_alive(access_port,
							      remote_ip, 1)
			else:
				remote_ip = "n/a"
				alive = False
			if (alive == True):
				liveliness = "up"
				n_rgs_up = n_rgs_up + 1
			else:
				liveliness = "down"
			local_ip = row[2].replace(" ", "")
			if (local_ip == ''):
				local_ip = "n/a"
			port_num = row[3].replace(" ", "")
			total_hb_misses = row[4].replace(" ", "")
			last_hb_miss_time = row[5].replace(" ", "")
			# always print only:
			# (a) configured ports
			# (b) ports where RG is configured
			# (c) only one 'up' port 
			# (d) only one 'down' port with a configured peer
			if (access_port == ""):
				continue
			port_rg = PortRg(self.vlog, access_port)
			if (port_rg.is_rg_configured() == False):
				continue
			if ((liveliness == "up") or
			    ((n_rgs_up == 0) and (remote_ip != "n/a"))):
				self.__display_rgsync_stats_row(access_port,
					liveliness, local_ip, port_num,
					remote_ip, total_hb_misses,
					last_hb_miss_time)
				return

	def __dump_xml_key_value(self, xml_doc, hook_node, key, value) :
		node = xml_doc.createElement(key)
		hook_node.appendChild(node)
		text = xml_doc.createTextNode(value)
		node.appendChild(text)
		return

	def dump_xml(self, xml_doc, hook_node):
		sync_status = "false"
		access_port, local_ip, remote_ip = self.get_rg_ipaddrs()
		if (access_port != ""):
			alive = self.is_rg_peer_alive(access_port, remote_ip, 1)
			if (alive == True):
				sync_status = "true"
		self.__dump_xml_key_value(xml_doc, hook_node,
					  "db-synced", sync_status)
