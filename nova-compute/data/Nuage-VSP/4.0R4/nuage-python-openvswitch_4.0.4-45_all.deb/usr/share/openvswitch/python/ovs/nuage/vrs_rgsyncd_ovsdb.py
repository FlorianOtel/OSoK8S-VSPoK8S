
import sys
import os
import signal
import getopt
import threading
import time

import ovs.daemon
import nuage.vlog
import nuage.utils
import nuage.vrs_common
import nuage.vrs_rgsyncd_agent
import nuage.ovsdb_client

def print_ovsdb_sync_usage(progname):
	print "usage: " + progname + " -l <local_ip> -r <remote_ip> [-i]"
	print "usage: " + progname + " -d|--daemon --start|--stop|--status|--configure"
	print "usage: " + progname + " -d -u|--usage"
	print ""
	print "options:"
	print "-l: IP address of local host"
	print "-r: IP address of remote host"
	print "-i: interactive mode"
	print "-d|--daemon: daemon mode (mutually exclusive with -i,-l,-r)"
	print "-u|--usage: print usage"
	print
	print "Suboptions for daemon mode:"
	print "    --start: start ovsdb/sync daemon"
	print "    --stop: stop ovsdb/sync daemon"
	print "    --stats: display config variables and status of ovsdb/sync daemon"
	print "    --configure <key>=<value>: configure ovsdb/sync daemon"
	sys.exit(1)

def get_rg_sync_data(vlog):
	db = "Open_vSwitch"
	table = "Vrs_Resiliency_Group_Sync_Data"
	cols = ["vrgsd_agent_name", "vrgsd_table_name", "vrgsd_priv_key",
		"vrgsd_priv_value"]
	msg = ""
	rgsync_table = nuage.ovsdb_client.Transact(db, table, vlog)
	n_rows = rgsync_table.get_n_rows()
	if (n_rows <= 0) :
		return msg, None, None, None
	values = rgsync_table.get_cols_all_rows(cols)
	msgList = []
	pkeyList = []
	pvalList = []
	for agent, table, pkey, pval in values:
		sender = nuage.vrs_rgsyncd_agent.VRSRgSyncdDataSender(
					vlog, agent)
		msg = sender.get_msg(table, pkey, pval)
		if (msg == None) :
			continue
		msgList.append(msg)
		pkeyList.append(pkey)
		pvalList.append(pval)
	return msgList, pkeyList, pvalList, rgsync_table

def process_message(vlog, remote_ip, port, msg, rgsync_table, pkey, pval):
	if (len(msg) == 0) :
		return
	if (msg == "exit" or msg == "q" or msg == "quit") :
		sys.exit(0)
	client = nuage.vrs_rgsyncd_agent.VRSRgSyncdClient(vlog,
						remote_ip, port, msg,
						rgsync_table, pkey, pval)
	t = threading.Thread(target=client.run)
	t.start()
	t.join()

class VRSRgSyncdHandler(object):
	def __init__(self, vlog, local_ip, remote_ip, port):
		self.vlog = vlog
		self.local_ip = local_ip
		self.remote_ip = remote_ip
		self.port = port
		signal.signal(signal.SIGUSR1, self.rgsyncd_sigusr1_handler)
		signal.signal(signal.SIGUSR2, self.rgsyncd_sigusr2_handler)

	def rgsyncd_sigusr1_handler(self, s, f):
		self.vlog.info("processing event for sync data table entries")
		handling_sync_event = True
		msgList, pkeyList, pvalList, rgsync_table = get_rg_sync_data(self.vlog)
		for msg in msgList:
			process_message(self.vlog, self.remote_ip, self.port,
				        msg, rgsync_table, pkeyList.pop(0),
					pvalList.pop(0))
		handling_sync_event = False

	def rgsyncd_sigusr2_handler(self, s, f):
		self.vlog.info("processing asynchronous resync event")
		client = nuage.vrs_rgsyncd_agent.VRSRgSyncdClient(self.vlog,
						self.remote_ip, self.port, None,
						None, None, "resync")
		t = threading.Thread(target=client.resync_agents)
		t.start()
		t.join()

def handle_ovsdb_sync__(vlog, local_ip, remote_ip, port, interactive):
	server = nuage.vrs_rgsyncd_agent.VRSRgSyncdServer(vlog, local_ip,
							      port, remote_ip)
	server_thread = threading.Thread(target=server.run)
	server_thread.daemon = True
	server_thread.start()

	client = nuage.vrs_rgsyncd_agent.VRSRgSyncdClient(vlog,
						remote_ip, port, None,
						None, None, None)
	t = threading.Thread(target=client.resync_agents)
	t.start()
	t.join()

	while True:
		msg = ""
		if (interactive == True) :
			msg = raw_input(progname + "> ")
			process_message(vlog, remote_ip, port, msg, None, None,
					None)
		else :
			client = nuage.vrs_rgsyncd_agent.VRSRgSyncdClient(
					vlog, 0, 0, 0, 0, 0, None)
			interval = client.get_sync_interval_secs()
			time.sleep(interval)
			if (handling_sync_event == True):
				continue
			msgList, pkeyList, pvalList, rgsync_table = get_rg_sync_data(vlog)
			if (len(msgList) != 0):
				vlog.info("residual entries in sync data table")
			for msg in msgList:
				process_message(vlog, remote_ip, port, msg,
					       	rgsync_table, pkeyList.pop(0),
						pvalList.pop(0))

def handle_ovsdb_sync_start(vlog):
	n_procs = nuage.utils.n_procs_by_name("vrs-rgsyncd")
	if (n_procs > 0):
		print "At least one instance of vrs-rgsyncd already running, exiting.."
		sys.exit(1)
	vlog.info("Starting vrs-rgsyncd ovsdb/sync daemon")
	print "NOTE: Resiliency Group Sync daemon is started"
	return

def handle_ovsdb_sync_stop(vlog):
	n_procs = nuage.utils.n_procs_by_name("vrs-rgsyncd")
	if (n_procs <= 0):
		print "No instances of vrs-rgsyncd are running, exiting.."
		sys.exit(1)
	rg_port = nuage.vrs_rg_infra.PortRg(vlog, None)
	rg_port.stop()
	rg_gw = nuage.vrs_rg_infra.GatewayRg(vlog)
	rg_gw.stop()
	vlog.info("Stopping vrs-rgsyncd ovsdb/sync daemon")
	print "NOTE: Resiliency Group Sync daemon is stopped"
	nuage.utils.killall_procs_by_name("vrs-rgsyncd")
	return

def handle_ovsdb_sync_stats(vlog):
	if (nuage.utils.proc_exists("vrs-rgsyncd")):
		print "Resiliency Group Sync Daemon: Running"
	else:
		print "Resiliency Group Sync Daemon: Not Running"
	server = nuage.vrs_rgsyncd_agent.VRSRgSyncdServer(vlog, 0, 0, 0)
	client = nuage.vrs_rgsyncd_agent.VRSRgSyncdClient(vlog, 0, 0, 0, 0, 0, None)
	rg_gw = nuage.vrs_rg_infra.GatewayRg(vlog)
	agent = nuage.vrs_rgsyncd_agent.VRSRgSyncdAgent()

	server.display_rgsync_cfg()
	client.display_rgsync_cfg()
	print

	rg_gw.display_rgsync_stats()
	print
	agent.display_rgsync_stats(vlog)
	print
	return

def handle_ovsdb_sync_configure(vlog, cfg_str):
	server = nuage.vrs_rgsyncd_agent.VRSRgSyncdServer(vlog, 0, 0, 0)
	rc = server.configure(cfg_str)
	if (rc == 1):
		return
	client = nuage.vrs_rgsyncd_agent.VRSRgSyncdClient(vlog, 0, 0, 0, 0, 0, None)
	rc = client.configure(cfg_str)
	if (rc == 1):
		return
	print "vrs-rgsyncd: Invalid configuration item '" + cfg_str + "'"
	return

def handle_ovsdb_sync(vlog, argv):
	progname = ovs.util.PROGRAM_NAME
	arg_str = ""
	for arg in argv:
		if (arg == "ovsdb/sync") :
			arg_str = ""
		arg_str += str(arg) + " "
	arg_str = arg_str[:-1]
	try:
		opts, args = getopt.getopt(arg_str.split(" "), "hl:r:id",
				[ "daemon", "start", "stop", "stats",
			       	  "configure=", ])
	except getopt.GetoptError as err:
		print progname + ": invalid argument, " + str(err)
		print_ovsdb_sync_usage(progname)

	local_ip = ""
	remote_ip = ""
	port = 65535
	interactive = False

	for opt, arg in opts:
		if opt == "-l":
			local_ip = arg
		if opt == "-r":
			remote_ip = arg
		elif opt == "-h":
			print_ovsdb_sync_usage(progname)
		elif opt == "-i":
			interactive = True
		elif opt == "--daemon" or opt == "-d":
			interactive = False
		elif opt == "--start":
			if (interactive == False):
				handle_ovsdb_sync_start(vlog)
		elif opt == "--stop":
		  	if (interactive == False):
				handle_ovsdb_sync_stop(vlog)
				sys.exit(0)
		elif opt == "--stats":
			if (interactive == False):
				handle_ovsdb_sync_stats(vlog)
				sys.exit(0)
		elif opt == "--configure":
			if (interactive == False):
				handle_ovsdb_sync_configure(vlog, arg)
				sys.exit(0)
	if (interactive and len(local_ip) == 0):
		print progname + ": need to specify IP address of local host"
		sys.exit(1)
	if (interactive and len(remote_ip) == 0):
		print progname + ": need to specify IP address of remote host"
		sys.exit(1)
	if (interactive == False) :
		global handling_sync_event
       		handling_sync_event = False
		s = VRSRgSyncdHandler(vlog, local_ip, remote_ip, port)
		if (os.fork() == 0):
			handle_ovsdb_sync__(vlog, local_ip, remote_ip, port,
					    False)
	else :
		handle_ovsdb_sync__(vlog, local_ip, remote_ip, port, True)
