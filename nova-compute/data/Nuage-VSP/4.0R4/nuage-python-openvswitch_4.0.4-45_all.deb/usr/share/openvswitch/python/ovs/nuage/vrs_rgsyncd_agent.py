
import sys
import os
import socket
import time
import thread
import threading
import SocketServer

import nuage.vlog
import nuage.vrs_sock
import nuage.vrs_rg_infra
import nuage.vrs_rgsyncd_dhcp_agent
import nuage.ovsdb_client

## Global class declarations
class VRSRgSyncdAgent(object):
	vrs_rgsyncd_agents = [
		{ "name" : "dhcp",
		  "hndlr_class" :
			 nuage.vrs_rgsyncd_dhcp_agent.VRSRgSyncdDhcpAgent },
	]
	db = "Open_vSwitch"
	table = "Vrs_Resiliency_Group_Sync_Agents"
	def get_agent_list(self):
		agentList = []
		for this_agent in self.vrs_rgsyncd_agents:
			agentList.append(this_agent)
		return agentList

	def get_agent_data(self, this_agent, vlog):
		this_agent_name = this_agent['name']
		rgsync_stats_tbl = nuage.ovsdb_client.Transact(
					self.db, self.table, vlog)
		cols = [ "vrgsa_priv_data" ]
		agent_read_row = rgsync_stats_tbl.get_cols_key_rows(
			"vrgsa_agent_name", "string", this_agent_name, cols)
		priv_data = str(agent_read_row).replace("[[", "").replace("]]", "")
		vlog.info("priv_data: {%s}" % priv_data)
		return this_agent_name, priv_data

	def set_agent_data(self, this_agent_name, priv_data, vlog):
		rgsync_stats_tbl = nuage.ovsdb_client.Transact(
					self.db, self.table, vlog)
		key = '[[ "vrgsa_agent_name", "==", "' + this_agent_name + '" ]]'
		row = '{ "vrgsa_priv_data" : "' + priv_data + '" }'
		rgsync_stats_tbl.update_row(key, row)

	def lookup_agent(self, agent):
		hndlr_class = ''
		for this_agent in self.vrs_rgsyncd_agents:
			this_agent_name = this_agent['name']
			if (this_agent_name == agent) :
				hndlr_class = this_agent['hndlr_class']
				break
		return hndlr_class

	def update_rgsync_stats(self, type, msg, vlog):
		this_agent = msg.split("::")[0]
		if (this_agent == None) or (this_agent == "") :
			vlog.info("No agent identified for msg: '%s'" % msg)
			return
		rgsync_stats_tbl = nuage.ovsdb_client.Transact(self.db,
							self.table, vlog)
		cols = [ "vrgsa_agent_name", "vrgsa_last_receive_time", "vrgsa_last_send_time", "vrgsa_n_receives", "vrgsa_n_sends" ]
		agent_read_row = rgsync_stats_tbl.get_cols_key_rows(
				"vrgsa_agent_name", "string", this_agent, cols)
		now = time.strftime("%Y-%m-%d-%H:%M:%S", time.localtime())
		if (agent_read_row == []):
			if (type == "send") :
				last_recv_time = ""
				last_send_time = now
				n_recvs = "0"
				n_sends = "1"
			elif (type == "recv") :
				last_recv_time = now
				last_send_time = ""
				n_recvs = "1"
				n_sends = "0"
			else:
				return
			row = '{ "vrgsa_agent_name" : "' + this_agent + '", "vrgsa_last_receive_time" : "' + last_recv_time + '", "vrgsa_last_send_time" : "' + last_send_time + '", "vrgsa_n_receives" : "' + n_recvs + '", "vrgsa_n_sends" : "' + n_sends + '" }'
			rgsync_stats_tbl.insert_row(row)
		else:
			agent_read_row = str(agent_read_row).replace("[[", "").replace("]]", "").split(",")
			if (type == "send") :
				last_recv_time = str(agent_read_row[1]).replace(" ", "")
				last_send_time = now.replace(" ", "")
				n_recvs = str(str(agent_read_row[3]).replace("'", "").replace(" ", ""))
				curr_n_sends = int(str(agent_read_row[4]).replace("'", ""))
				n_sends = str(curr_n_sends + 1).replace(" ", "")
			elif (type == "recv") :
				last_recv_time = now.replace(" ", "")
				last_send_time = str(agent_read_row[2]).replace(" ", "")
				curr_n_recvs = int(str(agent_read_row[3]).replace("'", ""))
				n_recvs = str(curr_n_recvs + 1).replace(" ", "")
				n_sends = str(str(agent_read_row[4]).replace("'", "").replace(" ", ""))
			else:
				return
			key = '[[ "vrgsa_agent_name", "==", "' + this_agent + '" ]]'
			row = '{ "vrgsa_agent_name" : "' + this_agent + '", "vrgsa_last_receive_time" : "' + last_recv_time + '", "vrgsa_last_send_time" : "' + last_send_time + '", "vrgsa_n_receives" : "' + n_recvs + '", "vrgsa_n_sends" : "' + n_sends + '" }'
			rgsync_stats_tbl.update_row(key, row)

	def display_rgsync_stats(self, vlog):
		rgsync_stats_tbl = nuage.ovsdb_client.Transact(self.db,
			 			self.table, vlog)
		cols = [ "vrgsa_agent_name", "vrgsa_last_receive_time", "vrgsa_last_send_time", "vrgsa_n_receives", "vrgsa_n_sends" ]
		agent_read_rows = rgsync_stats_tbl.get_cols_all_rows(cols)
		print("Resiliency Group Sync Agent Statistics:")
		print("%-10s%-10s%-20s%-10s%-20s" %("Agent", "N-Recvs", "Last-Recv", "N-Sends", "Last-Send"))
		for agent_row in agent_read_rows:
			agent_row = str(agent_row).replace("[", "").replace("]", "").replace("'", "").split(",")
			agent = agent_row[0]
			last_recv_time = agent_row[1].replace(" ", "")
			if (last_recv_time == '') or (last_recv_time == None) :
				last_recv_time = "-"
			last_send_time = agent_row[2].replace(" ", "")
			if (last_send_time == '') :
				last_send_time = "-"
			n_recvs = agent_row[3]
			n_sends = agent_row[4]
			print("%-9s%-10s %-19s%-10s %-19s" %(agent, n_recvs, last_recv_time, n_sends, last_send_time))

		print
		print("Resiliency Group Sync Statistics from known agents:")
		for agent_row in agent_read_rows:
			agent_row = str(agent_row).replace("[", "").replace("]", "").replace("'", "").split(",")
			agent = agent_row[0]
			hndlr_class = self.lookup_agent(agent)
			cls = hndlr_class(vlog)
			if (cls != '') :
				cls.display_rgsync_stats()

class VRSRgSyncdServer(object):
	db = "Open_vSwitch"
	cfg_table = "Vrs_Resiliency_Group_Sync_Cfg"
	ovsdb_lock = None
	def __init__(self, vlog, local_ip, port, remote_ip):
		self.vlog = vlog
		self.local_ip = local_ip
		self.port = port
		self.remote_ip = remote_ip
		self.gw_rg = nuage.vrs_rg_infra.GatewayRg(self.vlog)
		self.connected = False
		self.rg_port_name = ""
		self.sock_server = None
		self.max_hb_misses = 3
		self.reconfigure_secs = 30
		self.server_reconnect_secs = 4
		self.hb_miss_check_secs = 5
		self.hb_miss_grace_secs = 3
		self.hb_miss_grace_count = 20
		self.total_hb_misses = 0
		self.last_hb_miss_time = ""
		self.ovsdb_lock = threading.Lock()

	def __connect_rg_peer(self):
		self.rg_port_name = ""
		if (self.connected == False) or (self.rg_port_name == ""):
			self.rg_port_name, self.local_ip, self.remote_ip = self.gw_rg.get_rg_ipaddrs()
			self.vlog.info("Connecting (local_ip: %s, rg_port_name: %s) to peer remote_ip: %s" %(self.local_ip, self.rg_port_name, self.remote_ip))
			self.connected = self.gw_rg.connect_rg_peer(
					self.rg_port_name, self.local_ip,
					self.port, self.remote_ip)
			if (self.connected == True):
				self.vlog.info("sync server configuration - local_ip: '%s', remote_ip: '%s', rg_port_name: '%s'" %(self.local_ip, self.remote_ip, self.rg_port_name))
		self.gw_rg.clear_rgsync_stats(self.rg_port_name)
		self.gw_rg.update_rgsync_stats_all(self.rg_port_name,
						   self.local_ip, self.port,
						   self.remote_ip,
						   self.total_hb_misses,
						   self.last_hb_miss_time)

	def __disconnect_rg_peer(self):
		self.gw_rg.disconnect_rg_peer(self.rg_port_name, self.local_ip,
					      self.remote_ip)
		self.connected = False

	def __configure_server_kv(self, insert, cols, cfg_key, cfg_value,
				  hb_miss_check_secs, max_hb_misses,
				  hb_miss_grace_secs, hb_miss_grace_count,
				  server_reconnect_secs):
		if (cfg_key == cols[0]):
			if (insert == True):
				row = '{ "vrgsc_item" : "server", "vrgsc_hb_miss_check_secs" : ' + cfg_value + ', "vrgsc_max_hb_misses" : ' + str(max_hb_misses) +', "vrgsc_server_reconnect_secs" : ' + str(server_reconnect_secs) + ', "vrgsc_hb_miss_grace_secs" : ' + str(hb_miss_grace_secs) + ', "vrgsc_hb_miss_grace_count" : ' + str(hb_miss_grace_count) + ' }'
			else:
				row = '{ "vrgsc_hb_miss_check_secs" : ' + cfg_value + ', "vrgsc_max_hb_misses" : ' + str(max_hb_misses) +', "vrgsc_server_reconnect_secs" : ' + str(server_reconnect_secs) + ', "vrgsc_hb_miss_grace_secs" : ' + str(hb_miss_grace_secs) + ', "vrgsc_hb_miss_grace_count" : ' + str(hb_miss_grace_count) + ' }'
		elif (cfg_key == cols[1]):
			if (insert == True):
				row = '{ "vrgsc_item" : "server", "vrgsc_hb_miss_check_secs" : ' + str(hb_miss_check_secs) + ', "vrgsc_max_hb_misses" : ' + cfg_value +', "vrgsc_server_reconnect_secs" : ' + str(server_reconnect_secs) + ', "vrgsc_hb_miss_grace_secs" : ' + str(hb_miss_grace_secs) + ', "vrgsc_hb_miss_grace_count" : ' + str(hb_miss_grace_count) + ' }'
			else:
				row = '{ "vrgsc_hb_miss_check_secs" : ' + str(hb_miss_check_secs) + ', "vrgsc_max_hb_misses" : ' + cfg_value +', "vrgsc_server_reconnect_secs" : ' + str(server_reconnect_secs) + ', "vrgsc_hb_miss_grace_secs" : ' + str(hb_miss_grace_secs) + ', "vrgsc_hb_miss_grace_count" : ' + str(hb_miss_grace_count) + ' }'
		elif (cfg_key == cols[2]):
			if (insert == True):
				row = '{ "vrgsc_item" : "server", "vrgsc_hb_miss_check_secs" : ' + str(hb_miss_check_secs) + ', "vrgsc_max_hb_misses" : ' + str(max_hb_misses) +', "vrgsc_server_reconnect_secs" : ' + cfg_value + ', "vrgsc_hb_miss_grace_secs" : ' + str(hb_miss_grace_secs) + ', "vrgsc_hb_miss_grace_count" : ' + str(hb_miss_grace_count) + ' }'
			else:
				row = '{ "vrgsc_hb_miss_check_secs" : ' + str(hb_miss_check_secs) + ', "vrgsc_max_hb_misses" : ' + str(max_hb_misses) +', "vrgsc_server_reconnect_secs" : ' + cfg_value + ', "vrgsc_hb_miss_grace_secs" : ' + str(hb_miss_grace_secs) + ', "vrgsc_hb_miss_grace_count" : ' + str(hb_miss_grace_count) + ' }'
		elif (cfg_key == cols[3]):
			if (insert == True):
				row = '{ "vrgsc_item" : "server", "vrgsc_hb_miss_check_secs" : ' + str(hb_miss_check_secs) + ', "vrgsc_max_hb_misses" : ' + str(max_hb_misses) +', "vrgsc_server_reconnect_secs" : ' + str(server_reconnect_secs) + ', "vrgsc_hb_miss_grace_secs" : ' + cfg_value + ', "vrgsc_hb_miss_grace_count" : ' + str(hb_miss_grace_count) + ' }'
			else:
				row = '{ "vrgsc_hb_miss_check_secs" : ' + str(hb_miss_check_secs) + ', "vrgsc_max_hb_misses" : ' + str(max_hb_misses) +', "vrgsc_server_reconnect_secs" : ' + str(server_reconnect_secs) + ', "vrgsc_hb_miss_grace_secs" : ' + cfg_value + ', "vrgsc_hb_miss_grace_count" : ' + str(hb_miss_grace_count) + ' }'
		elif (cfg_key == cols[4]):
			if (insert == True):
				row = '{ "vrgsc_item" : "server", "vrgsc_hb_miss_check_secs" : ' + str(hb_miss_check_secs) + ', "vrgsc_max_hb_misses" : ' + str(max_hb_misses) +', "vrgsc_server_reconnect_secs" : ' + str(server_reconnect_secs) + ', "vrgsc_hb_miss_grace_secs" : ' + str(hb_miss_grace_secs) + ', "vrgsc_hb_miss_grace_count" : ' + cfg_value + ' }'
			else:
				row = '{ "vrgsc_hb_miss_check_secs" : ' + str(hb_miss_check_secs) + ', "vrgsc_max_hb_misses" : ' + str(max_hb_misses) +', "vrgsc_server_reconnect_secs" : ' + str(server_reconnect_secs) + ', "vrgsc_hb_miss_grace_secs" : ' + str(hb_miss_grace_secs) + ', "vrgsc_hb_miss_grace_count" : ' + cfg_value + ' }'
		else:
			return None
		return row

	def configure(self, cfg_str):
		rgsync_cfg_tbl = nuage.ovsdb_client.Transact(self.db,
			 			self.cfg_table, self.vlog)
		cols = [ "vrgsc_hb_miss_check_secs",
			 "vrgsc_max_hb_misses",
			 "vrgsc_server_reconnect_secs",
			 "vrgsc_hb_miss_grace_secs",
			 "vrgsc_hb_miss_grace_count",
		]
		read_rows = rgsync_cfg_tbl.get_cols_key_rows("vrgsc_item",
			       		"string", "server", cols)
		cfg_key = "vrgsc_" + cfg_str.split("=")[0]
		cfg_value = cfg_str.split("=")[1]
		if (read_rows == []) :
			row = self.__configure_server_kv(True, cols, cfg_key,
					cfg_value, self.hb_miss_check_secs,
					self.max_hb_misses,
					self.hb_miss_grace_secs,
					self.hb_miss_grace_count,
					self.server_reconnect_secs)
			if (row == None):
				return 0
			rgsync_cfg_tbl.insert_row(row)
			self.vlog.info("Configuration: %s, changed to value: %s" %(cfg_key, cfg_value))
		else :
			for row in read_rows:
				row = str(row).replace("[", "").replace("]", "").replace("'", "").split(",")
				hb_miss_check_secs = row[0].replace(" ", "")
				max_hb_misses = row[1].replace(" ", "")
				server_reconnect_secs = row[2].replace(" ", "")
				hb_miss_grace_secs = row[3].replace(" ", "")
				hb_miss_grace_count = row[4].replace(" ", "")
				row = self.__configure_server_kv(False, cols,
					cfg_key, cfg_value, hb_miss_check_secs,
					max_hb_misses,
					hb_miss_grace_secs,
					hb_miss_grace_count,
					server_reconnect_secs)
				if (row == None):
					return 0
				key = '[[ "vrgsc_item", "==", "server" ]]'
				rgsync_cfg_tbl.update_row(key, row)
				print "Configuration Item: " + cfg_key.replace("vrgsc_", "")
				print "New Value: " + cfg_value
				self.vlog.info("Configuration: %s, updated to value: %s" %(cfg_key, cfg_value))
				break
		return 1

	def __display_rgsync_cfg(self, hb_miss_check_secs, max_hb_misses,
				 hb_miss_grace_secs, hb_miss_grace_count,
				 server_reconnect_secs):
		print("\tHeartbeat Miss Check Interval (hb_miss_check_secs): %s" %hb_miss_check_secs)
		print("\tMax Heartbeat Misses (max_hb_misses): %s" %max_hb_misses)
		print("\tHeartbeat Miss Grace Interval (hb_miss_grace_secs): %s" %hb_miss_grace_secs)
		print("\tHeartbeat Miss Grace Count (hb_miss_grace_count): %s" %hb_miss_grace_count)
		print("\tServer Reconnect Interval (server_reconnect_secs): %s" %server_reconnect_secs)

	def display_rgsync_cfg(self):
		rgsync_cfg_tbl = nuage.ovsdb_client.Transact(self.db,
			 			self.cfg_table, self.vlog)
		cols = [ "vrgsc_hb_miss_check_secs",
			 "vrgsc_max_hb_misses",
			 "vrgsc_server_reconnect_secs",
			 "vrgsc_hb_miss_grace_secs",
			 "vrgsc_hb_miss_grace_count",
		]
		read_rows = rgsync_cfg_tbl.get_cols_key_rows("vrgsc_item",
			       		"string", "server", cols)
		print("Resiliency Group Sync Server Configuration:")
		if (read_rows == []):
			self.__display_rgsync_cfg(self.hb_miss_check_secs,
						  self.max_hb_misses,
						  self.hb_miss_grace_secs,
						  self.hb_miss_grace_count,
						  self.server_reconnect_secs)
		else :
			for row in read_rows:
				row = str(row).replace("[", "").replace("]", "").replace("'", "").split(",")
				hb_miss_check_secs = row[0].replace(" ", "")
				max_hb_misses = row[1].replace(" ", "")
				server_reconnect_secs = row[2].replace(" ", "")
				hb_miss_grace_secs = row[3].replace(" ", "")
				hb_miss_grace_count = row[4].replace(" ", "")
				self.__display_rgsync_cfg(hb_miss_check_secs,
					       		  max_hb_misses,
							  hb_miss_grace_secs,
							  hb_miss_grace_count,
							  server_reconnect_secs)
				break

	def __reconfigure(self):
		rgsync_cfg_tbl = nuage.ovsdb_client.Transact(self.db,
			 			self.cfg_table, self.vlog)
		cols = [ "vrgsc_hb_miss_check_secs",
			 "vrgsc_max_hb_misses",
			 "vrgsc_server_reconnect_secs",
			 "vrgsc_hb_miss_grace_secs",
			 "vrgsc_hb_miss_grace_count",
		]
		while True:
			read_rows = rgsync_cfg_tbl.get_cols_key_rows(
					"vrgsc_item", "string", "server", cols)
			if (read_rows == []):
				time.sleep(self.reconfigure_secs)
				continue
			for row in read_rows:
				row = str(row).replace("[", "").replace("]", "").replace("'", "").split(",")
				hb_miss_check_secs = row[0].replace(" ", "")
				max_hb_misses = row[1].replace(" ", "")
				server_reconnect_secs = row[2].replace(" ", "")
				hb_miss_grace_secs = row[3].replace(" ", "")
				hb_miss_grace_count = row[4].replace(" ", "")
				if (self.hb_miss_check_secs != hb_miss_check_secs):
					self.hb_miss_check_secs = int(hb_miss_check_secs)
				if (self.hb_miss_grace_secs != hb_miss_grace_secs):
					self.hb_miss_grace_secs = int(hb_miss_grace_secs)
				if (self.hb_miss_grace_count != hb_miss_grace_count):
					self.hb_miss_grace_count = int(hb_miss_grace_count)
				if (self.max_hb_misses != max_hb_misses):
					self.max_hb_misses = int(max_hb_misses)
				if (self.server_reconnect_secs != server_reconnect_secs):
					self.server_reconnect_secs = int(server_reconnect_secs)
				break
			time.sleep(self.reconfigure_secs)

	def __check_rg_peer(self):
		n_hb_misses = 0
		while True:
			if (self.sock_server == None):
				time.sleep(self.hb_miss_check_secs)
				continue
			if (self.connected == False):
				time.sleep(self.hb_miss_check_secs)
				continue
			alive = self.gw_rg.is_rg_peer_alive(self.rg_port_name,
							    self.remote_ip, 2)
			if (alive == True):
				time.sleep(self.hb_miss_check_secs)
				n_hb_misses = 0
				continue
			n_hb_misses = n_hb_misses + 1
			if (n_hb_misses < self.max_hb_misses):
				time.sleep(self.hb_miss_check_secs)
				continue
			if (self.gw_rg.is_rg_peer_untagged(self.remote_ip)):
				alive = self.gw_rg.is_rg_peer_alive_retries(
					self.rg_port_name, self.remote_ip,
					self.hb_miss_grace_secs,
					self.hb_miss_grace_count)
				if (alive == True):
					n_hb_misses = 0
					continue
			self.vlog.info("max_hb_misses: %d" %self.max_hb_misses)
			self.vlog.info("hb_miss_check_secs: %d" %self.hb_miss_check_secs)
			self.vlog.info("hb_miss_grace_secs: %d" %self.hb_miss_grace_secs)
			self.vlog.info("hb_miss_grace_count: %d" %self.hb_miss_grace_count)
			self.vlog.info("server_reconnect_secs: %d" %self.server_reconnect_secs)
			n_rgs, n_rgs_up = self.gw_rg.get_num_rg_ports()
			rg_port_name = self.rg_port_name
			self.__disconnect_rg_peer()
			self.vlog.info("Heartbeat with %s failed from %s, shutting down socket. n_rgs: %d, n_rgs_up: %d" % (self.remote_ip, rg_port_name, n_rgs, n_rgs_up))
			self.sock_server.shutdown()
			self.sock_server = None
			self.connected = False
			self.total_hb_misses = self.total_hb_misses + 1
			self.last_hb_miss_time = time.strftime("%Y-%m-%d-%H:%M:%S", time.localtime())
			if (n_rgs_up < 1):
				self.gw_rg.update_rgsync_stats_hb_misses(self.remote_ip,
							self.total_hb_misses,
							self.last_hb_miss_time)
			else :
				self.gw_rg.clear_rgsync_stats(rg_port_name)
			n_hb_misses = 0

	def run(self):
		thread.start_new_thread(self.__check_rg_peer, ())
		thread.start_new_thread(self.__reconfigure, ())
		while True:
			self.__connect_rg_peer()
			if (self.connected == False):
				time.sleep(self.server_reconnect_secs)
				continue
			try:
				self.vlog.info("Starting sync server on "
					       "%s:%d through port: %s"
					       %(self.local_ip, self.port,
						 self.rg_port_name))
				self.sock_server = \
					nuage.vrs_sock._SocketServer(
						self.local_ip,
						self.port,
						self.remote_ip,
						VRSRgSyncdDataReceiver,
						self.ovsdb_lock,
						self.vlog)
				self.sock_server.serve_forever()
			except:
				self.vlog.info("Connectivity to " + self.remote_ip + " lost, retrying with other RG ports (if any)..")
				self.__disconnect_rg_peer()
				time.sleep(self.server_reconnect_secs)

class VRSRgSyncdDataReceiver(SocketServer.BaseRequestHandler,
			     VRSRgSyncdAgent):
	def handle(self):
		socket = nuage.vrs_sock._Socket(None, None, self.request)
		msg = socket.recv()
		agent = msg.split("::")[0]
		hndlr_class = self.lookup_agent(agent)
		if (hndlr_class == '') :
			self.server.vlog.warn("Received data for unknown agent (%s)" % agent)
		else:
			bytes = len(msg) - len(agent) - len("::")
			self.server.vlog.info("Received %d bytes. Target "
					      "agent: %s" % (bytes, agent))
			self.server.lock.acquire()
			try:
				cls = hndlr_class(self.server.vlog)
				resp = cls.run(msg)
			finally:
				self.server.lock.release()
			self.update_rgsync_stats("recv", msg, self.server.vlog)
			if (resp != None):
				client = nuage.vrs_rgsyncd_agent.VRSRgSyncdClient(self.server.vlog, self.server.remote_ip, self.server.port, resp, None, None, None)
				t = threading.Thread(target=client.run)
				t.start()
				t.join()
		return

class VRSRgSyncdClient(object):
	db = "Open_vSwitch"
	cfg_table = "Vrs_Resiliency_Group_Sync_Cfg"
	def __init__(self, vlog, remote_ip, port, msg, rgsync_table, pkey,
		     pval):
		self.vlog = vlog
		self.remote_ip = remote_ip
		self.port = port
		self.msg = msg
		self.rgsync_table = rgsync_table
		self.pkey = pkey
		self.pval = pval
		self.reconfigure_secs = 30
		self.sync_interval_secs = 10
		self.n_resync_attempts = 0
		self.max_resync_attempts = 10

	def __configure_client_kv(self, insert, cols, cfg_key, cfg_value,
				  sync_interval_secs):
		if (cfg_key == cols[0]):
			if (insert == True):
				row = '{ "vrgsc_item" : "client", "vrgsc_sync_interval_secs" : ' + cfg_value + ' }'
			else:
				row = '{ "vrgsc_sync_interval_secs" : ' + cfg_value + ' }'
		else:
			return None
		return row

	def configure(self, cfg_str):
		rgsync_cfg_tbl = nuage.ovsdb_client.Transact(self.db,
			 			self.cfg_table, self.vlog)
		cols = [ "vrgsc_sync_interval_secs" ]
		read_rows = rgsync_cfg_tbl.get_cols_key_rows("vrgsc_item",
			       		"string", "client", cols)
		cfg_key = "vrgsc_" + cfg_str.split("=")[0]
		cfg_value = cfg_str.split("=")[1]
		if (read_rows == []) :
			row = self.__configure_client_kv(True, cols, cfg_key,
					cfg_value, self.sync_interval_secs)
			if (row == None):
				return 0
			rgsync_cfg_tbl.insert_row(row)
			self.vlog.info("Configuration: %s, changed to value: %s" %(cfg_key, cfg_value))
		else :
			for row in read_rows:
				row = str(row).replace("[", "").replace("]", "").replace("'", "").split(",")
				sync_interval_secs = row[0].replace(" ", "")
				row = self.__configure_client_kv(False, cols,
					cfg_key, cfg_value, sync_interval_secs)
				if (row == None):
					return 0
				key = '[[ "vrgsc_item", "==", "client" ]]'
				rgsync_cfg_tbl.update_row(key, row)
				print "Configuration Item: " + cfg_key.replace("vrgsc_", "")
				print "New Value: " + cfg_value
				self.vlog.info("Configuration: %s, updated to value: %s" %(cfg_key, cfg_value))
				break
		return 1

	def __read_sync_interval_secs(self):
		rgsync_cfg_tbl = nuage.ovsdb_client.Transact(self.db,
			 			self.cfg_table, self.vlog)
		cols = [ "vrgsc_sync_interval_secs", ]
		read_rows = rgsync_cfg_tbl.get_cols_key_rows(
				"vrgsc_item", "string", "client", cols)
		if (read_rows == []):
			return
		for row in read_rows:
			row = str(row).replace("[", "").replace("]", "").replace("'", "").split(",")
			sync_interval_secs = row[0].replace(" ", "")
			if (self.sync_interval_secs != sync_interval_secs):
				self.sync_interval_secs = int(sync_interval_secs)
			break

	def get_sync_interval_secs(self):
		self.__read_sync_interval_secs()
		return self.sync_interval_secs

	def __display_rgsync_cfg(self, sync_interval_secs):
		print("\tSync Interval (sync_interval_secs): %s" %sync_interval_secs)

	def display_rgsync_cfg(self):
		rgsync_cfg_tbl = nuage.ovsdb_client.Transact(self.db,
			 			self.cfg_table, self.vlog)
		cols = [ "vrgsc_sync_interval_secs", ]
		read_rows = rgsync_cfg_tbl.get_cols_key_rows("vrgsc_item",
			       		"string", "client", cols)
		print("Resiliency Group Sync Client Configuration:")
		if (read_rows == []):
			self.__display_rgsync_cfg(self.sync_interval_secs)
		else :
			for row in read_rows:
				row = str(row).replace("[", "").replace("]", "").replace("'", "").split(",")
				sync_interval_secs = row[0].replace(" ", "")
				self.__display_rgsync_cfg(sync_interval_secs)
				break

	def delete_rg_pkey_entry(self):
		if (self.pkey == None) or (self.rgsync_table == None):
			return
		cols = [ "vrgsd_priv_value" ]
		read_rows = self.rgsync_table.get_cols_key_rows(
				"vrgsd_priv_key", "string", self.pkey, cols)
		if (read_rows == []):
			self.vlog.info("rgsync_table content empty")
			return
		for row in read_rows:
			priv_data = str(row).replace("[", "").replace("]", "").replace("'", "")
			if (priv_data != self.pval):
				self.vlog.info("priv_data: {%s}, pkey: {%s}, pval: {%s}" % (priv_data, self.pkey, self.pval))
				return
			break
		row = '[[ "vrgsd_priv_key", "==", "' + self.pkey + '" ]]'
		self.vlog.info("Deleting entry from RG sync table: %s" %(str(row)))
		self.rgsync_table.delete_row(row)

	def run(self):
		if (self.remote_ip == ''):
			gw_rg = nuage.vrs_rg_infra.GatewayRg(self.vlog)
			rg_port_name, local_ip, self.remote_ip = gw_rg.get_rg_ipaddrs()
		self.vlog.info("Running sync client on %s: %d"
			       % (self.remote_ip, self.port))
		try:
			sock_client = nuage.vrs_sock._SocketClient(
					self.remote_ip, self.port)
			sock_client.write(self.msg)
		except:
			self.vlog.warn("Unable to connect to remote client %s"
					% self.remote_ip)
			return False
		agent = VRSRgSyncdAgent()
		agent.update_rgsync_stats("send", self.msg, self.vlog)
		self.delete_rg_pkey_entry()
		return True

	def __resync_agent(self, this_agent_name):
		ds = nuage.vrs_rgsyncd_agent.VRSRgSyncdDataSender(
					self.vlog, this_agent_name)
		self.msg = ds.get_resync_msg(evpn_id=None)
		send_status = False
		self.n_resync_attempts = 0
		while (send_status == False) :
			send_status = self.run()
			self.n_resync_attempts = self.n_resync_attempts + 1
			if (self.n_resync_attempts >= self.max_resync_attempts):
				self.vlog.warn("resync attempt aborted after %d attempts" % self.max_resync_attempts)
				break
			if (send_status == False):
				time.sleep(self.sync_interval_secs)

	def resync_agents(self):
		gw_rg = nuage.vrs_rg_infra.GatewayRg(self.vlog)
		rg_port_name, local_ip, remote_ip = gw_rg.get_rg_ipaddrs()
		port_rg = nuage.vrs_rg_infra.PortRg(self.vlog, rg_port_name)
		cfg_role, cur_role = port_rg.get_rg_role()
		self.vlog.info("cfg_role: %s" % cfg_role)
		if ((cfg_role != "backup") and (cfg_role != "master")) :
			return
		a = VRSRgSyncdAgent()
		agentList = a.get_agent_list()
		for agent in agentList:
			this_agent_name, priv_data = a.get_agent_data(agent,
				       				      self.vlog)
			if (priv_data == "''") or (priv_data == "[]") or (self.pval == "resync"):
				self.__resync_agent(this_agent_name)
				a.set_agent_data(this_agent_name,
					       	 "rgsync:done", self.vlog)

class VRSRgSyncdDataSender(VRSRgSyncdAgent):
	def __init__(self, vlog, agent):
		self.vlog = vlog
		self.agent = agent

	def get_msg(self, table, pkey, pval):
		hndlr_class = self.lookup_agent(self.agent)
		if (hndlr_class == ''):
			self.vlog.info("Send request for unknown agent %s ignored" % self.agent)
			return None
		cls = hndlr_class(self.vlog)
		return cls.get_msg(table, pkey, pval)

	def get_resync_msg(self, evpn_id):
		hndlr_class = self.lookup_agent(self.agent)
		if (hndlr_class == ''):
			self.vlog.info("Send request for unknown agent %s ignored" % self.agent)
			return None
		cls = hndlr_class(self.vlog)
		return cls.get_resync_msg(evpn_id)
