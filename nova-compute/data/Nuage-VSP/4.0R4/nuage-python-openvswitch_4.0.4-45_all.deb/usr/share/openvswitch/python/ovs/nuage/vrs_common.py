#! @PYTHON@

import sys
sys.path.append ('@pkgdatadir@/python')
sys.path.append ('@pkgdatadir@/python/ovs')
import os
import nuage.utils
import json
from compiler.ast import flatten

# 
# This function retrieves the DEFAULT_BRIDGE from the appropriate
# startup config file 
#
def get_default_bridge( ):

    if (os.path.isfile("/etc/default/openvswitch") is True) : 
        cmd = 'grep DEFAULT_BRIDGE /etc/default/openvswitch | awk \'BEGIN { FS="[#= \t]+" } NF==2 { print $2; exit } NF==3 {where = match($0, "#"); if (!where) { print $3; exit} }\'';
    elif (os.path.isfile("/etc/default/openvswitch-switch") is True) : 
        cmd = 'grep DEFAULT_BRIDGE /etc/default/openvswitch-switch | awk \'BEGIN { FS="[#= \t]+" } NF==2 { print $2; exit } NF==3 {where = match($0, "#"); if (!where) { print $3; exit} }\'';
    elif (os.path.isfile("/etc/sysconfig/openvswitch") is True) : 
        cmd = 'grep DEFAULT_BRIDGE /etc/sysconfig/openvswitch | awk \'BEGIN { FS="[#= \t]+" } NF==2 { print $2; exit } NF==3 {where = match($0, "#"); if (!where) { print $3; exit} }\'';

    r = nuage.utils.call_prog_as_is(cmd)
    if r[0] is not 0 :
        default_bridge = "alubr0"
    else :
        default_bridge = r[1].rstrip( )

    return default_bridge

def get_vrs_personality(default_bridge):

    if (os.path.isfile("/etc/default/openvswitch") is True) : 
        cmd = 'grep PERSONALITY /etc/default/openvswitch | awk \'BEGIN { FS="[#= \t]+" } NF==2 { print $2; exit } NF==3 {where = match($0, "#"); if (!where) { print $3; exit} }\'';
    elif (os.path.isfile("/etc/default/openvswitch-switch") is True) : 
        cmd = 'grep PERSONALITY /etc/default/openvswitch-switch | awk \'BEGIN { FS="[#= \t]+" } NF==2 { print $2; exit } NF==3 {where = match($0, "#"); if (!where) { print $3; exit} }\'';
    elif (os.path.isfile("/etc/sysconfig/openvswitch") is True) : 
        cmd = 'grep PERSONALITY /etc/sysconfig/openvswitch | awk \'BEGIN { FS="[#= \t]+" } NF==2 { print $2; exit } NF==3 {where = match($0, "#"); if (!where) { print $3; exit} }\'';

    r = nuage.utils.call_prog_as_is(cmd)
    if r[0] is not 0 :
        personality = "VRS"
    else :
        personality = r[1].rstrip( )
        if (personality == "vrs") :
            personality = "VRS"
        elif (personality == "vrs-g") :
            personality = "VRS-G"
        elif (personality == "nsg") :
            personality = "NSG"
        elif (personality == "vrs-b") :	
            personality = "VRS-B"
        elif (personality == "nsg-br") :	
            personality = "NSG-BR"
        else :
            personality = "VRS"

    return personality

def is_nsg_flavor(personality):
    if ( (personality == "NSG") or (personality == "NSG-BR") ) :
        return True 
    return False 
