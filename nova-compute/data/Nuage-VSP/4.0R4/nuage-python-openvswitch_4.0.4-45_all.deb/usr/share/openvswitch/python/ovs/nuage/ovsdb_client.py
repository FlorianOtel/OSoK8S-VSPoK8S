
import json
import nuage.vlog
import nuage.utils

class Transact(object):
	def __init__(self, db, table, vlog):
		self.db = db
		self.table = table
		self.vlog = vlog
		self.server = nuage.utils.proc_exists("ovsdb-server")

	def __execute(self, cmd):
		if (self.server == False) :
			return None
		r = nuage.utils.call_prog_as_is(cmd)
		if (r[0] is not 0) and (self.vlog != None) :
			self.vlog.warn("Unable to execute: %s" % cmd)
			self.vlog.warn("rc %s out %s err %s" % (r[0], r[1], r[2]))
			return None 
		return r[1]

	def __select_all(self):
		cmd = '/usr/bin/ovsdb-client transact \'["' + self.db + '", {"op" : "select", "table" : "' + self.table + '", "where" : [] } ]\''
		return self.__execute(cmd)

	def __select_row_integer(self, key, val):
		cmd = '/usr/bin/ovsdb-client transact \'["' + self.db + '", {"op" : "select", "table" : "' + self.table + '", "where" : [[ "' + key + '", "==", ' + val + ' ]] } ]\''
		return self.__execute(cmd)

	def __select_row_string(self, key, val):
		cmd = '/usr/bin/ovsdb-client transact \'["' + self.db + '", {"op" : "select", "table" : "' + self.table + '", "where" : [[ "' + key + '", "==", "' + val + '" ]] } ]\''
		return self.__execute(cmd)

	def __select_row_uuid(self, uuid):
		cmd = '/usr/bin/ovsdb-client transact \'["' + self.db + '", {"op" : "select", "table" : "' + self.table + '", "where" : [[ "_uuid", "==", ["uuid", "' + str(uuid) + '" ]]] } ]\''
		return self.__execute(cmd)

	def __select_cols(self, rows, cols):
		values = []
		if (rows == None):
			return values
		dict = json.loads(rows)
		for row in dict[0]['rows'] :
			value = []
			for col in cols :
				if (col not in dict[0]['rows'][0]) and (vlog != None) :
					self.vlog.err("Unexpected schema - col %s does not exist in %s" % (col, self.table))
					return
				value.append(str(row[col]).encode("ascii"))
			values.append(value)
		return values

	def __insert(self, row):
        	cmd = '/usr/bin/ovsdb-client transact \'["' + self.db + '", {"op" : "insert", "table" : "' + self.table + '", "row" : ' + row + '} ]\''
		return self.__execute(cmd)

	def __update(self, key, row):
        	cmd = '/usr/bin/ovsdb-client transact \'["' + self.db + '", {"op" : "update", "table" : "' + self.table + '", "where" : ' + key + ', "row" : ' + row + '} ]\''
		return self.__execute(cmd)

	def __delete(self, row):
        	cmd = '/usr/bin/ovsdb-client transact \'["' + self.db + '", {"op" : "delete", "table" : "' + self.table + '", "where" : ' + row + '} ]\''
		return self.__execute(cmd)

	def dump_all(self):
		rows = self.__select_all()
		parsed = json.loads(rows)
		print json.dumps(parsed, indent=4, sort_keys=True)

	def get_n_rows(self):
		rows = self.__select_all()
		if (rows == None):
			return 0
	      	else:
			return rows.count("_uuid")

	def get_cols_all_rows(self, cols):
		rows = self.__select_all()
		return self.__select_cols(rows, cols)

	def get_cols_key_rows(self, key, key_type, val, cols):
		if (key_type == "integer") :
			rows = self.__select_row_integer(key, val)
		else :
			rows = self.__select_row_string(key, val)
		return self.__select_cols(rows, cols)

	def get_cols_by_uuid(self, uuid, cols):
		rows = self.__select_row_uuid(uuid)
		return self.__select_cols(rows, cols)

	def insert_row(self, row):
		return self.__insert(row)

	def update_row(self, key, row):
		return self.__update(key, row)

	def delete_row(self, row):
		return self.__delete(row)
