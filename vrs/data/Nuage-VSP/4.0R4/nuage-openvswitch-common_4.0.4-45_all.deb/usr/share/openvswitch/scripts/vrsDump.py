#!/usr/bin/env python

__version__    = "$Revision: 0.5 $"
__author__     = "Luc Vermoesen"
__copyright__  = "Copyright 2015, NuageNetworks"
__maintainer__ = "Luc Vermoesen"
__email__      = "luc.vermoesen@alcatel-lucent.com"
__status__     = "alpha"

from tempfile import mkstemp
from array import array
import subprocess 
import tarfile
import os

cmds=( 'ovs-vsctl -V'
     , 'ovs-vsctl show '
     , 'ovs-vsctl list manager'
     , 'ovs-vsctl list controller'
     , 'ovs-vsctl list interface'
     , 'ovs-vsctl list-br'
     , 'ovs-vsctl list-ports alubr0'
     , 'ovs-vsctl get-manager'
     , 'ovs-vsctl get-controller alubr0'
     , 'ovs-vsctl list br alubr0'
     , 'ovs-dpctl  show'
     , 'ovs-dpctl  dump-flows'
     , 'ovs-appctl memory/show '
     , 'ovs-appctl coverage/show '
     , 'ovs-appctl host/show'
     , 'ovs-appctl host/port-show'
     , 'ovs-appctl host/port-detailed-show'
     , 'ovs-appctl host/dump-flows'
     , 'ovs-appctl host/dump-detailed-flows'
     , 'ovs-appctl vm/show' 
     , 'ovs-appctl vm/port-show'
     , 'ovs-appctl vm/port-detailed-show'
     , 'ovs-appctl vm/dump-flows'
     , 'ovs-appctl vm/dump-detailed-flows'
     , 'ovs-appctl bridge/show'
     , 'ovs-appctl bridge/port-show'
     , 'ovs-appctl bridge/port-detailed-show'
     , 'ovs-appctl bridge/dump-flows alubr0'
     , 'ovs-appctl bridge/dump-flows-detail alubr0'
     , 'ovs-appctl bridge/acl-table in alubr0'
     , 'ovs-appctl bridge/acl-table out alubr0'
     , 'ovs-appctl lport/show alubr0'
     , 'ovs-appctl dpif/show'
     , 'ovs-appctl dpif/dump-flows alubr0'
     , 'ovs-appctl dpif/dump-flows -m alubr0'
     , 'ovs-appctl ipsec/list-cert alubr0'
     , 'ovs-appctl ipsec/list-policies alubr0'
     , 'ovs-appctl ipsec/list-sa alubr0'
     , 'ovs-appctl ipsec/list-seed alubr0'
     , 'ovs-appctl ipsec/list-sek alubr0'
     , 'ovs-appctl vrf/show alubr0'
     , 'ovs-appctl evpn/show alubr0'
     , 'ovs-appctl ofproto/show alubr0'
     , 'ovs-appctl fdb/show alubr0'
     , 'ovs-ofctl dump-ports-desc alubr0'
     )

vrfCmds=( 'ovs-appctl vrf/list alubr0'
        , 'ovs-appctl vrf/route-table <vrf-id> alubr0'
        , 'ovs-appctl vrf/show alubr0 {vrf_id}')

evpnCmds=( 'ovs-appctl evpn/list alubr0'
         , 'ovs-appctl evpn/arp-table <evpn-id> alubr0'
         , 'ovs-appctl evpn/dhcp-pool-show alubr0 <evpn-id>'
# , 'ovs-appctl evpn/dhcp-static-show alubr0 <evpn_id>' # incorrect
         , 'ovs-appctl evpn/dhcp-table <evpn-id>'
         , 'ovs-appctl evpn/dhcp-table-show alubr0 <evpn-id>'
         , 'ovs-appctl evpn/dump-flows alubr0 {evpn-id}'
         , 'ovs-appctl evpn/mac-table <evpn-id> alubr0 '
         , 'ovs-appctl evpn/show alubr0 {evpn-id}'
)

vmWareCmds= [ 'service esxMonit status' ]

def runCmd(cmd, f):
    f.write('# cmd: [%s]\n# \n' % (cmd)) 
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in p.stdout.readlines():
        f.write(line) 
    retval = p.wait()
    f.write('#\n\n') 
    return retval

def learnIds(cmd, idName, f):
    # output cli command:
    #     vrfs: 20950 20953
    ids = []
    f.write('# cmd: [%s]\n# \n' % (cmd)) 
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in p.stdout.readlines():
        f.write(line) 
        # todo extract vrfIds from output but i do not have an example yet
        if idName in line:
            ids = line.split()[1:]
    retval = p.wait()
    f.write('#\n\n') 
    return ids

def prepCmd(aCmd, replaceStr, anId):
    # e.g. format of cli command that references 'replaceStr' e.g. vrf-id:
    #     'ovs-appctl vrf/route-table <vrf-id> alubr0'
    #     'ovs-appctl vrf/show alubr0 {vrf_id}'
    if '<' in aCmd:
        aCmd = aCmd.replace('<' + replaceStr + '>', anId,1)
    else:
        aCmd = aCmd.rsplit(' ', 1)[0] + " " + anId 
    return aCmd

def learnESXPresence(cmd, f):
    files2tar = []
    # cli command: service esxMonit status
    # output of cli command is 
    #   if esx present
    #     jesx-events-process (3.2.3.0008) is running
    #   else
    #     esxMonit: unrecognized service
    f.write('# cmd: [%s]\n# \n' % (cmd)) 
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in p.stdout.readlines():
        f.write(line) 
        # todo extract vrfIds from output but i do not have an example yet
        if 'unrecognized' not in line:
            files2tar.append("/root/config.data")
    retval = p.wait()
    f.write('#\n\n') 
    return files2tar

def make_tarfile(tarFileBaseName, files2Tar):
    oFile = tarFileBaseName + ".tar.gz"
    try: 
        with tarfile.open(oFile, "w:gz") as tar:
            for f in files2Tar:
                tar.add(f, recursive=False) 
        tar.close()
    except: 
        # python version <2.7 has no support for 
        # the context manager protocol.
        print "detected python <2.7 version, tar file is incomplete!"
        print "!!! pls add following files to a tar archive with: "
        sys.stdout.write('tar zcf ')
        sys.stdout.write(oFile)
        sys.stdout.write(' ')
        for fe in files2Tar:
            sys.stdout.write(fe) 
            sys.stdout.write(' ') 
        print ""
        pass
    return oFile

########
# main #
########
import sys
try:
    import argparse
    parser=argparse.ArgumentParser(
        description='''script collecting configuration/runtime information about vrs/ovs. script has no need for any arguments and should be ran where VRS runs''',
        epilog="""Done.""")
    # parser.add_argument('--foo', type=int, default=42, help='FOO!')
    args=parser.parse_args()
except ImportError:
    if len(sys.argv) > 1:
        print "argparse module not available. bailing out"
        print "possible fix, run: pip install argparse"
        raise SystemExit

fd, tempPath = mkstemp( prefix='vrs_', suffix='.log')
print ("%-21s %s" % ("Collecting info in: ", tempPath))

file = open(tempPath, 'w')
for cmd in cmds:
    runCmd( cmd, file)

vrfIds = learnIds(vrfCmds[0], "vrfs", file)
for vrfCmd in vrfCmds[1:]:
    for vrfId in vrfIds: 
        runnableCmd = prepCmd(vrfCmd, 'vrf-id', vrfId) 
        runCmd(runnableCmd, file)

evpnIds = learnIds(evpnCmds[0], "evpns", file)
for evpnCmd in evpnCmds[1:]:
    for evpnId in evpnIds: 
        runnableEvpnCmd = prepCmd(evpnCmd, 'evpn-id', evpnId) 
        runCmd(runnableEvpnCmd, file)

# if on VMWare managed machine, 
vmfiles = learnESXPresence(vmWareCmds[0], file)

file.close()
os.close(fd)

# list all files that need to be added to tar 
files2tar = []
files2tar.append(tempPath)
files2tar = files2tar + vmfiles

# select tar name and tar files
filename, file_extension = os.path.splitext(tempPath)
tarFile = make_tarfile(filename, files2tar)

print ("%-21s %s" % ("tar file is at: ", tarFile))
print 'Cleanup:'
print ("rm -f %s" % tempPath)
print ("rm -f %s" % tarFile)
