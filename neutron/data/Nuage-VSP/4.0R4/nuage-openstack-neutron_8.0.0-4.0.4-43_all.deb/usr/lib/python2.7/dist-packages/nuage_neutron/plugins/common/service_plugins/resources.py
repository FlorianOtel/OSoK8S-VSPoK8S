from neutron.callbacks.resources import *  # noqa

FLOATING_IP = 'floatingip'
