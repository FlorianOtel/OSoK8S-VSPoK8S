# Copyright 2015 Alcatel-Lucent USA Inc.
# All Rights Reserved.

import logging

from nuagenetlib.common import constants
from nuagenetlib.common import helper
from nuagenetlib.common.cms_id_helper import get_vsd_external_id
from nuagenetlib.common.cms_id_helper import strip_cms_id
from nuagenetlib.common import pnet_helper
from nuagenetlib.resources import dhcpoptions
from nuagenetlib import nuagelib
from nuagenetlib import restproxy

CONFLICT_ERR_CODE = constants.VSD_RESP_OBJ
VSD_RESP_OBJ = constants.VSD_RESP_OBJ
RES_EXISTS_INTERNAL_ERR_CODE = constants.RES_EXISTS_INTERNAL_ERR_CODE

LOG = logging.getLogger(__name__)


class NuageL2Domain(object):
    def __init__(self, restproxy, policygroups):
        self.restproxy = restproxy
        self.policygroups = policygroups

    def get_subnet_by_netpart(self, netpart_id):
        nuagel2dom = nuagelib.NuageL2Domain({'net_partition_id': netpart_id})
        response = self.restproxy.rest_call(
            'GET', nuagel2dom.get_all_resources_in_ent(), '')
        if not nuagel2dom.validate(response):
            raise restproxy.RESTProxyError(nuagel2dom.error_msg)
        res = []
        for l2dom in nuagel2dom.get_response_objlist(response):
            np_dict = dict()
            np_dict['domain_name'] = l2dom['name']
            np_dict['domain_id'] = l2dom['ID']
            np_dict['subnet_os_id'] = strip_cms_id(l2dom['externalID'])
            res.append(np_dict)
        return res

    def get_subnet_by_id(self, nuage_id):
        nuagel2dom = nuagelib.NuageL2Domain()
        l2domain = self.restproxy.get(nuagel2dom.get_resource(nuage_id),
                                      required=True)[0]
        res = helper.make_subnet_dict(l2domain)
        res['subnet_parent_id'] = l2domain['parentID']
        return res

    def create_subnet(self, neutron_subnet, params):
        net = params['net']
        req_params = {
            'net_partition_id': params['netpart_id'],
            'name': neutron_subnet['id'],
        }
        ext_params = {
            "DHCPManaged": neutron_subnet['enable_dhcp'],
            "address": str(net.ip),
            "netmask": str(net.netmask),
            "gateway": params['dhcp_ip'],
        }
        nuagel2domtmplt = nuagelib.NuageL2DomTemplate(create_params=req_params,
                                                      extra_params=ext_params)
        response = self.restproxy.rest_call('POST',
                                            nuagel2domtmplt.post_resource(),
                                            nuagel2domtmplt.post_data())

        if not nuagel2domtmplt.validate(response):
            error_code = nuagel2domtmplt.get_error_code(response)
            int_error_code = nuagel2domtmplt.vsd_error_code
            # 2510 is the internal error code returned by VSD in case
            # template already exists
            if (error_code != CONFLICT_ERR_CODE or
                (error_code == CONFLICT_ERR_CODE and
                 int_error_code != RES_EXISTS_INTERNAL_ERR_CODE)):
                raise restproxy.RESTProxyError(nuagel2domtmplt.error_msg,
                                               nuagel2domtmplt.vsd_error_code)

            # If the template exists, then just get the template id and use
            # it. This scenario is seen when the tmplt exists but the l2dom
            # is deleted from VSD. During sync we want to use the same
            # tmplt if it exists
            response = self.restproxy.rest_call('GET',
                                      nuagel2domtmplt.list_resource(), '',
                                      nuagel2domtmplt.extra_headers_get())
            if not nuagel2domtmplt.validate(response):
                raise restproxy.RESTProxyError(nuagel2domtmplt.error_msg)

        l2dom_tmplt_id = nuagel2domtmplt.get_templateid(response)

        subnet_dict = {}
        subnet_dict['nuage_l2template_id'] = l2dom_tmplt_id
        req_params = {
            'net_partition_id': params['netpart_id'],
            'name': neutron_subnet['id'],
            'template': l2dom_tmplt_id,
            'externalID': get_vsd_external_id(neutron_subnet['id'])
        }
        ext_params = {
            'description': neutron_subnet['name']
        }
        nuagel2domain = nuagelib.NuageL2Domain(create_params=req_params,
                                               extra_params=ext_params)
        response = self.restproxy.rest_call(
            'POST', nuagel2domain.post_resource(),
            nuagel2domain.post_data())
        if not nuagel2domain.validate(response):
            if not nuagel2domain.resource_exists(response):
                code = nuagel2domain.get_error_code(response)
                raise restproxy.RESTProxyError(nuagel2domain.error_msg,
                                               error_code=code)
            response = self.restproxy.rest_call(
                'GET', nuagel2domain.get_resource_with_ext_id(), '',
                extra_headers=nuagel2domain.extra_headers_get())
            if not nuagel2domain.get_validate(response):
                raise restproxy.RESTProxyError(nuagel2domain.error_msg)

        l2domain_id = nuagel2domain.get_domainid(response)
        external_id = nuagel2domain.get_response_externalid(response)
        parent_id = nuagel2domain.get_response_parentid(response)
        subnet_dict['nuage_l2domain_id'] = l2domain_id
        subnet_dict['nuage_external_id'] = strip_cms_id(external_id)
        subnet_dict['nuage_parent_id'] = parent_id

        nuagedhcpoptions = dhcpoptions.NuageDhcpOptions(self.restproxy)
        nuagedhcpoptions.create_nuage_dhcp(neutron_subnet,
                                        parent_id=l2domain_id,
                                        network_type=constants.NETWORK_TYPE_L2)

        nuage_userid, nuage_groupid = \
            helper._create_usergroup(self.restproxy,
                                    params['tenant_id'],
                                    params['netpart_id'])
        subnet_dict['nuage_userid'] = nuage_userid
        subnet_dict['nuage_groupid'] = nuage_groupid

        self._attach_nuage_group_to_l2domain(nuage_groupid,
                                             l2domain_id,
                                             params['netpart_id'],
                                             params.get('shared'))
        self._create_nuage_def_l2domain_acl(l2domain_id)
        self._create_nuage_def_l2domain_adv_fwd_template(l2domain_id)

        pnet_binding = params.get('pnet_binding', None)
        if pnet_binding:
            pnet_params = {
                'pnet_binding': pnet_binding,
                'netpart_id': params['netpart_id'],
                'l2domain_id': l2domain_id,
                'neutron_subnet_id': neutron_subnet['id']
            }
            try:
                pnet_helper.process_provider_network(self.restproxy,
                                                     self.policygroups,
                                                     pnet_params)
            except Exception:
                self.delete_subnet(neutron_subnet['id'])
                raise

        return subnet_dict

    def delete_subnet(self, id):
        params = {
            'externalID': get_vsd_external_id(id)
        }
        nuagel2domain = nuagelib.NuageL2Domain(create_params=params)
        response = self.restproxy.rest_call(
            'GET', nuagel2domain.get_resource_with_ext_id(), '',
            extra_headers=nuagel2domain.extra_headers_get())

        if nuagel2domain.get_validate(response):
            nuagel2domtemplates = nuagelib.NuageL2DomTemplate()
            template_id = nuagel2domain.get_template_id(response)
            resp_temp = self.restproxy.rest_call(
                'GET', nuagel2domtemplates.get_resource(template_id), '')
            if not nuagel2domtemplates.validate(resp_temp):
                raise restproxy.RESTProxyError(nuagel2domtemplates.error_msg)
            l2domain_id = nuagel2domain.get_domainid(response)

            try:
                # Delete bridge_interface and bridge vport if it is subnet
                # created for providernet
                pnet_helper.delete_resources_created_for_l2dom_providernet(
                    self.restproxy, l2domain_id)
                # delete subnet
                l2dom_delete_response = self.restproxy.rest_call(
                    'DELETE', nuagel2domain.delete_resource(l2domain_id), '')
                if not nuagel2domain.delete_validate(l2dom_delete_response):
                    code = nuagel2domain.get_error_code(l2dom_delete_response)
                    raise restproxy.RESTProxyError(nuagel2domain.error_msg,
                                                   error_code=code)
            except:
                raise

            if response[3][0]['name'] == resp_temp[3][0]['name']:
                try:
                    self.restproxy.rest_call('DELETE',
                        nuagel2domtemplates.delete_resource(template_id), '')
                except:
                    raise

    def update_subnet(self, neutron_subnet, params):
        type = constants.NETWORK_TYPE_L3
        new_name = neutron_subnet.get('name')
        if params['type']:
            type = constants.NETWORK_TYPE_L2

        nuagedhcpoptions = dhcpoptions.NuageDhcpOptions(self.restproxy)
        nuagedhcpoptions.create_nuage_dhcp(neutron_subnet,
                                           parent_id=params['parent_id'],
                                           network_type=type)

        if type == constants.NETWORK_TYPE_L2 and 'dhcp_ip' in params:
            nuagel2domtemplate = nuagelib.NuageL2DomTemplate()
            if neutron_subnet.get('enable_dhcp'):
                # Enable dhcpmanaged on the l2domain template
                net = params['net']
                data = {
                    "DHCPManaged": neutron_subnet['enable_dhcp'],
                    "address": str(net.ip),
                    "netmask": str(net.netmask),
                    "gateway": params['dhcp_ip'],
                }
                response = self.restproxy.rest_call(
                    'PUT',
                    nuagel2domtemplate.put_resource(params['type']),
                    data
                )
            else:
                # Disable dhcpmanaged on the l2domain template
                response = self.restproxy.rest_call(
                    'PUT',
                    nuagel2domtemplate.put_resource(params['type']),
                    {'DHCPManaged': False}
                )
            if not nuagel2domtemplate.validate(response):
                    raise restproxy.RESTProxyError(
                        nuagel2domtemplate.error_msg)
        if new_name:
            # update the description on the VSD for this subnet if required
            # If a subnet is updated from horizon, we get the name of the
            # subnet aswell in the subnet dict for update.
            if type == constants.NETWORK_TYPE_L2:
                nuagel2domain = nuagelib.NuageL2Domain()
                l2dom = self.restproxy.rest_call(
                    'GET', nuagel2domain.get_resource(params['parent_id']), '')
                if not nuagel2domain.validate(l2dom):
                    raise restproxy.RESTProxyError(nuagel2domain.error_msg)
                if nuagel2domain.get_description(l2dom) != new_name:
                    response = self.restproxy.rest_call(
                        'PUT', nuagel2domain.put_resource(params['parent_id']),
                        {'description': neutron_subnet['name']})
                    if not nuagel2domain.validate(response):
                        raise restproxy.RESTProxyError(nuagel2domain.error_msg)
            else:
                nuagesubn = nuagelib.NuageSubnet()
                l3dom = self.restproxy.rest_call(
                    'GET', nuagesubn.get_resource(params['parent_id']), '')
                if not nuagesubn.validate(l3dom):
                    raise restproxy.RESTProxyError(nuagesubn.error_msg)
                if nuagesubn.get_description(l3dom) != new_name:
                    response = self.restproxy.rest_call(
                        'PUT', nuagesubn.put_resource(params['parent_id']),
                        {'description': neutron_subnet['name']})
                    if not nuagesubn.validate(response):
                        raise restproxy.RESTProxyError(nuagesubn.error_msg)

    def _attach_nuage_group_to_l2domain(self, nuage_groupid,
                                        nuage_subnetid, nuage_npid,
                                        shared):
        if not shared:
            nuagegroup = nuagelib.NuageGroup()
            self.restproxy.rest_call('PUT',
                           nuagegroup.l2dom_attach_resource(nuage_subnetid),
                           nuagegroup.l2dom_attach_data(nuage_groupid))
        else:
            params = {
                'net_partition_id': nuage_npid
            }
            nuagegroup = nuagelib.NuageGroup(create_params=params)
            response = self.restproxy.rest_call(
                'GET', nuagegroup.list_resource(), '',
                nuagegroup.extra_headers_get_for_everybody())
            if not nuagegroup.validate(response):
                raise restproxy.RESTProxyError(nuagegroup.error_msg)
            nuage_all_groupid = nuagegroup.get_groupid(response)
            self.restproxy.rest_call('PUT',
                           nuagegroup.l2dom_attach_resource(nuage_subnetid),
                           nuagegroup.l2dom_attach_data(nuage_all_groupid))

    def _create_nuage_def_l2domain_acl(self, id):
        helper._create_nuage_l2dom_ingress_tmplt(self.restproxy, id)
        helper._create_nuage_l2dom_egress_tmplt(self.restproxy, id)

    def _create_nuage_def_l2domain_adv_fwd_template(self, l2dom_id):
        nuageadvfwdtmplt = nuagelib.NuageInAdvFwdTemplate()
        response = self.restproxy.rest_call('POST',
                                  nuageadvfwdtmplt.post_resource_l2(l2dom_id),
                                  nuageadvfwdtmplt.post_data_default_l2(
                                      l2dom_id))
        if not nuageadvfwdtmplt.validate(response):
            raise restproxy.RESTProxyError(nuageadvfwdtmplt.error_msg)
        return nuageadvfwdtmplt.get_response_objid(response)

    def get_nuage_cidr(self, nuage_subnetid):
        nuagesubn = nuagelib.NuageSubnet()
        response = self.restproxy.rest_call('GET',
                                  nuagesubn.get_resource(nuage_subnetid),
                                  '')
        if not nuagesubn.validate(response):
            nuagel2dom = nuagelib.NuageL2Domain()
            response = self.restproxy.rest_call('GET',
                                      nuagel2dom.get_resource(nuage_subnetid),
                                      '')
            if not nuagel2dom.validate(response):
                raise restproxy.RESTProxyError(nuagel2dom.error_msg)
            return nuagel2dom.get_cidr_info(response)
        else:
            return nuagesubn.get_cidr_info(response)

    def attach_nuage_group_to_nuagenet(self, tenant, nuage_npid,
                                       nuage_subnetid, shared):
        nuage_uid, nuage_gid = helper._create_usergroup(self.restproxy, tenant,
                                                        nuage_npid)
        nuagesubn = nuagelib.NuageSubnet()
        nuagegroup = nuagelib.NuageGroup()

        if shared:
            # Get the id for grp 'everybody'
            params = {
                'net_partition_id': nuage_npid
            }
            nuagegroup = nuagelib.NuageGroup(create_params=params)
            response = self.restproxy.rest_call(
                'GET', nuagegroup.list_resource(), '',
                nuagegroup.extra_headers_get_for_everybody())
            if not nuagegroup.validate(response):
                raise restproxy.RESTProxyError(nuagegroup.error_msg)
            nuage_all_groupid = nuagegroup.get_groupid(response)

        response = self.restproxy.\
            rest_call('GET', nuagesubn.get_resource(nuage_subnetid),
                      '')
        if not nuagesubn.validate(response):
            nuagel2dom = nuagelib.NuageL2Domain()
            response = self.restproxy.\
                rest_call('GET', nuagel2dom.get_resource(nuage_subnetid),
                          '')
            if not nuagel2dom.validate(response):
                raise restproxy.RESTProxyError(nuagel2dom.error_msg)
            resource = nuagegroup.l2dom_attach_resource(nuage_subnetid)
            if shared:
                self.restproxy.rest_call(
                    'PUT',
                    resource,
                    nuagegroup.l2dom_attach_data(nuage_all_groupid))
                return nuage_uid, nuage_gid
        else:
            resource = nuagegroup.zone_attach_resource(
                nuagesubn.get_parentzone(response))
            if shared:
                self.restproxy.rest_call(
                    'PUT',
                    resource,
                    nuagegroup.zone_attach_data(nuage_all_groupid))
                return nuage_uid, nuage_gid

        response = self.restproxy.rest_call('GET', resource, '')
        if not nuagegroup.validate(response):
            raise restproxy.RESTProxyError(nuagel2dom.error_msg)
        groups = nuagegroup.group_list(response)
        data = []
        for group in groups:
            data.append(group['ID'])
        data.append(nuage_gid)
        response = self.restproxy.rest_call('PUT', resource, data)
        if not nuagegroup.validate(response):
            raise restproxy.RESTProxyError(nuagegroup.error_msg,
                                           nuagegroup.vsd_error_code)
        return nuage_uid, nuage_gid

    def detach_nuage_group_to_nuagenet(
            self, tenant, nuage_npid, nuage_subnetid, shared):
        nuage_uid, nuage_gid = helper._create_usergroup(self.restproxy, tenant,
                                                        nuage_npid)
        nuagesubn = nuagelib.NuageSubnet()
        nuagegroup = nuagelib.NuageGroup()

        if shared:
            # Get the id for grp 'everybody'
            params = {
                'net_partition_id': nuage_npid
            }
            nuagegroup = nuagelib.NuageGroup(create_params=params)
            response = self.restproxy.rest_call(
                'GET', nuagegroup.list_resource(), '',
                nuagegroup.extra_headers_get_for_everybody())
            if not nuagegroup.validate(response):
                if response[0] == 404:
                    return
                raise restproxy.RESTProxyError(nuagegroup.error_msg,
                                               nuagegroup.vsd_error_code)
            nuage_all_groupid = nuagegroup.get_groupid(response)

        response = self.restproxy.rest_call('GET',
                                  nuagesubn.get_resource(nuage_subnetid),
                                  '')
        if not nuagesubn.validate(response):
            nuagel2dom = nuagelib.NuageL2Domain()
            response = self.restproxy.rest_call('GET',
                                      nuagel2dom.get_resource(nuage_subnetid),
                                      '')
            if not nuagel2dom.validate(response):
                # This is the case where the VSD-Managed subnet is deleted
                # from VSD first and then neutron subnet-delete operation
                # is performed from openstack
                # for both l2/l3 case we'll return form here
                return
            resource = nuagegroup.l2dom_attach_resource(nuage_subnetid)
        else:
            zone_id = nuagesubn.get_parentzone(response)
            resource = nuagegroup.zone_attach_resource(zone_id)
            nuage_dom = helper.get_nuage_domain_by_zoneid(self.restproxy,
                                                          zone_id)

            if nuage_dom['externalID']:
                # The perm. attached to the zone when the router is deleted
                # from openstack
                return

        response = self.restproxy.rest_call('GET', resource, '')
        if not nuagegroup.validate(response):
            if response[0] == 404:
                return
            raise restproxy.RESTProxyError(nuagegroup.error_msg,
                                           nuagegroup.vsd_error_code)

        groups = nuagegroup.group_list(response)
        data = []
        if shared:
            for group in groups:
                if group['ID'] != nuage_all_groupid:
                    data.append(group['ID'])
            self.restproxy.rest_call('PUT', resource, data)
        else:
            for group in groups:
                if group['ID'] != nuage_gid:
                    data.append(group['ID'])
            self.restproxy.rest_call('PUT', resource, data)

    def get_nuage_sharedresource(self, id):
        nuage_sharedresource = nuagelib.NuageSharedResources()
        response = self.restproxy.rest_call(
            'GET', nuage_sharedresource.get_resource_by_id(id), '')
        if not nuage_sharedresource.get_validate(response):
            raise restproxy.RESTProxyError(
                nuage_sharedresource.error_msg,
                nuage_sharedresource.vsd_error_code)
        resource = nuage_sharedresource.get_response_obj(response)
        return {'subnet_address': resource['address'],
                'subnet_netmask': resource['netmask'],
                'subnet_gateway': resource['gateway']}

    def get_sharedresource(self, neutron_id):
        return self._get_sharedresource_by_external(neutron_id)

    def create_nuage_sharedresource(self, params):
        subnet = params['neutron_subnet']
        req_params = {
            'name': subnet['id'],
            'gateway_ip': subnet['gateway_ip'],
            'net': params['net'],
            'type': params['type'],
            'net_id': params['net_id'],
            'externalID': get_vsd_external_id(subnet['id'])
        }
        desc_str = params['net_id'] + '_' + subnet['name']
        extra_params = {
            'description': desc_str
        }
        if params.get('underlay_config'):
            extra_params['underlay'] = True
        if params.get('underlay') is not None:
            extra_params['underlay'] = params['underlay']
        if params.get('nuage_uplink'):
            extra_params['sharedResourceParentID'] = params['nuage_uplink']

        nuage_sharedresource = nuagelib.NuageSharedResources(
            create_params=req_params, extra_params=extra_params)
        response = self.restproxy.rest_call('POST',
                                  nuage_sharedresource.post_resource(),
                                  nuage_sharedresource.post_data())
        if not nuage_sharedresource.validate(response):
            code = nuage_sharedresource.get_error_code(response)
            raise restproxy.RESTProxyError(nuage_sharedresource.error_msg,
                                           code)
        return nuage_sharedresource.get_sharedresource_id(response)

    def _get_sharedresource_by_external(self, neutron_id):
        create_params = {
            'externalID': get_vsd_external_id(neutron_id)
        }
        nuage_sharedresource = nuagelib.NuageSharedResources(create_params)
        url = nuage_sharedresource.get_resource()
        extra_headers = nuage_sharedresource.extra_headers_get_by_externalID()
        response = self.restproxy.rest_call('GET', url, '', extra_headers)
        if not nuage_sharedresource.get_validate(response):
            raise restproxy.RESTProxyError(nuage_sharedresource.error_msg)
        return nuage_sharedresource.get_response_obj(response)

    def update_nuage_sharedresource(self, neutron_id, params):
        nuage_id = self._get_sharedresource_by_external(neutron_id)['ID']

        req_params = {}
        if params.get('net_id') and params.get('subnet_name'):
            description = params['net_id'] + '_' + params['subnet_name']
            req_params['description'] = description
        if params.get('gateway_ip'):
            req_params['gateway'] = params.get('gateway_ip')
        if not req_params:
            return

        create_params = {
            'id': nuage_id
        }
        nuage_sharedresource = nuagelib.NuageSharedResources(create_params,)
        url = nuage_sharedresource.put_resource()
        self.restproxy.rest_call('PUT', url, req_params)

    def delete_nuage_sharedresource(self, id):
        req_params = {
            'name': id
        }
        nuage_sharedresource = nuagelib.NuageSharedResources(
            create_params=req_params)
        sharedresource = self.restproxy.get(
            nuage_sharedresource.get_resource(),
            extra_headers=nuage_sharedresource.extra_headers_get_by_name())
        if sharedresource:
            self._delete_nuage_sharedresource(sharedresource[0]['ID'])

    def _delete_nuage_sharedresource(self, id):
        nuage_sharedresource = nuagelib.NuageSharedResources()
        resp = self.restproxy.rest_call(
            'DELETE', nuage_sharedresource.delete_resource(id), '')
        if not nuage_sharedresource.validate(resp):
            code = nuage_sharedresource.get_error_code(resp)
            raise restproxy.RESTProxyError(nuage_sharedresource.error_msg,
                                           error_code=code)

    def get_gateway_ip_for_advsub(self, nuage_l2dom_id):
        LOG.debug("NuageClient.get_gateway_ip_for_advsub() called")
        nuagesubn = nuagelib.NuageSubnet()
        l3subnet = self.restproxy.get(nuagesubn.get_resource(nuage_l2dom_id),
                                      required=False)
        if l3subnet:
            return l3subnet[0]['gateway']
        else:
            nuagel2dom = nuagelib.NuageL2Domain()
            dhcpoptions = self.restproxy.get(
                nuagel2dom.dhcp_get_resource(nuage_l2dom_id))
            # dhcp_port_exist will exist in case for adv. subnet when it is
            # set via rest call on VSD
            gw_ip = None
            for dhcpoption in dhcpoptions:
                if dhcpoption['type'] == constants.DHCP_ROUTER_OPTION:
                    gw_ip = nuagel2dom.get_gwIp_set_via_dhcp(dhcpoption)
            return gw_ip

    def check_if_l2Dom_in_correct_ent(self, nuage_l2dom_id, nuage_netpart):
        nuagesubn = nuagelib.NuageSubnet()
        resp_subn = self.restproxy.rest_call(
            'GET',
            nuagesubn.get_resource(nuage_l2dom_id),
            '')
        if not nuagesubn.validate(resp_subn):
            nuagel2dom = nuagelib.NuageL2Domain()
            response = self.restproxy.rest_call(
                'GET',
                nuagel2dom.get_resource(nuage_l2dom_id),
                '')
            if not nuagel2dom.validate(response):
                raise restproxy.RESTProxyError(nuagel2dom.error_msg)
            else:
                if response[3][0]['parentID'] == nuage_netpart['id']:
                    return True
                return False
        else:
            req_params = {
                'zone_id': resp_subn[3][0]['parentID']
            }
            nuagezone = nuagelib.NuageZone(create_params=req_params)
            resp_zone = self.restproxy.rest_call(
                'GET', nuagezone.get_resource(), '')

            if not nuagezone.validate(resp_zone):
                raise restproxy.RESTProxyError(nuagezone.error_msg)

            req_params = {
                'domain_id': resp_zone[3][0]['parentID']
            }
            nuage_l3domain = nuagelib.NuageL3Domain(create_params=req_params)
            dom_resp = self.restproxy.rest_call(
                'GET', nuage_l3domain.get_resource(), '')

            if not nuage_l3domain.validate(dom_resp):
                raise restproxy.RESTProxyError(nuage_l3domain.error_msg)
            if dom_resp[3][0]['parentID'] == nuage_netpart['id']:
                return True
            return False

    def get_gw_from_dhcp_options(self, nuage_id):
        l2domain = nuagelib.NuageL2Domain()
        dhcpoptions = self.restproxy.get(l2domain.dhcp_get_resource(nuage_id))
        for dhcpoption in dhcpoptions:
            if dhcpoption['type'] == constants.DHCP_ROUTER_OPTION:
                return l2domain.get_gwIp_set_via_dhcp(dhcpoption)
