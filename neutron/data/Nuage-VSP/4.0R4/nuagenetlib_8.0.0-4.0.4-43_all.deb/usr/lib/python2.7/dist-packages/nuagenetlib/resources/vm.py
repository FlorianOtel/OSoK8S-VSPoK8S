# Copyright 2015 Alcatel-Lucent USA Inc.
# All Rights Reserved.

import logging
from netaddr import IPAddress
from netaddr import IPNetwork

from nuagenetlib.common import constants
from nuagenetlib.common import helper
from nuagenetlib.common.cms_id_helper import get_vsd_external_id
from nuagenetlib import nuagelib
from nuagenetlib import restproxy

LOG = logging.getLogger(__name__)

ACTION_NOOP = "noop"
ACTION_MACSPOOFING = "macspoofing"
ACTION_NOVIP = "novipallowed"
ACTION_VIP = "createvip"


class NuageVM(object):
    def __init__(self, restproxy_serv):
        self.restproxy = restproxy_serv

    def vms_on_l2domain(self, l2dom_id):
        nuagel2dom = nuagelib.NuageL2Domain()
        response = self.restproxy.rest_call(
            'GET',
            nuagel2dom.vm_get_resource(l2dom_id),
            '')
        return nuagel2dom.vm_exists(response)

    def vms_on_subnet(self, subnet_id):
        nuagesubnet = nuagelib.NuageSubnet()
        response = self.restproxy.rest_call(
            'GET',
            nuagesubnet.vm_get_resource(subnet_id),
            '')
        return nuagesubnet.vm_exists(response)

    def _get_nuage_vm(self, params, isdelete=False):
        req_params = {
            'id': params['id']
        }

        extra_params = {
            'tenant': params['tenant'],
            'net_partition_name': params['netpart_name']
        }
        nuagevm = nuagelib.NuageVM(create_params=req_params,
                                   extra_params=extra_params)
        response = self.restproxy.rest_call(
            'GET',
            nuagevm.get_resource(), '',
            extra_headers=nuagevm.extra_headers_get())
        if nuagevm.get_validate(response):
            vm_id = nuagevm.get_response_objid(response)
        else:
            if isdelete:
                vm_id = None
            else:
                msg = 'VM with uuid %s not found on VSD' % params['id']
                raise restproxy.RESTProxyError(msg)
        return vm_id

    def _attach_groupid_list_to_l2domain(self, nuage_grpid_list,
                                         nuage_subnetid):
        nuagegroup = nuagelib.NuageGroup()
        self.restproxy.rest_call(
            'PUT', nuagegroup.l2dom_attach_resource(nuage_subnetid),
            nuagegroup.l2dom_attach_groupid_list(nuage_grpid_list))

    def _attach_groupid_list_to_zone(self, nuage_grpid_list,
                                     nuage_zoneid):
        nuagegroup = nuagelib.NuageGroup()
        self.restproxy.rest_call(
            'PUT', nuagegroup.zone_attach_resource(nuage_zoneid),
            nuagegroup.zone_attach_groupid_list(nuage_grpid_list))

    def _make_grp_id_list(self, params):
        nuage_grp_id_list = []
        if params['subn_tenant'] != params['tenant']:
            nuage_userid, nuage_groupid = helper._create_usergroup(
                self.restproxy, params['subn_tenant'],
                params['netpart_id'])
            nuage_grp_id_list.append(nuage_groupid)
        nuage_userid, nuage_groupid = helper._create_usergroup(
            self.restproxy, params['tenant'], params['netpart_id'])
        nuage_grp_id_list.append(nuage_groupid)
        return nuage_grp_id_list

    def _attach_reqd_perm_for_vm_boot(self, params, id, on_l2=True):
        if on_l2:
            # if the vm is to be attached on a non-shared n/w and the request
            # is from an admin tenant, then add the permissions to the l2domain
            # so that the admin tenant can boot a VM on a l2domain that was
            # not created by admin himself.
            l2dom_id = id
            nuage_grp_id_list = self._make_grp_id_list(params)
            self._attach_groupid_list_to_l2domain(nuage_grp_id_list, l2dom_id)
        else:
            # if the vm is to be attached on a non-shared n/w and the request
            # is from an admin tenant, then add the permissions to the zone
            # so that the admin tenant can boot a VM on a domain-subnet
            # that was not created by him.
            zone_id = id
            nuage_perm = nuagelib.NuagePermission(
                create_params={'zone_id': zone_id})
            response = self.restproxy.rest_call(
                'GET', nuage_perm.get_resource_by_zone_id(), '')
            if not nuage_perm.validate(response):
                raise restproxy.RESTProxyError(nuage_perm.error_msg)
            for resp in nuage_perm.get_response_objlist(response):
                if resp['permittedEntityName'] == params['tenant']:
                    return

            nuage_grp_id_list = self._make_grp_id_list(params)
            self._attach_groupid_list_to_zone(nuage_grp_id_list, id)

    def _create_nuage_vm(self, params):
        req_params = {
            'id': params['id'],
            'mac': params['mac'],
            'ip': params['ip'],
            'externalID': get_vsd_external_id(params['port_id'])
        }
        if 'parent_id' in params.keys():
            parent_id = params['parent_id']
        else:
            parent_id = helper.get_nuage_l2dom_or_subnet(self.restproxy,
                                                         params['neutron_id'])
        #if vport_id passed in VMInterface and attachedNetworkId is not set,
        #VM create associates the passed vport to the VMInterface
        if params.get('vport_id') and not params.get('attached_network'):
            req_params['vport_id'] = params.get('vport_id')
        elif params.get('attached_network'):
            req_params['attachedNetworkID'] = parent_id

        req_params_dom = {
            'domain_id': parent_id
        }

        nuagesubn = nuagelib.NuageSubnet()
        resp_subn = self.restproxy.rest_call(
            'GET',
            nuagesubn.get_resource(parent_id),
            '')
        if not nuagesubn.validate(resp_subn):
            nuage_l2_domain = nuagelib.NuageL2Domain(
                create_params=req_params_dom)
            resp_l2_dom = self.restproxy.rest_call(
                'GET',
                nuage_l2_domain.get_resource(parent_id), '')

            if not nuage_l2_domain.validate(resp_l2_dom):
                raise restproxy.RESTProxyError(nuage_l2_domain.error_msg)

            self.send_or_drop_l2_domain_vm_ip(resp_l2_dom, req_params,
                                              params.get('dhcp_enabled'))

            if not params['portOnSharedSubn']:
                self._attach_reqd_perm_for_vm_boot(
                    params, resp_l2_dom[3][0]['ID'], on_l2=True)
        else:
            if not params['portOnSharedSubn']:
                self._attach_reqd_perm_for_vm_boot(
                    params, resp_subn[3][0]['parentID'], on_l2=False)
        extra_params = {
            'tenant': params['tenant'],
            'net_partition_name': params['netpart_name']
        }
        nuagevm = nuagelib.NuageVM(create_params=req_params,
                                   extra_params=extra_params)
        response = self.restproxy.rest_call(
            'POST',
            nuagevm.post_resource(),
            nuagevm.post_data(),
            extra_headers=nuagevm.extra_headers_post())

        if not nuagevm.validate(response):
            code = nuagevm.get_error_code(response)
            raise restproxy.RESTProxyError(nuagevm.error_msg, code)
        vm_dict = {}
        new_vmif = nuagevm.get_new_vmif(response)
        if new_vmif:
            vm_dict['ip'] = nuagevm.get_vmif_ip(new_vmif)
            vm_dict['vport_id'] = nuagevm.get_vmif_vportid(new_vmif)
            vm_dict['vif_id'] = nuagevm.get_vmif_id(new_vmif)

        return vm_dict

    def _create_nuage_vm_if(self, params):
        vm_id = self._get_nuage_vm(params)

        req_params = {
            'vm_id': vm_id,
            'mac': params['mac'],
            'ip': params['ip'],
            'externalID': get_vsd_external_id(params['port_id'])
        }

        extra_params = {
            'tenant': params['tenant'],
            'net_partition_name': params['netpart_name']
        }

        if 'parent_id' in params.keys():
            parent_id = params['parent_id']
        else:
            parent_id = helper.get_nuage_l2dom_or_subnet(self.restproxy,
                                                         params['neutron_id'])

        if params.get('vport_id') and not params.get('attached_network'):
            req_params['vport_id'] = params.get('vport_id')
        elif params.get('attached_network'):
            req_params['attachedNetworkID'] = parent_id

        req_params_dom = {
            'domain_id': parent_id
        }
        nuagesubn = nuagelib.NuageSubnet()
        resp_subn = self.restproxy.rest_call(
            'GET',
            nuagesubn.get_resource(parent_id),
            '')
        if not nuagesubn.validate(resp_subn):
            nuage_l2_domain = nuagelib.NuageL2Domain(
                create_params=req_params_dom)
            resp_dom = self.restproxy.rest_call(
                'GET',
                nuage_l2_domain.get_resource(parent_id), '')

            if not nuage_l2_domain.validate(resp_dom):
                raise restproxy.RESTProxyError(nuage_l2_domain.error_msg)

            self.send_or_drop_l2_domain_vm_ip(resp_dom, req_params,
                                              params.get('dhcp_enabled'))

            self._attach_reqd_perm_for_vm_boot(
                params, resp_dom[3][0]['ID'], on_l2=True)
        else:
            self._attach_reqd_perm_for_vm_boot(
                params, resp_subn[3][0]['parentID'], on_l2=False)

        nuagevmif = nuagelib.NuageVMInterface(create_params=req_params,
                                              extra_params=extra_params)
        response = self.restproxy.rest_call(
            'POST',
            nuagevmif.post_resource(),
            nuagevmif.post_data(),
            extra_headers=nuagevmif.extra_headers())

        if not nuagevmif.validate(response):
            code = nuagevmif.get_error_code(response)
            raise restproxy.RESTProxyError(nuagevmif.error_msg, code)

        vm_dict = {}
        vm_dict['ip'] = nuagevmif.get_vmif_ip(response)
        vm_dict['vport_id'] = nuagevmif.get_vport_id(response)
        vm_dict['vif_id'] = nuagevmif.get_vif_id(response)
        return vm_dict

    def send_or_drop_l2_domain_vm_ip(self, resp_dom, req_params, dhcp_enabled):
        #Decide if we have to send or drop IP to the VSD
        shared_resource_id = resp_dom[3][0].get(
                'associatedSharedNetworkResourceID')
        if not dhcp_enabled:
            req_params['ip'] = None
        elif (not resp_dom[3][0]['DHCPManaged']) and (
                not shared_resource_id):
            req_params['ip'] = None
        elif shared_resource_id:
            if not self.is_shared_l2_domain_managed(shared_resource_id):
                req_params['ip'] = None

    def is_shared_l2_domain_managed(self, shared_nuage_id):
        nuage_sharedresource = nuagelib.NuageSharedResources()
        response = self.restproxy.rest_call(
            'GET', nuage_sharedresource.get_resource_by_id(shared_nuage_id),
            '')
        if not nuage_sharedresource.get_validate(response):
            raise restproxy.RESTProxyError(nuage_sharedresource.error_msg)
        l2_shared = nuage_sharedresource.get_response_obj(response)
        return l2_shared.get('DHCPManaged')

    def create_vms(self, params):
        if params['no_of_ports'] > 1:
            nuage_vm = self._create_nuage_vm_if(params)
        else:
            nuage_vm = self._create_nuage_vm(params)
        return nuage_vm

    def _delete_vsd_permission_of_tenant(self, params, tenant):
        nuage_perm = nuagelib.NuagePermission(
            create_params=params)
        if 'l2dom_id' in params:
            response = self.restproxy.rest_call(
                'GET', nuage_perm.get_resource_by_l2dom_id(), '')
        elif 'zone_id' in params:
            response = self.restproxy.rest_call(
                'GET', nuage_perm.get_resource_by_zone_id(), '')

        if not nuage_perm.validate(response):
            raise restproxy.RESTProxyError(nuage_perm.error_msg)
        if len(nuage_perm.get_response_objlist(response)) > 1:
            for resp in nuage_perm.get_response_objlist(response):
                if resp['permittedEntityName'] == tenant:
                    response = self.restproxy.rest_call(
                        'DELETE', nuage_perm.delete_resource(
                            resp['ID']), '')
                    if not nuage_perm.validate(response):
                        raise restproxy.RESTProxyError(
                            nuage_perm.error_msg)
                    else:
                        break

    def _delete_extra_perm_attached(self, tenant, l2dom_id=None,
                                    l3dom_id=None):
        if l2dom_id:
            create_params = {'l2dom_id': l2dom_id}
            self._delete_vsd_permission_of_tenant(create_params,
                                                  tenant)
        elif l3dom_id:
            nuagesubnet = nuagelib.NuageSubnet()
            response = self.restproxy.rest_call(
                'GET', nuagesubnet.get_resource(l3dom_id),
                '')
            if not nuagesubnet.get_validate(response):
                raise restproxy.RESTProxyError(
                    nuagesubnet.error_msg, nuagesubnet.vsd_error_code)
            subnet = nuagesubnet.get_response_obj(response)
            create_params = {'zone_id': subnet['parentID']}
            self._delete_vsd_permission_of_tenant(create_params,
                                                  tenant)

    def _delete_nuage_vm(self, params):
        nuage_vm_id = self._get_nuage_vm(params, isdelete=True)
        if not nuage_vm_id:
            # It might already be deleted from the VSD
            return
        req_params = {
            'id': nuage_vm_id,
        }

        extra_params = {
            'tenant': params['tenant'],
            'net_partition_name': params['netpart_name']
        }

        nuagevm = nuagelib.NuageVM(create_params=req_params,
                                   extra_params=extra_params)
        resp = self.restproxy.rest_call('DELETE',
                       nuagevm.delete_resource(),
                       '',
                       extra_headers=nuagevm.extra_headers_delete())
        if not nuagevm.delete_validate(resp):
            raise restproxy.RESTProxyError(nuagevm.error_msg,
                                           nuagevm.vsd_error_code)
        if (not params['portOnSharedSubn'] and
                (params['subn_tenant'] != params['tenant'])):
            self._delete_extra_perm_attached(params['tenant'],
                                             params['l2dom_id'],
                                             params['l3dom_id'])

    def _delete_nuage_vm_if(self, params):
        LOG.debug("NuageClient._delete_nuage_vm_if() called")
        req_params = {
            'id': params['nuage_vif_id'],
        }
        extra_params = {
            'tenant': params['tenant'],
            'net_partition_name': params['netpart_name']
        }

        nuagevmif = nuagelib.NuageVMInterface(create_params=req_params,
                                              extra_params=extra_params)
        resp = self.restproxy.rest_call(
            'DELETE',
            nuagevmif.delete_resource(), '',
            extra_headers=nuagevmif.extra_headers())
        if not nuagevmif.delete_validate(resp):
            raise restproxy.RESTProxyError(nuagevmif.error_msg,
                                           nuagevmif.vsd_error_code)
        if (not params['portOnSharedSubn'] and
                (params['subn_tenant'] != params['tenant'])):
            self._delete_extra_perm_attached(params['tenant'],
                                             params['l2dom_id'],
                                             params['l3dom_id'])

    def delete_vms(self, params):
        LOG.debug("NuageClient.delete_vms() called")
        if params['no_of_ports'] > 1:
            self._delete_nuage_vm_if(params)
        else:
            self._delete_nuage_vm(params)

    def update_nuage_vm_vport(self, params):
        req_params = {
            'vport_id': params['nuage_vport_id'],
            'fip_id': params['nuage_fip_id']
        }
        nuage_fip = None
        nuagevport = nuagelib.NuageVPort(create_params=req_params)
        if params['nuage_fip_id']:
            nuage_fip = self.restproxy.rest_call('GET',
                                                 nuagevport.get_resource(),
                                                 '')
        # call PUT only if fip_id update required for the vport or when passed
        # nuage_fip_id param is None
        if (not nuage_fip or
                (nuage_fip and (nuage_fip[3][0]['associatedFloatingIPID'] !=
                                params['nuage_fip_id']))):
            resp = self.restproxy.rest_call('PUT',
                                            nuagevport.put_resource(),
                                            nuagevport.fip_update_data())
            if not nuagevport.validate(resp):
                raise restproxy.RESTProxyError(nuagevport.error_msg)

    def create_vport(self, params):
        if 'parent_id' in params.keys():
            parent_id = params['parent_id']
        else:
            parent_id = helper.get_nuage_l2dom_or_subnet(self.restproxy,
                                                         params['neutron_id'])
        vport_params = {
            'port_id': params['port_id'],
            'type': 'VM',
            'name': params['port_id'],
            'externalID': get_vsd_external_id(params['port_id']),
            'description': params.get('description'),
            'addressSpoofing': params['address_spoof']
        }
        if params.get('name'):
            vport_params['name'] = params['name']
        req_params_dom = {
            'domain_id': parent_id
        }

        nuagesubn = nuagelib.NuageSubnet()
        resp_subn = self.restproxy.rest_call(
            'GET',
            nuagesubn.get_resource(parent_id),
            '')
        if not nuagesubn.validate(resp_subn):
            nuage_l2_domain = nuagelib.NuageL2Domain(
                create_params=req_params_dom)
            resp_l2_dom = self.restproxy.rest_call(
                'GET',
                nuage_l2_domain.get_resource(parent_id), '')
            if not nuage_l2_domain.validate(resp_l2_dom):
                raise restproxy.RESTProxyError(nuage_l2_domain.error_msg)
            l2dom_id = resp_l2_dom[3][0]['ID']
            vport_response = self.restproxy.rest_call(
                'POST',
                nuage_l2_domain.vport_post(l2dom_id),
                nuage_l2_domain.vm_vport_post_data(vport_params))
            if not nuage_l2_domain.validate(vport_response):
                raise restproxy.RESTProxyError(nuage_l2_domain.error_msg)
        else:
            # Create vport in domain subnet
            vport_response = self.restproxy.rest_call(
                'POST',
                nuagesubn.vport_post(resp_subn[3][0]['ID']),
                nuagesubn.vm_vport_post_data(vport_params))

            if not nuagesubn.validate(vport_response):
                raise restproxy.RESTProxyError(nuagesubn.error_msg)

        # Returning a dictionary such that if required
        # we can add more attributes in future to it.
        vport_dict = {
            'nuage_vport_id': vport_response[3][0]['ID'],
        }
        return vport_dict

    def nuage_vports_on_l2domain(self, l2dom_id, pnet_binding):
        nuagel2dom = nuagelib.NuageL2Domain()
        if pnet_binding:
            response = self.restproxy.rest_call(
                'GET',
                nuagel2dom.get_all_vports(
                    l2dom_id), '', extra_headers=(
                    nuagel2dom.extra_headers_host_and_vm_vport_get()))
        else:
            response = self.restproxy.rest_call(
                'GET',
                nuagel2dom.get_all_vports(l2dom_id), '')
        return nuagel2dom.get_validate(response)

    def nuage_vports_on_subnet(self, subnet_id, pnet_binding):
        nuagesubnet = nuagelib.NuageSubnet()
        if pnet_binding:
            response = self.restproxy.rest_call(
                'GET',
                nuagesubnet.get_all_vports(
                    subnet_id), '', extra_headers=(
                        nuagesubnet.extra_headers_host_and_vm_vport_get()))
        else:
            response = self.restproxy.rest_call(
                'GET',
                nuagesubnet.get_all_vports(subnet_id), '')
        return nuagesubnet.get_validate(response)

    @staticmethod
    def _get_vip_action(key):
        return {
            (0, 0, 0, 0): ACTION_MACSPOOFING,
            (0, 0, 0, 1): ACTION_MACSPOOFING,
            (0, 0, 1, 1): ACTION_MACSPOOFING,
            (0, 1, 0, 0): ACTION_MACSPOOFING,
            (0, 1, 0, 1): ACTION_MACSPOOFING,
            (0, 1, 1, 1): ACTION_MACSPOOFING,
            (1, 0, 0, 0): ACTION_NOVIP,
            (1, 0, 0, 1): ACTION_VIP,
            (1, 0, 1, 1): ACTION_NOVIP,
            (1, 1, 0, 0): ACTION_MACSPOOFING,
            (1, 1, 0, 1): ACTION_VIP,
            (1, 1, 1, 1): ACTION_MACSPOOFING,
        }.get(key, "error")

    @staticmethod
    def _log_no_vip_allowed(params, args):
        if args['key'] == (1, 0, 1, 1):
            LOG.warn("No VIP is created for ip %(vip)s and mac %(mac)s as "
                     "private ip %(ip)s is same as vip ip",
                     {'vip': params['vip'],
                      'mac': params['mac'],
                      'ip': params['port_ip']})
        elif args['key'] == (1, 0, 0, 0):
            LOG.warn("No VIP is created for vip %(vip)s and mac %(mac)s "
                     "as vip and private ip %(ip)s belong to different "
                     "subnets", {'vip': params['vip'],
                                 'mac': params['mac'],
                                 'ip': params['port_ip']})

    def _create_vip(self, params, args):
        if args['subn_type'] == constants.SUBNET:
            # Create VIP only for l3 subnet
            self.create_vip_on_vport(params)
        else:
            self.update_mac_spoofing_on_vport(params, constants.ENABLED)

    @staticmethod
    def get_net_size(netmask):
        binary_str = ''
        for octet in netmask:
            binary_str += bin(int(octet))[2:].zfill(8)
        return str(len(binary_str.rstrip('0')))

    @staticmethod
    def _check_cidr(params):
        ip = IPNetwork(params['vip'])
        if str(ip.cidr) != (str(ip.ip) + '/' + '32'):
            LOG.info("No VIP will be created for %s", str(ip.cidr))
            return False

        return True

    @staticmethod
    def _compare_ip(params):
        vip_addr = params['vip']
        if '/' in vip_addr:
            ip = vip_addr.split('/')
            vip_addr = ip[0]
        if vip_addr == params['port_ip']:
            LOG.info("No VIP will be created for %s as it is same as the"
                     "ip of the port", params['vip'])
            return True

        return False

    @staticmethod
    def _compare_mac(params):
        if params['mac'] == params['port_mac']:
            LOG.info("VIP mac %s is same as physical mac", params['port_mac'])
            return False

        return True

    def _get_subnet_type(self, params):
        nuage_subnet = helper.get_nuage_subnet(self.restproxy, params[
            'subnet_id'])
        if nuage_subnet['parentType'] == constants.ENTERPRISE:
            LOG.info("No VIP will be created for %(ip)s and %(mac)s",
                     {'ip': params['vip'],
                      'mac': params['mac']})
            return constants.L2DOMAIN
        else:
            return constants.SUBNET

    def _check_if_same_subnet(self, params):
        nuage_subnet = helper.get_nuage_subnet(self.restproxy, params[
            'subnet_id'])

        ipaddr = nuage_subnet['address'].split('.')
        netmask = nuage_subnet['netmask'].split('.')
        net_start = [str(int(ipaddr[x]) & int(netmask[x]))
                     for x in range(0, 4)]
        ipcidr = '.'.join(net_start) + '/' + self.get_net_size(netmask)

        vip_addr = params['vip']
        if '/' in vip_addr:
            ip = vip_addr.split('/')
            vip_addr = ip[0]
        if IPAddress(vip_addr) in IPNetwork(ipcidr):
            return True
        return False

    def process_vip(self, params):
        key, action = self._find_vip_action(params)

        # check if subnet is l2 or l3
        subn_type = self._get_subnet_type(params)
        args = {
            'key': key,
            'subn_type': subn_type
        }

        if action == ACTION_NOOP:
            LOG.warn("No action on VSD for vip with ip %(vip)s and mac %("
                     "mac)s", {'vip': params['vip'],
                               'mac': params['mac']})
        elif action == ACTION_MACSPOOFING:
            self.update_mac_spoofing_on_vport(params, constants.ENABLED)
        elif action == ACTION_VIP:
            self._create_vip(params, args)
        elif action == ACTION_NOVIP:
            self._log_no_vip_allowed(params, args)
        else:
            msg = ("VIP creation not supported in VSD for ip %(vip)s and "
                   "mac %(mac)s", {'vip': params['vip'],
                                   'mac': params['mac']})
            LOG.error(msg)
            raise Exception(msg)

    def _find_vip_action(self, params):
        # check if it is a /32 ip
        full_cidr = self._check_cidr(params)

        # check if mac is diff from port mac
        diff_mac = self._compare_mac(params)

        # check if vip is same as private ip
        same_ip = self._compare_ip(params)

        # check if ip and vip are in same subnet
        same_subn = self._check_if_same_subnet(params)

        key = (full_cidr, diff_mac, same_ip, same_subn)
        action = self._get_vip_action(key)
        LOG.info("Key is %s and action is %s", key, action)
        return key, action

    def process_deleted_addr_pair(self, params):
        _, action = self._find_vip_action(params)
        if action == ACTION_MACSPOOFING or action == ACTION_VIP:
            self.update_mac_spoofing_on_vport(params, constants.INHERITED)

    def update_mac_spoofing_on_vport(self, params, status):
        req_params = {
            'vport_id': params['vport_id']
        }

        extra_params = {
            'mac_spoofing': status
        }
        nuage_vport = nuagelib.NuageVPort(create_params=req_params,
                                          extra_params=extra_params)

        response = self.restproxy.rest_call('GET', nuage_vport.get_resource(),
                                            '')
        if not nuage_vport.validate(response):
            raise restproxy.RESTProxyError(nuage_vport.error_msg)

        mac_spoofing = nuage_vport.get_mac_spoofing(response)
        if mac_spoofing != status:
            response = self.restproxy.rest_call(
                'PUT',
                nuage_vport.put_resource(),
                nuage_vport.mac_spoofing_update_data())
            if not nuage_vport.validate(response):
                raise restproxy.RESTProxyError(nuage_vport.error_msg)
            LOG.info("MAC spoofing changed to %s on vport %s", status, params[
                'vport_id'])

    def create_vip_on_vport(self, params):
        # Check for fip to vip association
        associate_fip = False
        vip_list = self._get_vips_for_subnet(params)
        if vip_list:
            if vip_list[0]['associatedFloatingIPID']:
                associate_fip = True

        req_params = {
            'vport_id': params['vport_id']
        }

        extra_params = {
            'vip': params['vip'],
            'subnet': params['subnet_id'],
            'mac': params['mac']
        }

        nuage_vip = nuagelib.NuageVIP(create_params=req_params,
                                      extra_params=extra_params)
        response = self.restproxy.rest_call(
            'POST',
            nuage_vip.get_resource_for_vport(),
            nuage_vip.post_vip_data())
        if not nuage_vip.validate(response):
            raise restproxy.RESTProxyError(nuage_vip.error_msg)
        LOG.info("VIP with ip %(vip)s and mac %(mac)s created for %(vport)s",
                 {'vip': params['vip'],
                  'mac': params['mac'],
                  'vport': params['vport_id']})

        # Set anti spoofing to inherited if it was enabled before
        self.update_mac_spoofing_on_vport(params, constants.INHERITED)

        if associate_fip:
            params['nuage_fip_id'] = vip_list[0]['associatedFloatingIPID']
            self._associate_fip_to_vip(
                params,
                nuage_vip.get_response_obj(response))

        return nuage_vip.get_response_obj(response)

    def get_vips_on_vport(self, vport_id):
        req_params = {
            'vport_id': vport_id
        }

        nuage_vip = nuagelib.NuageVIP(create_params=req_params)
        response = self.restproxy.rest_call('GET',
                                            nuage_vip.get_resource_for_vport(),
                                            '')
        if not nuage_vip.validate(response):
            raise restproxy.RESTProxyError(nuage_vip.error_msg)

        vips = nuage_vip.get_response_objlist(response)
        resp = []
        if vips:
            for vip in vips:
                ret = {
                    'vip': nuagelib.NuageVIP.get_ip_addr(vip),
                    'mac': nuagelib.NuageVIP.get_mac_addr(vip),
                    'vip_id': nuagelib.NuageVIP.get_vip_id(vip)
                }

                resp.append(ret)
        return resp

    def delete_vips(self, vport_id, vip_dict, vips):
        nuage_vips = self.get_vips_on_vport(vport_id)

        nuage_vip_dict = dict()
        for vip in vips:
            nuage_vip_dict[vip] = vip_dict[vip]

        for nuage_vip in nuage_vips:
            if nuage_vip['vip'] in nuage_vip_dict:
                req_params = {
                    'vip_id': nuage_vip['vip_id']
                }
                nuage_vip = nuagelib.NuageVIP(create_params=req_params)
                response = self.restproxy.rest_call(
                    'DELETE',
                    nuage_vip.delete_resource(), '')
                if not nuage_vip.validate(response):
                    LOG.error("Error in deleting vip with ip %(vip)s and mac "
                              "%(mac)s", {'vip': nuage_vip['vip'],
                                          'mac': nuage_vip['mac']})
                    raise restproxy.RESTProxyError(nuage_vip.error_msg)

    def _get_vips_for_subnet(self, params):
        # Get the nuage subnet
        if params.get('neutron_subnet_id'):
            nuage_subnet_id = helper.get_nuage_l2dom_or_subnet(
                self.restproxy,
                params['neutron_subnet_id'])
        else:
            nuage_subnet_id = params['subnet_id']

        # Get the vips under subnet
        req_params = {
            'subnet_id': nuage_subnet_id
        }
        extra_params = {
            'vip': params['vip']
        }
        nuage_vip = nuagelib.NuageVIP(create_params=req_params,
                                      extra_params=extra_params)
        response = self.restproxy.rest_call(
            'GET',
            nuage_vip.get_resource_for_subnet(), '',
            nuage_vip.extra_headers_given_vip())
        if not nuage_vip.validate(response):
            raise restproxy.RESTProxyError(nuage_vip.error_msg)
        vip_list = nuage_vip.get_response_objlist(response)
        return vip_list

    def _associate_fip_to_vip(self, params, vip):
        req_params = {
            'vip_id': vip['ID']
        }
        extra_params = {
            'fip': params['nuage_fip_id']
        }
        nuage_vip = nuagelib.NuageVIP(create_params=req_params,
                                      extra_params=extra_params)
        response = self.restproxy.rest_call(
            'PUT', nuage_vip.put_resource(), nuage_vip.post_vip_data())
        if not nuage_vip.validate(response):
            raise restproxy.RESTProxyError(nuage_vip.error_msg)
        LOG.debug("Updated fip %s with floatingip %s", vip['ID'],
                  params['nuage_fip_id'])

    def associate_fip_to_vips(self, params):
        vip_list = self._get_vips_for_subnet(params)
        for vip in vip_list:
            self._associate_fip_to_vip(params, vip)
