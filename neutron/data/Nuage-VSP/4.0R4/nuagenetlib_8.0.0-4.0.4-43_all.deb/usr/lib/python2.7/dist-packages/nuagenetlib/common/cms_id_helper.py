
CMS_ID = None


def get_vsd_external_id(neutron_id):
    if neutron_id and '@' not in neutron_id and CMS_ID:
        return neutron_id + '@' + CMS_ID
    return neutron_id


def strip_cms_id(external_id):
    return external_id.split('@')[0] if external_id else external_id


def extra_headers_get():
    return {
        'X-NUAGE-FilterType': "predicate",
        'X-Nuage-Filter': "externalID ENDSWITH '@%s'" % CMS_ID
    }
