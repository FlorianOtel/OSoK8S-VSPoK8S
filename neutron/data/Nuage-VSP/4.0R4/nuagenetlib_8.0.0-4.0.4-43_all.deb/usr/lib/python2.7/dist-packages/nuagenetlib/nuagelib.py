# Copyright 2015 Alcatel-Lucent USA Inc.
# All Rights Reserved.

import hashlib
import json
import six

from abc import ABCMeta

from nuagenetlib.common import constants
from nuagenetlib.common.cms_id_helper import get_vsd_external_id
from nuagenetlib.common.cms_id_helper import strip_cms_id

REST_SUCCESS_CODES = constants.REST_SUCCESS_CODES
REST_NOT_FOUND = constants.RES_NOT_FOUND
DEF_OPENSTACK_USER = constants.DEF_OPENSTACK_USER
DEF_OPENSTACK_USER_EMAIL = constants.DEF_OPENSTACK_USER_EMAIL
DEF_OPENSTACK_USER_PASS = constants.DEF_OPENSTACK_USER_PASS
REST_SERV_UNAVAILABLE_CODE = constants.REST_SERV_UNAVAILABLE_CODE


class NuageServerBaseClass(object):
    def __init__(self, create_params=None, extra_params=None):
        self.create_params = create_params
        self.extra_params = extra_params
        self.error_msg = None
        self.vsd_error_code = None

    def validate(self, response):
        if response[0] == 0:
            return False
        if response[0] not in REST_SUCCESS_CODES:
            errors = json.loads(response[3])
            if response[0] == REST_SERV_UNAVAILABLE_CODE:
                self.error_msg = self.get_503_error_msg(errors)
            else:
                self.error_msg = self.get_error_msg(errors)
                if response[0] == REST_NOT_FOUND:
                    # 404s don't have an internalErrorCode
                    self.vsd_error_code = REST_NOT_FOUND
                else:
                    self.vsd_error_code = self.get_internal_error_code(errors)
            return False
        return True

    def get_503_error_msg(self, errors):
        return 'VSD temporarily unavailable, ' + str(errors['errors'])

    def get_error_msg(self, errors):
        return str(errors['errors'][0]['descriptions'][0]['description'])

    def get_internal_error_code(self, errors):
        return str(errors.get('internalErrorCode'))

    def get_response_objid(self, response):
        return str(response[3][0]['ID'])

    def get_response_objtype(self, response):
        if 'type' in response[3][0]:
            return str(response[3][0]['type'])

    def get_response_obj(self, response):
        return response[3][0]

    def get_response_objlist(self, response):
        return response[3]

    def get_response_parentid(self, response):
        return response[3][0]['parentID']

    def get_response_externalid(self, response):
        return strip_cms_id(response[3][0]['externalID'])

    def get_description(self, response):
        return response[3][0]['description']

    def get_validate(self, response):
        return self.validate(response) and response[3]

    def check_response_exist(self, response):
        return len(response[3]) > 0

    def delete_validate(self, response):
        return (self.validate(response) or
                response[0] == constants.RES_NOT_FOUND)

    def get_error_code(self, response):
        return response[0]

    def resource_exists(self, response):
        error_code = self.get_error_code(response)
        if error_code == 0:
            return False
        errors = json.loads(response[3])
        int_error_code = self.get_internal_error_code(errors)
        # 2510 is the internal error code returned by VSD in case
        # template already exists
        if (error_code != constants.CONFLICT_ERR_CODE or
            (error_code == constants.CONFLICT_ERR_CODE and
             int_error_code != constants.RES_EXISTS_INTERNAL_ERR_CODE)):
            return False
        return True

    def extra_header_filter(self, **filters):
        filter = ''
        for field, value in filters.iteritems():
            if isinstance(value, six.string_types):
                value = "'%s'" % value
            if value is None:
                value = 'null'
            if filter:
                filter += " and "
            filter += "%s IS %s" % (field, value)
        return {'X-Nuage-Filter': filter} if filter else None


class NuageL3DomTemplate(NuageServerBaseClass):
    def post_resource(self):
        ent_id = self.create_params['net_partition_id']
        return '/enterprises/%s/domaintemplates' % ent_id

    def list_resource(self):
        ent_id = self.create_params['net_partition_id']
        return '/enterprises/%s/domaintemplates' % ent_id

    def post_data(self):
        data = {
            'name': self.create_params['name']
        }
        if self.extra_params:
            data.update(self.extra_params)
        return data

    def get_templateid(self, response):
        if response[3]:
            return self.get_response_objid(response)
        else:
            return None

    def delete_resource(self, id):
        return '/domaintemplates/%s' % id

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" % self.create_params['name']
        return headers


class NuageL2DomTemplate(NuageServerBaseClass):
    def post_resource(self):
        ent_id = self.create_params['net_partition_id']
        return '/enterprises/%s/l2domaintemplates' % ent_id

    def list_resource(self):
        ent_id = self.create_params['net_partition_id']
        return '/enterprises/%s/l2domaintemplates' % ent_id

    def post_data(self):
        data = {
            "name": self.create_params['name']
        }
        if self.extra_params:
            data.update(self.extra_params)
        return data

    def get_resource(self, id):
        return '/l2domaintemplates/%s' % id

    def put_resource(self, id):
        return '/l2domaintemplates/%s?responseChoice=1' % id

    def get_templateid(self, response):
        if response[3]:
            return self.get_response_objid(response)
        else:
            return None

    def validate_cidr(self, response, net_ip):
        if response[3][0]['address'] is not None:
            if str(net_ip.ip) != response[3][0]['address'] or \
                    str(net_ip.netmask) != response[3][0]['netmask']:
                return True, False
            return True, True
        else:
            return False, False

    def delete_resource(self, id):
        return '/l2domaintemplates/%s' % id

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" % self.create_params['name']
        return headers


class NuageZoneTemplate(NuageServerBaseClass):
    def post_resource(self):
        l3dom_id = self.create_params['l3domain_id']
        return '/domaintemplates/%s/zonetemplates' % l3dom_id

    def list_resource(self):
        l3dom_id = self.create_params['l3domain_id']
        return '/domaintemplates/%s/zonetemplates' % l3dom_id

    def post_data(self):
        data = {
            "name": self.create_params['name']
        }
        if self.extra_params:
            data.update(self.extra_params)
        return data

    def get_templateid(self, response):
        return self.get_response_objid(response)

    def delete_resource(self, id):
        return '/zonetemplates/%s' % id

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" % self.create_params['name']
        return headers

    def zonetemplate_list(self, response):
        return response[3]


class NuageL2Domain(NuageServerBaseClass):
    resource = 'l2domains'

    def post_resource(self):
        ent_id = self.create_params['net_partition_id']
        return '/enterprises/%s/%s?responseChoice=1' % (ent_id, self.resource)

    def post_data(self):
        data = {
            "name": self.create_params['name'],
            "templateID": self.create_params['template'],
            "externalID": get_vsd_external_id(self.create_params['externalID'])
        }

        if self.extra_params:
            data.update(self.extra_params)
        return data

    def put_resource(self, id):
        return '/%s/%s?responseChoice=1' % (self.resource, id)

    def get_validate(self, response):
        return self.validate(response) and response[3]

    def get_domainid(self, response):
        return self.get_response_objid(response)

    def get_template_id(self, response):
        return response[3][0]['templateID']

    def get_resource_with_ext_id(self):
        return '/%s' % self.resource

    def get_cidr_info(self, response):
        ip = response[3][0]['address']
        netmask = response[3][0]['netmask']
        return (ip, netmask)

    def delete_resource(self, id):
        return '/%s/%s?responseChoice=1' % (self.resource, id)

    def get_resource(self, id):
        return '/%s/%s' % (self.resource, id)

    def get_all_resources_in_ent(self):
        return '/enterprises/%s/%s' % (
            self.create_params['net_partition_id'], self.resource)

    def get_all_resources(self):
        return '/%s' % self.resource

    def vm_get_resource(self, id):
        return '/%s/%s/vms' % (self.resource, id)

    def vport_get_resource(self, l2dom_id):
        return '/%s/%s/vports' % (self.resource, l2dom_id)

    def vm_exists(self, response):
        return self.validate(response) and len(response[3]) > 0

    def nuage_redirect_target_get_resource(self, id):
        return '/%s/%s/redirectiontargets' % (self.resource, id)

    def dhcp_get_resource(self, id):
        return '/%s/%s/dhcpoptions' % (self.resource, id)

    def get_gwIp_set_via_dhcp(self, dhcpoption):
        gw_ip_via_dhcp_option = dhcpoption['value']
        bytes = ["".join(x) for x in zip(*[iter(gw_ip_via_dhcp_option)]*2)]
        bytes = [int(x, 16) for x in bytes]
        return ".".join(str(x) for x in bytes)

    def get_gw_info(self, response):
        gw_ip = response[3][0]['gateway']
        return gw_ip

    def get_all_vports(self, id):
        return '/%s/%s/vports' % (self.resource, id)

    def vport_post(self, id):
        return '/%s/%s/vports' % (self.resource, id)

    def vport_post_data(self, params):
        data = {
            'VLANID': params['vlan'],
            'type': params['type'],
            'name': params['name']
        }

        if params.get('type') == constants.BRIDGE_VPORT_TYPE:
            data['addressSpoofing'] = constants.ENABLED
        else:
            data['addressSpoofing'] = constants.INHERITED
        return data

    def vm_vport_post_data(self, params):
        data = {
            'type': params['type'],
            'name': params['name'],
            'addressSpoofing': params['addressSpoofing'],
            'externalID': get_vsd_external_id(params['externalID'])
        }

        if params.get('description'):
            data['description'] = params.get('description')
        return data

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" %  \
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers

    def extra_headers_vport_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "type IS BRIDGE"
        return headers

    def extra_headers_host_and_vm_vport_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "type IS VM or type is HOST"
        return headers


class NuageSubnet(NuageServerBaseClass):
    def post_resource(self):
        return ('/zones/%s/subnets?responseChoice=1'
                % self.create_params['zone'])

    def post_data(self):
        data = {
            "name": self.create_params['name'],
            "address": str(self.create_params['net'].ip),
            "netmask": str(self.create_params['net'].netmask),
            "gateway": self.create_params['gateway'],
            "externalID": get_vsd_external_id(self.create_params['externalID'])
        }
        if self.extra_params:
            data.update(self.extra_params)
        return data

    def get_subnetid(self, response):
        return self.get_response_objid(response)

    def get_cidr_info(self, response):
        ip = response[3][0]['address']
        netmask = response[3][0]['netmask']
        return (ip, netmask)

    def delete_resource(self, id):
        return '/subnets/%s?responseChoice=1' % id

    def get_resource(self, id):
        return '/subnets/%s' % id

    def put_resource(self, id):
        return '/subnets/%s?responseChoice=1' % id

    def get_all_resources_in_domain(self):
        return '/domains/%s/subnets' % self.create_params['nuage_domain_id']

    def get_all_resources_in_zone(self):
        return '/zones/%s/subnets' % self.create_params['zone']

    def get_all_resources(self):
        return '/subnets'

    def get_resource_with_ext_id(self):
        return '/subnets'

    def get_parentzone(self, response):
        return response[3][0]['parentID']

    def vm_get_resource(self, id):
        return '/subnets/%s/vms' % id

    def vport_get_resource(self, subnet_id):
        return '/subnets/%s/vports' % subnet_id

    def vm_exists(self, response):
        return self.validate(response) and len(response[3]) > 0

    def dhcp_get_resource(self, id):
        return '/subnets/%s/dhcpoptions' % id

    def get_gwIp_set_via_dhcp(self, dhcpoption):
        gw_ip_via_dhcp_option = dhcpoption['value']
        bytes = ["".join(x) for x in zip(*[iter(gw_ip_via_dhcp_option)]*2)]
        bytes = [int(x, 16) for x in bytes]
        return ".".join(str(x) for x in bytes)

    def get_gw_info(self, response):
        gw_ip = response[3][0]['gateway']
        return gw_ip

    def vport_post(self, id):
        return '/subnets/%s/vports' % id

    def vport_post_data(self, params):
        data = {
            'VLANID': params['vlan'],
            'type': params['type'],
            'name': params['name']
        }

        if params.get('type') == constants.BRIDGE_VPORT_TYPE:
            data['addressSpoofing'] = constants.ENABLED
        else:
            data['addressSpoofing'] = constants.INHERITED

        return data

    def vm_vport_post_data(self, params):
        data = {
            'type': params['type'],
            'name': params['name'],
            'addressSpoofing': params['addressSpoofing'],
            'externalID': get_vsd_external_id(params['externalID'])
        }

        if params.get('description'):
            data['description'] = params.get('description')
        return data

    def get_all_vports(self, id):
        return '/subnets/%s/vports' % id

    def extra_headers_get_name(self, subn_name):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" % subn_name
        return headers

    def extra_headers_vport_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "type IS BRIDGE"
        return headers

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" %  \
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers

    def extra_headers_host_and_vm_vport_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "type IS VM or type is HOST"
        return headers


class NuageDhcpOptions(NuageServerBaseClass):
    def resource_by_l2domainid(self, id):
        # This method is used for GET and POST for l2 case
        return '/l2domains/%s/dhcpoptions' % id

    def resource_by_subnetid(self, id):
        # This method is used for GET and POST for l3 case
        return '/subnets/%s/dhcpoptions' % id

    def resource_by_sharedresourceid(self, id):
        # This method is used for GET and POST for shared networks
        return '/sharednetworkresources/%s/dhcpoptions' % id

    def resource_by_vportid(self, id):
        # This method is used for GET and POST for VPort case
        return '/vports/%s/dhcpoptions' % id

    def dhcp_resource(self, id):
        # This method is used for DELETE and PUT with acceptance
        return '/dhcpoptions/%s?responseChoice=1' % id

    def get_gwIp_set_via_dhcp(self, dhcpoption):
        gw_ip_via_dhcp_option = dhcpoption['value']
        bytes = ["".join(x) for x in zip(*[iter(gw_ip_via_dhcp_option)]*2)]
        bytes = [int(x, 16) for x in bytes]
        return ".".join(str(x) for x in bytes)


class NuageL3Domain(NuageServerBaseClass):
    resource = 'domains'

    def post_resource(self):
        ent_id = self.create_params['net_partition_id']
        return '/enterprises/%s/%s' % (ent_id, self.resource)

    def get_resource(self):
        return '/%s/%s' % (self.resource, self.create_params['domain_id'])

    def post_data(self):
        data = {
            "name": self.create_params['name'],
            "templateID": self.create_params['templateID'],
            "externalID": get_vsd_external_id(self.create_params['externalID'])
        }
        if self.extra_params:
            data.update(self.extra_params)
        return data

    def get_domainid(self, response):
        return self.get_response_objid(response)

    def delete_resource(self, id):
        return '/%s/%s?responseChoice=1' % (self.resource, id)

    def put_resource(self, id):
        return '/%s/%s?responseChoice=1' % (self.resource, id)

    def get_all_resources(self):
        return '/%s' % self.resource

    def get_resource_with_ext_id(self):
        return '/%s' % self.resource

    def get_all_resources_in_ent(self):
        return '/enterprises/%s/%s' % (self.create_params[
            'net_partition_id'], self.resource)

    def get_all_zones(self):
        return '/%s/%s/zones' % (self.resource,
                                 self.create_params['domain_id'])

    def get_all_vports(self):
        return '/%s/%s/vports' % (self.resource,
                                  self.create_params['domain_id'])

    def get_domain_rt(self, response):
        return response[3][0].get('routeTarget')

    def get_domain_rd(self, response):
        return response[3][0].get('routeDistinguisher')

    def get_domain_ecmp_count(self, response):
        return response[3][0].get('ECMPCount')

    def get_domain_tunnel_type(self, response):
        return response[3][0].get('tunnelType')

    def get_domain_backhaul_vnid(self, response):
        return response[3][0].get('backHaulVNID')

    def get_domain_backhaul_rd(self, response):
        return response[3][0].get('backHaulRouteDistinguisher')

    def get_domain_backhaul_rt(self, response):
        return response[3][0].get('backHaulRouteTarget')

    def get_patenabled(self, response):
        return response[3][0].get('PATEnabled', None)

    def get_domain_subnets(self, id):
        return '/%s/%s/subnets' % (self.resource, id)

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" %  \
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers

    def extra_headers_get_name(self, zone_name):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" % zone_name
        return headers

    def extra_headers_get_address(self, net_ip):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "address IS '%s'" % net_ip
        return headers


class NuageZone(NuageServerBaseClass):
    def get_zoneid(self, response):
        return self.get_response_objid(response)

    def get_resource(self):
        return '/zones/%s' % self.create_params['zone_id']

    def post_resource(self):
        return '/domains/%s/zones' % self.create_params['domain_id']

    def list_resource(self):
        return '/domains/%s/zones' % self.create_params['domain_id']

    def get_all_resource(self):
        return '/zones'

    def post_data(self):
        data = {
            "name": self.create_params['name'],
            "externalID": get_vsd_external_id(self.create_params['externalID'])
        }
        if self.extra_params:
            data.update(self.extra_params)
        return data

    def zone_list(self, response):
        return response[3]

    def get_isolated_zone_id(self, response):
        for zone in self.zone_list(response):
            if '-pub-' not in zone['name']:
                return zone['ID']

    def get_shared_zone_id(self, response):
        for zone in self.zone_list(response):
            if '-pub-' in zone['name']:
                return zone['ID']

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" %  \
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers


class NuageStaticRoute(NuageServerBaseClass):
    def get_staticrouteid(self, response):
        return self.get_response_objid(response)

    def post_resource(self):
        return ("/domains/%s/staticroutes"
                "?responseChoice=1" % self.create_params['domain_id'])

    def get_resource(self):
        return '/staticroutes'

    def get_resources_of_domain(self):
        return '/domains/%s/staticroutes' % self.create_params['domain_id']

    def post_data(self):
        data = {
            'address': str(self.create_params['net'].ip),
            'netmask': str(self.create_params['net'].netmask),
            'nextHopIp': self.create_params['nexthop'],
            'externalID': get_vsd_external_id(self.create_params['router_id'])
        }
        if self.extra_params:
            data.update(self.extra_params)
        return data

    def delete_resource(self, id):
        return '/staticroutes/%s?responseChoice=1' % id

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "address IS '%s' and nextHopIp IS '%s'" %\
                                    (self.create_params['address'],
                                     self.create_params['nexthop'])
        return headers


class NuageGroup(NuageServerBaseClass):
    def post_resource(self):
        ent_id = self.create_params['net_partition_id']
        return '/enterprises/%s/groups' % ent_id

    def get_group_id(self, response):
        return self.get_response_objid(response)

    def list_resource(self):
        ent_id = self.create_params['net_partition_id']
        return '/enterprises/%s/groups' % ent_id

    def find_group_by_name(self, name, group_list):
        for group in group_list:
            if name == group['name']:
                return group['ID']
        return None

    def group_list(self, response):
        return response[3]

    def post_data(self):
        data = {}
        data['name'] = self.create_params['name']
        data["managementMode"] = constants.NUAGE_LDAP_MODE
        return data

    def get_groupid(self, response):
        return self.get_response_objid(response)

    def zone_attach_resource(self, zoneid):
        return '/zones/%s/groups' % zoneid

    def l2dom_attach_resource(self, l2domid):
        return '/l2domains/%s/groups' % l2domid

    def l2dom_attach_data(self, groupid):
        return [groupid]

    def l2dom_attach_groupid_list(self, groupid):
        return groupid

    def zone_attach_data(self, groupid):
        return [groupid]

    def zone_attach_groupid_list(self, groupid):
        return groupid

    def delete_resource(self, id):
        return '/groups/%s?responseChoice=1' % id

    def extra_headers_get_for_everybody(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS 'Everybody'"
        return headers

    def extra_headers_get_by_name(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" % self.create_params['name']
        return headers


class NuageUser(NuageServerBaseClass):
    def ent_post_resource(self):
        ent_id = self.create_params['net_partition_id']
        return '/enterprises/%s/users' % ent_id

    def group_post_resource(self):
        return '/groups/%s/users' % self.create_params['group_id']

    def find_user_by_name(self, name, user_list):
        for user in user_list:
            if name == user['userName']:
                return user['ID']
        return None

    def user_list(self, response):
        return response[3]

    def set_group_id(self, groupid):
        self.create_params['group_id'] = groupid

    def post_data(self):
        data = {}
        data["firstName"] = DEF_OPENSTACK_USER
        data["lastName"] = DEF_OPENSTACK_USER
        data["userName"] = self.create_params['name']
        data["email"] = DEF_OPENSTACK_USER_EMAIL
        data["password"] = hashlib.sha1(DEF_OPENSTACK_USER_PASS).hexdigest()
        data["managementMode"] = constants.NUAGE_LDAP_MODE
        return data

    def get_userid(self, response):
        return self.get_response_objid(response)

    def delete_resource(self, id):
        return '/users/%s?responseChoice=1' % id

    def extra_headers_get_by_username(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = (
            "userName IS '%s'" % self.extra_params['userName'])
        return headers


class NuageNetPartition(NuageServerBaseClass):
    def post_resource(self):
        return '/enterprises'

    def get_resource(self):
        return '/enterprises'

    def get_resource_by_id(self):
        return '/enterprises/%s' % self.create_params['netpart_id']

    def default_post_data(self):
        data = {
            'allowedForwardingClasses': ['E', 'F', 'G', 'H']
        }
        return data

    def post_data(self):
        data = {
            'name': self.create_params['name'],
            'floatingIPsQuota': self.create_params['fp_quota'],
        }
        data.update(self.default_post_data())
        return data

    def get_net_partition_id(self, response):
        return self.get_response_objid(response)

    def get_validate(self, response):
        return self.validate(response) and response[3]

    def delete_resource(self, id):
        return '/enterprises/%s?responseChoice=1' % id

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" % self.create_params['name']
        return headers


class NuageEntProfile(NuageServerBaseClass):
    def get_resource(self):
        return '/enterpriseprofiles'

    def get_resource_by_id(self, id):
        return '/enterpriseprofiles/%s' % id

    def post_fip_quota(self, fip_quota):
        data = {
            'floatingIPsQuota': fip_quota
        }
        return data

    def get_validate(self, response):
        return self.validate(response) and response[3]


class NuageVM(NuageServerBaseClass):
    def post_resource(self):
        return '/vms'

    def get_resource(self):
        return '/vms'

    def delete_resource(self):
        return '/vms/%s?responseChoice=1' % self.create_params['id']

    def post_data(self):
        interface = {
            'MAC': self.create_params['mac'],
            'externalID': get_vsd_external_id(self.create_params['externalID'])
        }
        if self.create_params.get('attachedNetworkID'):
            interface['attachedNetworkID'] = (
                self.create_params['attachedNetworkID'])
        if self.create_params.get('vport_id'):
            interface['VPortID'] = self.create_params['vport_id']
        if self.create_params['ip'] is not None:
            interface['IPAddress'] = self.create_params['ip']

        data = {
            'name': 'vm-' + self.create_params['mac'].replace(':', ''),
            'interfaces': [interface],
            'UUID': self.create_params['id']
        }
        return data

    def extra_headers_post(self):
        headers = {}
        ent_name = self.extra_params['net_partition_name']
        headers['X-Nuage-ProxyUser'] = "%s@%s" % (self.extra_params['tenant'],
                                                  ent_name)
        return headers

    def extra_headers_delete(self):
        return self.extra_headers_post()

    def extra_headers_get(self):
        headers = {}
        ent_name = self.extra_params['net_partition_name']
        headers['X-Nuage-ProxyUser'] = "%s@%s" % (self.extra_params['tenant'],
                                                  ent_name)
        headers['X-NUAGE-FilterType'] = "predicate"
        id = str(self.create_params['id'])
        headers['X-Nuage-Filter'] = "UUID IS '%s'" % id
        return headers

    def extra_headers_get_by_externalID(self):
        headers = {}
        headers['X-/vport-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" % \
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers

    def get_validate(self, response):
        return self.validate(response) and response[3]

    def get_vmid(self, response):
        return self.get_response_objid(response)

    def get_num_interfaces(self, response):
        return len(response[3][0]['interfaces'])

    def get_new_vmif(self, response):
        vm_interfaces = response[3][0]['interfaces']
        for vm_if in vm_interfaces:
            if str(vm_if['MAC']) == self.create_params['mac']:
                return vm_if
        return None

    def get_vmif_ip(self, vm_if):
        return vm_if['IPAddress']

    def get_vmif_id(self, vm_if):
        return vm_if['ID']

    def get_vmif_vportid(self, vm_if):
        return vm_if['VPortID']

    def get_all_resources(self):
        return '/l2domains/%s/vms' % self.create_params['l2domain_id']


class NuageVMInterface(NuageServerBaseClass):
    def get_all_resource(self):
        return '/vminterfaces'

    def get_inteface_for_vport(self):
        return '/vports/%s/vminterfaces' % self.create_params['vport_id']

    def post_resource(self):
        return '/vms/%s/vminterfaces' % self.create_params['vm_id']

    def delete_resource(self):
        return '/vminterfaces/%s?responseChoice=1' % self.create_params['id']

    def post_data(self):
        data = {
            'MAC': self.create_params['mac'],
            'externalID': get_vsd_external_id(self.create_params['externalID'])
        }
        if self.create_params.get('attachedNetworkID'):
            data['attachedNetworkID'] = (
                self.create_params['attachedNetworkID'])
        if self.create_params.get('vport_id'):
            data['VPortID'] = self.create_params['vport_id']
        if self.create_params['ip'] is not None:
            data['IPAddress'] = self.create_params['ip']
        return data

    def extra_headers(self):
        headers = {}
        ent_name = self.extra_params['net_partition_name']
        headers['X-Nuage-ProxyUser'] = "%s@%s" % (self.extra_params['tenant'],
                                                  ent_name)
        return headers

    def extra_headers_for_all_vmifs(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" %  \
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers

    def get_vif_id(self, response):
        return response[3][0]['ID']

    def get_vport_id(self, response):
        return response[3][0]['VPortID']

    def get_vmif_ip(self, response):
        return response[3][0]['IPAddress']


class NuageInboundACL(NuageServerBaseClass):
    def get_resource_l2(self):
        parent_id = self.create_params['parent_id']
        return '/l2domains/%s/ingressacltemplates' % parent_id

    def post_resource_l2(self):
        parent_id = self.create_params['parent_id']
        return '/l2domains/%s/ingressacltemplates' % parent_id

    def get_resource_l3(self):
        parent_id = self.create_params['parent_id']
        return '/domains/%s/ingressacltemplates' % parent_id

    def post_resource_l3(self):
        parent_id = self.create_params['parent_id']
        return '/domains/%s/ingressacltemplates' % parent_id

    def post_data_default_l2(self):
        data = {}
        data['name'] = (self.create_params['name'] +
                        constants.NUAGE_DEFAULT_L2_INGRESS_ACL)
        data['description'] = 'default ACL'
        data['active'] = True
        data['defaultAllowNonIP'] = False
        return data

    def post_data_l2(self):
        return

    def post_data_default_l3(self):
        data = {}
        data['name'] = (self.create_params['name'] +
                        constants.NUAGE_DEFAULT_L3_INGRESS_ACL)
        data['description'] = 'default ACL'
        data['active'] = True
        data['defaultAllowNonIP'] = False
        return data

    def post_data_default_l3rule(self):
        aclentry = {
            "locationType": "ANY",
            "networkType": "ENDPOINT_DOMAIN",
            "etherType": "0x0800",
            "protocol": "ANY",
            "priority": 32768,
            "action": "FORWARD",
            "DSCP": '*',
        }
        return aclentry

    def post_data_default_l2rule(self):
        aclentry = {
            "locationType": "ANY",
            "networkType": "ANY",
            "etherType": "0x0800",
            "protocol": "ANY",
            "priority": 32768,
            "action": "FORWARD",
            "DSCP": '*',
        }
        return aclentry

    def post_data_l3(self):
        return

    def get_iacl_id(self, response):
        return self.get_response_objid(response)

    def extra_headers_get_by_name(self, name):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" % name
        return headers


class NuageOutboundACL(NuageServerBaseClass):
    def get_resource_l2(self):
        parent_id = self.create_params['parent_id']
        return '/l2domains/%s/egressacltemplates' % parent_id

    def post_resource_l2(self):
        parent_id = self.create_params['parent_id']
        return '/l2domains/%s/egressacltemplates' % parent_id

    def get_resource_l3(self):
        parent_id = self.create_params['parent_id']
        return '/domains/%s/egressacltemplates' % parent_id

    def post_resource_l3(self):
        parent_id = self.create_params['parent_id']
        return '/domains/%s/egressacltemplates' % parent_id

    def post_data_default_l2(self):
        data = {}
        data['name'] = (self.create_params['name'] +
                        constants.NUAGE_DEFAULT_L2_EGRESS_ACL)
        data['description'] = 'default ACL'
        data['active'] = True
        data['defaultAllowNonIP'] = False
        data['defaultInstallACLImplicitRules'] = False
        return data

    def post_data_l2(self):
        return

    def post_data_default_l3(self):
        data = {}
        data['name'] = (self.create_params['name'] +
                        constants.NUAGE_DEFAULT_L3_EGRESS_ACL)
        data['description'] = 'default ACL'
        data['active'] = True
        data['defaultAllowNonIP'] = False
        data['defaultInstallACLImplicitRules'] = False
        return data

    def post_data_default_l3rule(self):
        aclentry = {
            "locationType": "ANY",
            "networkType": "ENDPOINT_DOMAIN",
            "etherType": "0x0800",
            "protocol": "ANY",
            "priority": 32768,
            "action": "FORWARD",
            "DSCP": '*',
        }
        return aclentry

    def post_data_default_l2rule(self):
        aclentry = {
            "locationType": "ANY",
            "networkType": "ANY",
            "etherType": "0x0800",
            "protocol": "ANY",
            "priority": 32768,
            "action": "FORWARD",
            "DSCP": '*',
        }
        return aclentry

    def post_data_l3(self):
        return

    def get_oacl_id(self, response):
        return self.get_response_objid(response)

    def extra_headers_get_by_name(self, name):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" % name
        return headers


class NuageSharedResources(NuageServerBaseClass):
    def get_resource_by_id(self, id):
        return '/sharednetworkresources/%s' % id

    def post_resource(self):
        return '/sharednetworkresources'

    def get_resource(self):
        return '/sharednetworkresources'

    def put_resource(self):
        return ('/sharednetworkresources/%s?responseChoice=1'
                % self.create_params['id'])

    def post_data(self):
        data = {
            'name': self.create_params['name'],
            'gateway': self.create_params['gateway_ip'],
            'address': str(self.create_params['net'].ip),
            'netmask': str(self.create_params['net'].netmask),
            'type': self.create_params['type'],
            'externalID': get_vsd_external_id(self.create_params['externalID'])
        }
        if self.extra_params:
            data.update(self.extra_params)
        return data

    def get_sharedresource_id(self, response):
        return self.get_response_objid(response)

    def get_validate(self, response):
        return self.validate(response) and response[3]

    def delete_resource(self, id):
        return '/sharednetworkresources/%s?responseChoice=1' % id

    def extra_headers_get_by_name(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" %\
                                    self.create_params['name']
        return headers

    def extra_headers_get_by_externalID(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" % \
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers


class NuageFloatingIP(NuageServerBaseClass):
    resource = 'floatingips'

    def get_fip_id(self, response):
        return self.get_response_objid(response)

    def post_resource(self):
        return '/domains/%s/%s' % (self.create_params['domain_id'],
                                   self.resource)

    def get_resource(self):
        return '/%s' % self.resource

    def get_resource_by_id(self, id):
        return '/%s/%s' % (self.resource, id)

    def get_child_resource(self, parent_resource, parent_id):
        return '/%s/%s/%s' % (parent_resource, parent_id, self.resource)

    def post_data(self):
        data = {
            "associatedSharedNetworkResourceID":
                self.create_params['shared_netid'],
            "address": self.create_params['address'],
            "externalID": get_vsd_external_id(self.create_params['externalID'])
        }
        if self.extra_params:
            data.update(self.extra_params)
        return data

    def post_fip_data(self):
        data = {
            "associatedSharedNetworkResourceID":
                self.create_params['shared_netid'],
            "domain_id": self.create_params['domain_id']
        }
        return data

    def delete_resource(self, id):
        return '/%s/%s?responseChoice=1' % (self.resource, id)

    def get_fip_resource(self):
        return '/%s/%s' % (self.resource, self.create_params['fip_id'])

    def extra_headers(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" % \
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers


class NuageVPort(NuageServerBaseClass):
    resource = 'vports'

    def get_vport_id(self, response):
        return self.get_response_objid(response)

    def get_mac_spoofing(self, response):
        if self.check_response_exist(response):
            return response[3][0]['addressSpoofing']

    def get_resource(self):
        return '/%s/%s' % (self.resource, self.create_params['vport_id'])

    def delete_resource(self):
        return '/%s/%s?responseChoice=1' % (self.resource,
                                            self.create_params['vport_id'])

    def put_resource(self):
        return '/%s/%s?responseChoice=1' % (self.resource,
                                            self.create_params['vport_id'])

    def get_vports_for_policygroup(self):
        return '/policygroups/%s/%s' % (self.create_params['policygroup_id'],
                                        self.resource)

    def get_vports_for_subnet(self):
        return '/subnets/%s/%s' % (self.create_params['subnet_id'],
                                   self.resource)

    def get_vports_for_l2domain(self):
        return '/l2domains/%s/%s' % (self.create_params['l2domain_id'],
                                     self.resource)

    def get_vport_for_fip(self):
        return '/floatingips/%s/%s' % (self.create_params['fip_id'],
                                       self.resource)

    def get_vport_for_redirectiontargets(self):
        return ('/redirectiontargets/%s/%s'
                % (self.create_params['rtarget_id'], self.resource))

    def get_child_resource(self, parent_resource, parent_id):
        return '/%s/%s/%s' % (parent_resource, parent_id, self.resource)

    def post_vport_for_l2domain(self):
        return '/l2domains/%s/%s' % (self.create_params['l2domain_id'],
                                     self.resource)

    def post_vport_for_subnet(self):
        return '/subnets/%s/%s' % (self.create_params['subnet_id'],
                                   self.resource)

    def post_vport_data(self):
        data = {
            'VLANID': self.extra_params['vlan'],
            'type': self.extra_params['type'],
            'name': self.extra_params['name']
        }

        if self.extra_params.get('type') == constants.BRIDGE_VPORT_TYPE:
            data['addressSpoofing'] = constants.ENABLED
        else:
            data['addressSpoofing'] = \
                (constants.INHERITED if
                 self.extra_params[constants.PORTSECURITY]
                 else constants.ENABLED)

        if self.extra_params.get('externalID'):
            data['externalID'] = get_vsd_external_id(
                self.extra_params['externalID'])
        return data

    def fip_update_data(self):
        data = {
            'associatedFloatingIPID': self.create_params['fip_id']
        }
        return data

    def mac_spoofing_update_data(self):
        data = {
            'addressSpoofing': self.extra_params['mac_spoofing']
        }
        return data

    def get_vport_policygroup_resource(self, id):
        return '/%s/%s/policygroups' % (self.resource, id)

    def get_vport_redirect_target_resource(self, vport_id):
        return '/%s/%s/redirectiontargets' % (self.resource, vport_id)

    def post_bridge_interface(self, id):
        return '/%s/%s/bridgeinterfaces' % (self.resource, id)

    def del_bridge_interface(self, id):
        return '/bridgeinterfaces/%s' % id

    def del_vport(self, vport_id):
        return '/%s/%s?responseChoice=1' % (self.resource, vport_id)

    def post_bridge_iface_data(self, net_type, name):
        data = {
            "attachedNetworkType": net_type,
            "name": name
        }
        return data

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" %\
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers

    def extra_headers_get_by_name(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" %\
                                    self.extra_params['vport_name']
        return headers


class NuagePolicygroup(NuageServerBaseClass):
    resource = 'policygroups'

    def get_all_resources(self):
        return '/%s' % self.resource

    def get_policygroups_for_vport(self):
        return '/vports/%s/%s' % (self.create_params['vport_id'],
                                  self.resource)

    def get_policygroup_id(self, response):
        return self.get_response_objid(response)

    def get_child_resource(self, parent_resource, parent_id):
        return '/%s/%s/%s' % (parent_resource, parent_id, self.resource)

    def put_child_resource(self, parent_resource, parent_id):
        return '/%s/%s/%s?responseChoice=1' % (parent_resource, parent_id,
                                               self.resource)

    def post_resource(self):
        return '/domains/%s/%s' % (self.create_params['domain_id'],
                                   self.resource)

    def post_resource_l2dom(self):
        return '/l2domains/%s/%s' % (self.create_params['domain_id'],
                                     self.resource)

    def post_data(self):
        data = {
            'description': self.create_params['name'],
            'name': self.create_params['sg_id'],
            'externalID': get_vsd_external_id(
                self.create_params['externalID']),
            'type': 'SOFTWARE'
        }
        if not data['name']:
            data['name'] = self.create_params['name']
        if self.create_params.get('sg_type') == 'HARDWARE':
            data['type'] = 'HARDWARE'
        if self.extra_params:
            data.update(self.extra_params)
        return data

    def post_data_ext_sg(self):
        data = {
            'description': self.create_params['description'],
            'name': self.create_params['name'],
            'type': 'SOFTWARE',
            'external': "true",
            'EVPNCommunityTag': self.create_params['extended_community']
        }
        if self.extra_params:
            data.update(self.extra_params)
        return data

    def delete_resource(self, id):
        return '/%s/%s?responseChoice=1' % (self.resource, id)

    def get_resource(self, id):
        return '/%s/%s' % (self.resource, id)

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" % \
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers

    def extra_headers_get_name(self, name):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" % name
        return headers

    def extra_headers_get_external(self, is_external):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "external IS '%s'" % is_external
        return headers

    def extra_headers_get_name_and_external(self, name, is_external):
        headers = {}
        headers['X-Nuage-Filter'] = "name IS '%s' and external IS '%s'" %\
                                    (name, is_external)

        return headers


class NuageACLRule(NuageServerBaseClass):
    def get_aclrule_id(self, response):
        return self.get_response_objid(response)

    def in_get_all_resources(self):
        return '/ingressaclentrytemplates'

    def eg_get_all_resources(self):
        return '/egressaclentrytemplates'

    def in_post_resource(self):
        id = self.create_params['acl_id']
        return ("/ingressacltemplates/%s/ingressaclentrytemplates"
                "?responseChoice=1" % id)

    def in_get_resource(self):
        id = self.create_params['acl_id']
        return '/ingressacltemplates/%s/ingressaclentrytemplates' % id

    def eg_post_resource(self):
        id = self.create_params['acl_id']
        return ("/egressacltemplates/%s/egressaclentrytemplates"
                "?responseChoice=1" % id)

    def eg_get_resource(self):
        id = self.create_params['acl_id']
        return '/egressacltemplates/%s/egressaclentrytemplates' % id

    def in_delete_resource(self, id):
        return '/ingressaclentrytemplates/%s?responseChoice=1' % id

    def eg_delete_resource(self, id):
        return '/egressaclentrytemplates/%s?responseChoice=1' % id

    def post_data_for_spoofing(self):
        aclrule = {
            "locationType": "POLICYGROUP",
            "networkType": "ANY",
            "etherType": "0x0800",
            "protocol": "ANY",
            "action": "FORWARD",
            "DSCP": '*',
        }
        if self.extra_params:
            aclrule.update(self.extra_params)
        return aclrule

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" % \
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers

    def extra_headers_get_locationID(self, policygroup_id):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "locationID IS '%s'" % policygroup_id
        return headers

    def extra_headers_get_network_id(self, policygroup_id):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "networkID IS '%s'" % policygroup_id
        return headers


class NuageNetPartitionNetwork(NuageServerBaseClass):
    def get_resource_by_id(self, net_id):
        return '/enterprisenetworks/%s' % net_id

    def post_resource(self):
        ent_id = self.create_params['net_partition_id']
        return '/enterprises/%s/enterprisenetworks' % ent_id

    def post_data(self):
        data = {
            'name': self.create_params['name'],
            'address': str(self.create_params['net'].ip),
            'netmask': str(self.create_params['net'].netmask)
        }
        return data

    def get_np_network_id(self, response):
        return self.get_response_objid(response)

    def delete_resource(self, id):
        return '/enterprisenetworks/%s' % id

    def put_resource(self, id):
        return '/enterprisenetworks/%s' % id

    def get_resource(self):
        ent_id = self.create_params['net_partition_id']
        return '/enterprises/%s/enterprisenetworks' % ent_id

    def get_np_net_list(self, response):
        return response[3]

    def get_np_net_by_name(self, response, name):
        for pubnet in self.get_np_net_list(response):
            if pubnet['name'] == name:
                return pubnet['ID']
        return None

    def extra_headers_get_name(self, name):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" % name
        return headers

    def extra_headers_get_netadress(self, cidr, netmask):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = ("address IS '%s' and netmask IS '%s'"
                                     % (cidr, netmask))
        return headers


class NuageGatewayBase(NuageServerBaseClass):
    # creation method
    def factory(create_params, extra_params, redundant=False):
        if redundant:
            return NuageRedundancyGroup(create_params=create_params,
                                        extra_params=extra_params)
        else:
            return NuageGateway(create_params=create_params,
                                extra_params=extra_params)
    factory = staticmethod(factory)

    def get_response_id(self, response):
        return self.get_response_objid(response)

    def ent_perm_update(self, np_id):
        data = {
            'permittedAction': 'EXTEND',
            'permittedID': np_id
        }
        return data

    def extra_headers_by_name(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" % self.extra_params['name']
        return headers


class NuageGateway(NuageGatewayBase):
    def get_resource(self):
        return '/gateways'

    def get_resource_for_netpart(self):
        return '/enterprises/%s/gateways' %\
            self.create_params['netpart_id']

    def get_resource_by_id(self):
        return '/gateways/%s' % self.create_params['gw_id']

    def get_ent_perm(self):
        return ('/gateways/%s/enterprisepermissions' %
                self.create_params['gw_id'])


class NuageRedundancyGroup(NuageGatewayBase):
    def get_resource(self):
        return '/redundancygroups'

    def get_resource_for_netpart(self):
        return ('/enterprises/%s/redundancygroups' %
                self.create_params['netpart_id'])

    def get_resource_by_id(self):
        return '/redundancygroups/%s' % self.create_params['gw_id']

    def get_ent_perm(self):
        return ('/redundancygroups/%s/enterprisepermissions' %
               self.create_params['gw_id'])


class NuageGatewayPortBase(NuageServerBaseClass):
    # creation method
    def factory(create_params, extra_params, redundant=False):
        if redundant:
            return NuageGatewayRedundantPort(create_params=create_params,
                                             extra_params=extra_params)
        else:
            return NuageGatewayPort(create_params=create_params,
                                    extra_params=extra_params)
    factory = staticmethod(factory)

    def get_response_id(self, response):
        return self.get_response_objid(response)

    def get_gw(self, response):
        if response[3]:
            return response[3][0]['parentID']

    def post_vlan_data(self, vlanid):
        data = {
            'value': vlanid
        }
        return data

    def delete_vlan(self, vlanid):
        return '/vlans/%s' % vlanid

    def ent_perm_update(self, np_id):
        data = {
            'permittedAction': "EXTEND",
            'permittedEntityID': np_id
        }
        return data

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" %\
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers

    def extra_headers_by_name(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" %\
                                    self.extra_params['gw_port_name']
        return headers


class NuageGatewayPort(NuageGatewayPortBase):
    def get_resource(self):
        return '/ports/%s' % self.create_params['port_id']

    def get_resource_by_gateway(self):
        return '/gateways/%s/ports' % self.create_params['gw_id']

    def post_vlan(self):
        return '/ports/%s/vlans' % self.create_params['port_id']

    def get_ent_perm(self):
        return '/ports/%s/enterprisepermissions' %\
            self.create_params['port_id']

    def get_response_objlist(self, response):
        # filter out ports whci are part of redundant ports
        return ([elem for elem in response[3] if
                elem['associatedRedundantPortID'] is None])


class NuageGatewayRedundantPort(NuageGatewayPortBase):
    def get_resource(self):
        if self.create_params['personality'] == constants.GW_TYPE['VSG']:
            return '/vsgredundantports/%s' % self.create_params['port_id']
        else:
            return '/ports/%s' % self.create_params['port_id']

    def get_resource_by_gateway(self):
        if self.create_params['personality'] == constants.GW_TYPE['VSG']:
            return '/redundancygroups/%s/vsgredundantports' %\
                    self.create_params['gw_id']
        else:
            return '/redundancygroups/%s/ports' %\
                self.create_params['gw_id']

    def post_vlan(self):
        if self.create_params['personality'] == constants.GW_TYPE['VSG']:
            return '/vsgredundantports/%s/vlans' %\
                self.create_params['port_id']
        else:
            return '/ports/%s/vlans' % self.create_params['port_id']

    def get_ent_perm(self):
        if self.create_params['personality'] == constants.GW_TYPE['VSG']:
            return '/vsgredundantports/%s/enterprisepermissions' %\
                self.create_params['port_id']
        else:
            return '/ports/%s/enterprisepermissions' %\
                self.create_params['port_id']


class NuageVlanBase(NuageServerBaseClass):
    # create method
    def factory(create_params, extra_params, redundant=False):
        if redundant:
            return NuageRedundantVlan(create_params=create_params,
                                      extra_params=extra_params)
        else:
            return NuageVlan(create_params=create_params,
                             extra_params=extra_params)
    factory = staticmethod(factory)

    def get_resonse_id(self, response):
        return self.get_response_objid(response)

    def get_resource(self):
        return '/vlans/%s' % self.create_params['vlan_id']

    def get_ent_perm(self):
        return ('/vlans/%s/enterprisepermissions' % self.create_params[
            'vlan_id'])

    def post_vlan_data(self, vlanid):
        data = {
            'value': vlanid
        }
        return data

    def ent_perm_update(self, np_id):
        data = {
            'permittedAction': "USE",
            'permittedEntityID': np_id
        }
        return data

    def extra_headers_by_value(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = ("value IS %s" %
                                     self.extra_params['vlan_value'])
        return headers


class NuageVlan(NuageVlanBase):
    def post_vlan(self):
        return '/ports/%s/vlans' % self.create_params['port_id']

    def get_resource_by_port(self):
        return '/ports/%s/vlans' % self.create_params['port_id']


class NuageRedundantVlan(NuageVlanBase):
    def post_vlan(self):
        if self.create_params['personality'] == constants.GW_TYPE['VSG']:
            return '/vsgredundantports/%s/vlans' %\
                self.create_params['port_id']
        else:
            return '/ports/%s/vlans' % self.create_params['port_id']

    def get_resource_by_port(self):
        if self.create_params['personality'] == constants.GW_TYPE['VSG']:
            return '/vsgredundantports/%s/vlans' %\
                self.create_params['port_id']
        else:
            return '/ports/%s/vlans' % self.create_params['port_id']


class NuageQOS(NuageServerBaseClass):
    __metaclass__ = ABCMeta

    def get_resource(self):
        return '/qos/%s' % self.create_params['qos_id']

    def post_data(self):
        data = {
            "name": self.create_params['name'],
        }

        if self.extra_params:
            data.update(self.extra_params)
        return data

    def put_resource(self):
        return '/qos/%s?responseChoice=1' % self.create_params['qos_id']

    def get_qosid(self, response):
        return self.get_response_objid(response)

    def delete_resource(self):
        return '/qos/%s?responseChoice=1' % self.create_params['qos_id']


class NuageVportQOS(NuageQOS):
    def get_all_resource(self):
        return '/vports/%s/qos' % self.create_params['vport_id']

    def post_resource(self):
        return '/vports/%s/qos' % self.create_params['vport_id']

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = (
            "externalID IS '%s'" % get_vsd_external_id(
                self.create_params['externalID']))
        return headers

    def extra_headers_by_value(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "value IS %s" %\
                                    self.extra_params['vlan_value']
        return headers


class NuageBasePermission(object):

    def get_permitted_entity_id(self, response):
        return response[3][0]['permittedEntityID']

    def get_permitted_entity_type(self, response):
        return response[3][0]['permittedEntityType']

    def perm_update(self, id):
        data = {
            'permittedAction': "USE",
            'permittedEntityID': id
        }
        return data


class NuagePermission(NuageServerBaseClass, NuageBasePermission):
    # def __init__(self, create_params=None, extra_params=None):
    #   super(NuagePermission, self).__init__(create_params, extra_params)

    def get_resource_by_id(self):
        return '/permissions/%s' % self.create_params['perm_id']

    def get_resource_by_vlan(self):
        return '/vlans/%s/permissions' % self.create_params['vlan_id']

    def get_resource_by_l2dom_id(self):
        return '/l2domains/%s/permissions' % self.create_params['l2dom_id']

    def get_resource_by_zone_id(self):
        return '/zones/%s/permissions' % self.create_params['zone_id']

    def delete_resource(self, perm_id):
        return '/permissions/%s?responseChoice=1' % perm_id

    def extra_headers_by_entity_id(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "permittedEntityID IS %s" %\
                                    self.extra_params['entity_id']
        return headers


class NuageEntPermission(NuageServerBaseClass, NuageBasePermission):
    # def __init__(self, create_params=None, extra_params=None):
    #   super(NuageEntPermission, self).__init__(create_params, extra_params)

    def get_response_obj(self, response):
        if response[3]:
            return super(NuageEntPermission, self).get_response_obj(response)

    def get_resource_by_id(self):
        return '/enterprisepermissions/%s' % self.create_params['perm_id']

    def get_resource_by_vlan(self):
        return '/vlans/%s/enterprisepermissions' % self.create_params[
            'vlan_id']

    def get_resource_by_port(self, redundancy=False):
        if redundancy:
            return '/vsgredundantports/%s/enterprisepermissions' %\
                self.create_params['port_id']
        else:
            return '/ports/%s/enterprisepermissions' %\
                self.create_params['port_id']

    def get_resource_by_gw(self, redundancy=False):
        if redundancy:
            return '/redundancygroups/%s/enterprisepermissions' %\
                self.create_params['gw_id']
        else:
            return '/gateways/%s/enterprisepermissions' %\
                self.create_params['gw_id']


class NuageHostInterface(NuageServerBaseClass):
    def get_all_resource(self):
        return '/vports/%s/hostinterfaces' % self.create_params['vport_id']

    def get_resource(self):
        return '/hostinterfaces/%s' % self.create_params['interface_id']

    def delete_resource(self):
        return '/hostinterfaces/%s?responseChoice=1' % self.create_params[
            'interface_id']

    def get_resource_by_vport(self):
        return '/vports/%s/hostinterfaces' % self.create_params['vport_id']

    def post_resource_by_vport(self):
        return self.get_resource_by_vport() + '?responseChoice=1'

    def post_iface_data(self):
        data = {
            "attachedNetworkType": self.extra_params['net_type'],
            "IPAddress": self.extra_params['ipaddress'],
            "MAC": self.extra_params['mac'],
            'externalID': get_vsd_external_id(self.extra_params['externalID'])
        }
        return data

    def extra_headers_by_externalid(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" % \
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers


class NuageBridgeInterface(NuageServerBaseClass):
    def get_resource(self):
        return '/bridgeinterfaces/%s' % self.create_params['interface_id']

    def delete_resource(self):
        return '/bridgeinterfaces/%s?responseChoice=1' % self.create_params[
            'interface_id']

    def get_resource_by_vport(self):
        return '/vports/%s/bridgeinterfaces' % self.create_params['vport_id']

    def post_resource_by_vport(self):
        return self.get_resource_by_vport()

    def post_iface_data(self):
        data = {
            "attachedNetworkType": self.extra_params['net_type'],
            "name": self.extra_params['name']
        }
        return data


class NuageRedirectTarget(NuageServerBaseClass):
    resource = 'redirectiontargets'

    def post_resource_l2dom(self, l2dom_id):
        return '/l2domains/%s/%s' % (l2dom_id, self.resource)

    def post_resource_l3dom(self, l3dom_id):
        return '/domains/%s/%s' % (l3dom_id, self.resource)

    def post_virtual_ip(self, rtarget_id):
        return '/%s/%s/virtualips' % (self.resource, rtarget_id)

    def get_resource_l2dom(self, l2dom_id):
        return '/l2domains/%s/%s' % (l2dom_id, self.resource)

    def get_resource_subnet(self, subnet_id):
        return '/subnets/%s/%s' % (subnet_id, self.resource)

    def get_resource_l3dom(self, l3dom_id):
        return '/domains/%s/%s' % (l3dom_id, self.resource)

    def get_redirect_target(self, rtarget_id):
        return '/%s/%s' % (self.resource, rtarget_id)

    def get_child_resource(self, parent_resource, parent_id):
        return '/%s/%s/%s' % (parent_resource, parent_id, self.resource)

    def get_all_redirect_targets(self):
        return '/%s' % self.resource

    def get_virtual_ip(self, virtual_ip_id):
        return '/virtualips/%s' % virtual_ip_id

    def get_vport_redirect_target(self, vport_id):
        return '/vports/%s/%s' % (vport_id, self.resource)

    def delete_redirect_target(self, rtarget_id):
        return '/%s/%s?responseChoice=1' % (self.resource, rtarget_id)

    def delete_virtual_ip(self, virtual_ip_id):
        return '/virtualips/%s?responseChoice=1' % virtual_ip_id

    def post_rtarget_data(self, params):
        if params.get('description'):
            description = params.get('description')
        else:
            description = params.get('name')
        if params.get('redundancy_enabled', 'false').lower() == "true":
            redundancy = True
        else:
            redundancy = False
        data = {
            'name': params.get('name'),
            'description': description,
            'endPointType': params.get('insertion_mode'),
            'redundancyEnabled': redundancy
        }
        return data

    def post_virtualip_data(self, vip):
        data = {
            'virtualIP': vip
        }
        return data

    def put_vport_data(self, rtarget_id):
        if not rtarget_id:
            data = []
        else:
            data = [rtarget_id]
        return data

    def extra_headers_by_name(self, name):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "name IS '%s'" % name
        return headers

    def extra_headers_by_id(self, rtarget_id):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "id IS '%s'" % rtarget_id
        return headers


class NuageInAdvFwdTemplate(NuageServerBaseClass):
    def get_resource_l2(self, l2dom_id):
        return '/l2domains/%s/ingressadvfwdtemplates' % l2dom_id

    def get_resource_l3(self, l3dom_id):
        return '/domains/%s/ingressadvfwdtemplates' % l3dom_id

    def post_resource_l2(self, l2dom_id):
        return '/l2domains/%s/ingressadvfwdtemplates' % l2dom_id

    def post_resource_l3(self, l3dom_id):
        return '/domains/%s/ingressadvfwdtemplates' % l3dom_id

    def post_data_default_l2(self, name):
        data = {}
        data['name'] = name + '_def_ibadvfwdl2tmplt'
        data['description'] = 'default Policy'
        data['active'] = True
        return data

    def post_data_default_l3(self, name):
        data = {}
        data['name'] = name + '_def_ibadvfwdl3tmplt'
        data['description'] = 'default Policy'
        data['active'] = True
        return data


class NuageAdvFwdRule(NuageServerBaseClass):
    def in_post_resource(self, policy_id):
        return ("/ingressadvfwdtemplates/%s/ingressadvfwdentrytemplates"
                "?responseChoice=1" % policy_id)

    def in_get_resource(self, rule_id):
        return '/ingressadvfwdentrytemplates/%s' % rule_id

    def in_delete_resource(self, rule_id):
        return '/ingressadvfwdentrytemplates/%s?responseChoice=1' % rule_id

    def extra_headers_get(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "externalID IS '%s'" % \
                                    get_vsd_external_id(
                                        self.create_params['externalID'])
        return headers

    def extra_headers_get_locationID(self, policygroup_id):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "locationID IS '%s'" % policygroup_id
        return headers


class NuageCms(NuageServerBaseClass):
    def post_resource(self):
        return '/cms'

    def post_data(self):
        return {"name": self.create_params['name']}

    def get_resource(self):
        return '/cms/%s' % self.create_params['cms_id']


class NuageVIP(NuageServerBaseClass):
    def get_resource(self):
        return "/virtualips/%s" % self.create_params['vip_id']

    def put_resource(self):
        return "/virtualips/%s?responseChoice=1" % self.create_params['vip_id']

    def delete_resource(self):
        return self.get_resource()

    def get_resource_for_vport(self):
        return "/vports/%s/virtualips" % self.create_params['vport_id']

    def get_resource_for_subnet(self):
        return "/subnets/%s/virtualips" % self.create_params['subnet_id']

    def extra_headers_given_vip(self):
        headers = {}
        headers['X-NUAGE-FilterType'] = "predicate"
        headers['X-Nuage-Filter'] = "virtualIP IS '%s'" % self.extra_params[
            'vip']
        return headers

    def post_vip_data(self):
        data = dict()
        if 'mac' in self.extra_params:
            data['MAC'] = self.extra_params['mac']

        if 'vip' in self.extra_params:
            data['virtualIP'] = self.extra_params['vip']

        if 'fip' in self.extra_params:
            if self.extra_params['fip']:
                data['associatedFloatingIPID'] = self.extra_params['fip']
            else:
                data['associatedFloatingIPID'] = None
        return data

    @staticmethod
    def get_ip_addr(vip):
        return vip['virtualIP']

    @staticmethod
    def get_mac_addr(vip):
        return vip['MAC']

    @staticmethod
    def get_vip_id(vip):
        return vip['ID']
