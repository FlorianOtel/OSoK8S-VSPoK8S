# Copyright 2015 Alcatel-Lucent USA Inc.
# All Rights Reserved.

import base64
import httplib
import json
import logging
import socket
import ssl
import time

from nuagenetlib.common import constants

LOG = logging.getLogger(__name__)
MAX_RETRIES = 5
MAX_RETRIES_503 = 5

REST_SUCCESS_CODES = constants.REST_SUCCESS_CODES
REST_NOT_FOUND = constants.RES_NOT_FOUND
REST_SERV_UNAVAILABLE_CODE = constants.REST_SERV_UNAVAILABLE_CODE


class RESTProxyBaseException(Exception):
    message = _("An unknown exception occurred.")

    def __init__(self, **kwargs):
        try:
            super(RESTProxyBaseException, self).__init__(self.message % kwargs)
            self.msg = self.message % kwargs
        except Exception:
            if self.use_fatal_exceptions():
                raise
            else:
                super(RESTProxyBaseException, self).__init__(self.message)

    def __unicode__(self):
        return unicode(self.msg)

    def use_fatal_exceptions(self):
        return False


class RESTProxyError(RESTProxyBaseException):
    def __init__(self, message, error_code=None, vsd_code=None):
        self.code = 0
        if error_code:
            self.code = error_code
        self.vsd_code = vsd_code

        if message is None:
            message = "None"

        if self.code == 409:
            self.message = _(message)
        else:
            self.message = (_("Error in REST call to VSD: %s") % message)
        super(RESTProxyError, self).__init__()


class ResourceExistsException(RESTProxyError):
    def __init__(self, message):
        super(ResourceExistsException, self).__init__(
            message,
            constants.CONFLICT_ERR_CODE,
            vsd_code=constants.RES_EXISTS_INTERNAL_ERR_CODE)

        super(RESTProxyError, self).__init__()


class ResourceNotFoundException(RESTProxyError):
    def __init__(self, message):
        super(ResourceNotFoundException, self).__init__(
            message,
            constants.RES_NOT_FOUND)


class RESTProxyServer(object):
    def __init__(self, server, base_uri, serverssl,
                 serverauth, auth_resource,
                 organization, servertimeout=30):
        try:
            server_ip, port = server.split(":")
        except ValueError:
            server_ip = server
            port = None
        self.server = server_ip
        self.port = int(port) if port else None
        self.base_uri = base_uri
        self.serverssl = serverssl
        self.serverauth = serverauth
        self.auth_resource = auth_resource
        self.organization = organization
        self.timeout = servertimeout
        self.retry = 0
        self.retry_503 = 0
        self.auth = None
        self.success_codes = range(200, 207)

    def _rest_call(self, action, resource, data, extra_headers=None):
        if self.retry >= MAX_RETRIES:
            LOG.error(_('RESTProxy: Max retries exceeded'))
            # Get ready for the next set of operation
            self.retry = 0
            return 0, None, None, None
        uri = self.base_uri + resource
        body = json.dumps(data)
        headers = {}
        headers['Content-type'] = 'application/json'
        headers['X-Nuage-Organization'] = self.organization
        if self.auth:
            headers['Authorization'] = self.auth
        conn = None
        if extra_headers:
            headers.update(extra_headers)

        LOG.debug('Request uri: %s', uri)
        LOG.debug('Request headers: %s', headers)
        LOG.debug('Request body: %s', body)

        if self.serverssl:
            if hasattr(ssl, '_create_unverified_context'):
                # pylint: disable=no-member
                # pylint: disable=unexpected-keyword-arg
                conn = httplib.HTTPSConnection(
                    self.server, self.port, timeout=self.timeout,
                    context=ssl._create_unverified_context())
                # pylint: enable=no-member
                # pylint: enable=unexpected-keyword-arg
            else:
                conn = httplib.HTTPSConnection(
                    self.server, self.port, timeout=self.timeout)

            if conn is None:
                LOG.error(_('RESTProxy: Could not establish HTTPS '
                            'connection'))
                return 0, None, None, None
        else:
            conn = httplib.HTTPConnection(
                self.server, self.port, timeout=self.timeout)
            if conn is None:
                LOG.error(_('RESTProxy: Could not establish HTTP '
                            'connection'))
                return 0, None, None, None

        try:
            conn.request(action, uri, body, headers)
            response = conn.getresponse()
            respstr = response.read()
            respdata = respstr
            LOG.debug('Response status is %(st)s and reason is %(res)s',
                      {'st': response.status,
                       'res': response.reason})
            LOG.debug('Response data is %s', respstr)
            if response.status in self.success_codes:
                try:
                    respdata = json.loads(respstr)
                except ValueError:
                    # response was not JSON, ignore the exception
                    pass
            ret = (response.status, response.reason, respstr, respdata)
        except (socket.timeout, socket.error) as e:
            LOG.error(_('ServerProxy: %(action)s failure, %(e)r'), locals())
            # retry
            time.sleep(1)
            self.retry = self.retry + 1
            return self._rest_call(action, resource, data, extra_headers)
        conn.close()
        if response.status == constants.REST_SERV_UNAVAILABLE_CODE:
            if self.retry_503 < MAX_RETRIES_503:
                time.sleep(1)
                self.retry_503 = self.retry_503 + 1
                LOG.debug('VSD unavailable. Retrying')
                return self._rest_call(action, resource, data,
                                       extra_headers=extra_headers)
            else:
                LOG.debug('After 5 retries VSD is unavailable. Bailing out')
        self.retry = 0
        self.retry_503 = 0
        return ret

    def generate_nuage_auth(self):
        data = ''
        encoded_auth = base64.encodestring(self.serverauth).strip()
        self.auth = 'Basic ' + encoded_auth
        resp = self._rest_call('GET', self.auth_resource, data)
        if resp[0] in self.success_codes and resp[3][0]['APIKey']:
            respkey = resp[3][0]['APIKey']
        else:
            if resp[0] == 0:
                assert 0, 'Could not establish conn with REST server. Abort'
            else:
                assert 0, 'Could not authenticate to REST server. Abort'
        uname = self.serverauth.split(':')[0]
        new_uname_pass = uname + ':' + respkey
        auth = 'Basic ' + base64.encodestring(new_uname_pass).strip()
        self.auth = auth

    def rest_call(self, action, resource, data, extra_headers=None):
        response = self._rest_call(action, resource, data,
                                   extra_headers=extra_headers)
        '''
        If at all authentication expires with VSD, re-authenticate.
        '''
        if response[0] == 401 and response[1] == 'Unauthorized':
            self.generate_nuage_auth()
            return self._rest_call(action, resource, data,
                                   extra_headers=extra_headers)
        return response

    def get(self, resource, data='', extra_headers=None, required=False):
        response = self.rest_call('GET', resource, data,
                                  extra_headers=extra_headers)
        if response[0] in REST_SUCCESS_CODES:
            return response[3]
        elif response[0] == REST_NOT_FOUND and not required:
            return ''
        else:
            raise self._error_response(response)

    def retrieve_by_external_id(self, resource, data):
        if not data.get('externalID'):
            return None
        headers = {'X-NUAGE-FilterType': "predicate",
                   'X-Nuage-Filter':
                       "externalID IS '%s'" % data.get('externalID')}
        return self.get(resource, extra_headers=headers)

    def retrieve_by_name(self, resource, data):
        if not data.get('name'):
            return None
        headers = {'X-NUAGE-FilterType': "predicate",
                   'X-Nuage-Filter': "name IS '%s'" % data.get('name')}
        return self.get(resource, extra_headers=headers)

    def post(self, resource, data, extra_headers=None,
             on_res_exists=retrieve_by_external_id):
        response = self.rest_call('POST', resource, data,
                                  extra_headers=extra_headers)
        if response[0] in REST_SUCCESS_CODES:
            return response[3]
        elif response[0] == constants.CONFLICT_ERR_CODE:
            # Under heavy load, vsd responses may get lost. We must try find
            # the resource else it's stuck in VSD.
            errors = json.loads(response[3])
            if (errors.get('internalErrorCode') ==
                    constants.RES_EXISTS_INTERNAL_ERR_CODE):
                get_response = None
                if on_res_exists:
                    get_response = on_res_exists(resource, data)
                if not get_response:
                    errors = json.loads(response[3])
                    msg = str(errors['errors'][0]['descriptions'][0]
                              ['description'])
                    raise ResourceExistsException(msg)
                return get_response
        raise self._error_response(response)

    def put(self, resource, data, extra_headers=None):
        response = self.rest_call('PUT', resource, data,
                                  extra_headers=extra_headers)
        if response[0] in REST_SUCCESS_CODES:
            return
        else:
            errors = json.loads(response[3])
            vsd_code = str(errors.get('internalErrorCode'))
            if vsd_code == constants.VSD_NO_ATTR_CHANGES_TO_MODIFY_ERR_CODE:
                return
            raise self._error_response(response)

    def delete(self, resource, data='', extra_headers=None, required=False):
        response = self.rest_call('DELETE', resource, data,
                                  extra_headers=extra_headers)
        if response[0] in REST_SUCCESS_CODES:
            return response[3]
        elif response[0] == REST_NOT_FOUND and not required:
            return None
        else:
            raise self._error_response(response)

    def _error_response(self, response):
        errors = json.loads(response[3])
        if response[0] == REST_SERV_UNAVAILABLE_CODE:
            msg = 'VSD temporarily unavailable, ' + str(errors['errors'])
        else:
            msg = str(errors['errors'][0]['descriptions'][0]['description'])

        if response[0] == REST_NOT_FOUND:
            return ResourceNotFoundException(msg)
        vsd_code = str(errors.get('internalErrorCode'))
        return RESTProxyError(msg, error_code=response[0], vsd_code=vsd_code)
