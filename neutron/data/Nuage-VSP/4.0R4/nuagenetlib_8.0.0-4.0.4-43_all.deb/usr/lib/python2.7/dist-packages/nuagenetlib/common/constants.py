REST_SUCCESS_CODES = range(200, 207)
DEF_OPENSTACK_USER = 'os_user'
DEF_OPENSTACK_USER_EMAIL = 'osuser@nuage-openstack.com'
DEF_OPENSTACK_USER_PASS = 'dummypass'
REST_SERV_UNAVAILABLE_CODE = 503

VSD_RESP_OBJ = 3
CONFLICT_ERR_CODE = 409
RES_NOT_FOUND = 404
RES_EXISTS_INTERNAL_ERR_CODE = '2510'
VSD_NO_ATTR_CHANGES_TO_MODIFY_ERR_CODE = '2039'

PROTO_NAME_TO_NUM = {
    'tcp': 6,
    'udp': 17,
    'icmp': 1
}
NUAGE_ACL_INGRESS = 'ingress'
NUAGE_ACL_EGRESS = 'egress'
NUAGE_ACL_INGRESS_TEMPLATE = 'ingressacltemplate'
NUAGE_ACL_EGRESS_TEMPLATE = 'egressacltemplate'
NUAGE_DEFAULT_L2_INGRESS_ACL = '_def_ibl2acl'
NUAGE_DEFAULT_L2_EGRESS_ACL = '_def_obl2acl'
NUAGE_DEFAULT_L3_INGRESS_ACL = '_def_ibl3acl'
NUAGE_DEFAULT_L3_EGRESS_ACL = '_def_obl3acl'


DHCP_OPTIONS = {
    'gateway_ip': '03',
    'dns_nameserver': '06',
    'classless-static-route': '79',  # 121
    'microsoft-classless-static-route': 'f9'  # 249
}
DHCP_ROUTER_OPTION = '03'

PRCS_DHCP_OPT_AS_RAW_HEX = [46, 77, 94, 97, 121, 125, 255]

NOVA_PORT_OWNER_PREF = 'compute:'

DEF_NUAGE_ZONE_PREFIX = 'def_zone'
DEF_L3DOM_TEMPLATE_PFIX = '_def_L3_Template'
DEF_L2DOM_TEMPLATE_PFIX = '_def_L2_Template'
TEMPLATE_ISOLATED_ZONE = 'openstack-isolated'
TEMPLATE_SHARED_ZONE = 'openstack-shared'

NUAGE_NOTSUPPORTED_ETHERTYPE = ['IPv6']
NUAGE_NOTSUPPORTED_ACL_MATCH = ['ethertype value IPv6']
NOT_SUPPORTED_ACL_ATTR_MSG = (','.join(NUAGE_NOTSUPPORTED_ACL_MATCH) +
                              " attribute(s) not supported by nuage plugin")
NUAGE_ACL_PROTOCOL_ANY_MAPPING = ['tcp', 'udp']
RES_POLICYGROUPS = 'policygroups'


AUDIT_LOG_DIRECTORY = '/nuageaudit'
AUDIT_LOG_FILENAME = '/audit.log'

HEX_ELEM = '[0-9A-Fa-f]'
UUID_PATTERN = '-'.join([HEX_ELEM + '{8}', HEX_ELEM + '{4}',
                         HEX_ELEM + '{4}', HEX_ELEM + '{4}',
                         HEX_ELEM + '{12}'])

NETWORK_TYPE_L2 = 'l2'
NETWORK_TYPE_L3 = 'l3'

NUAGE_PAT_DEF_ENABLED = 'default_enabled'
NUAGE_PAT_DEF_DISABLED = 'default_disabled'

ENTERPRISE = 'enterprise'
ENABLED = 'ENABLED'
DISABLED = 'DISABLED'
INHERITED = 'INHERITED'
BRIDGE_VPORT_TYPE = 'BRIDGE'
HOST_VPORT_TYPE = 'HOST'
L2DOMAIN = 'L2DOMAIN'
SUBNET = 'SUBNET'
ASSIGN_VLAN = 'assign'
UNASSIGN_VLAN = 'unassign'
SOFTWARE = 'SOFTWARE'
HARDWARE = 'HARDWARE'
VPORT = 'VPORT'
GW_TYPE = {
    'VSG': 'VSG',
    'VSA': 'VSA',
    'VRSG': 'VRSG'
}
VSD_TUNNEL_TYPES = {
    'VXLAN': 'VXLAN',
    'GRE': 'GRE',
    'DEFAULT': 'DC_DEFAULT'
}

HEX_ELEM = '[0-9A-Fa-f]'
UUID_PATTERN = '-'.join([HEX_ELEM + '{8}', HEX_ELEM + '{4}',
                         HEX_ELEM + '{4}', HEX_ELEM + '{4}',
                         HEX_ELEM + '{12}'])
INFINITY = 'INFINITY'

TIER_STANDARD = 'STANDARD'
TIER_NETWORK_MACRO = 'NETWORK_MACRO'
TIER_APPLICATION = 'APPLICATION'
TIER_APPLICATION_EXTENDED_NETWORK = 'APPLICATION_EXTENDED_NETWORK'

NUAGE_LDAP_MODE = 'CMS'

NUAGE_PLCY_GRP_FOR_SPOOFING = 'PG_FOR_LESS_SECURITY'
PORTSECURITY = 'port_security_enabled'
